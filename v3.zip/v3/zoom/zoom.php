<?php 
 
include_once 'Zoom_Api.php';

$zoom_meeting = new Zoom_Api();

$data = array();
$data['topic'] 		= 'Online Appointment';
$data['start_date'] = date("Y-m-d h:i:s", strtotime($_POST['date'].' '.$_POST['time']));
$data['duration'] 	= 60;
$data['type'] 		= 2;
$data['password'] 	= rand();

try {
	$response = $zoom_meeting->createMeeting($data);
	
	/*echo "Meeting ID: ". $response->id;
	echo "<br>";
	echo "Topic: "	. $response->topic;
	echo "<br>";
	echo "Join URL: ". $response->join_url ."<a href='". $response->join_url ."'>Open URL</a>";
	echo "<br>";
	echo "Meeting Password: ". $response->password;*/
    
	
} catch (Exception $ex) {
    echo $ex;
}


?>