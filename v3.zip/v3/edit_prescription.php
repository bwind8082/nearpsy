<?php include 'includes/session.php'; ?>
<?php
if(isset($_POST['add_prescription'])){
$no=$_POST['nopr'];
for($i=0;$i<$no;$i++){
	$m_name.=$_POST['prname_'.$i].'@@';
	$quantity.=$_POST['prqun_'.$i].'@@';
	$day.=$_POST['prday_'.$i].'@@';

if(!empty($_POST['prtime_'.$i])){
foreach($_POST['prtime_'.$i] as $selected){
$time.= $selected.",";
}
$time = rtrim($time, ",");
$time.='@@';
}
}
$m_name = rtrim($m_name, "@@");
$quantity = rtrim($quantity, "@@");
$time = rtrim($time, "@@");
$day = rtrim($day, "@@");
$date=date("d M Y");

$conn = $pdo->open();
try{
	if($_POST['e']=='0'){
	$stmt = $conn->prepare("INSERT INTO prescription (pid, did,`date`, m_name, quantity, day,`time`) VALUES (:pid,:did,:pdate,:m_name,:quantity, :day,:ptime)");
	$stmt->execute(['pid'=>$_POST['pid'], 'did'=>$_POST['did'],'pdate'=>$date, 'm_name'=>$m_name, 'quantity'=>$quantity, 'day'=>$day,'ptime'=>$time]);
	}
	else{
	$stmt = $conn->prepare("UPDATE prescription SET m_name=:m_name, quantity=:quantity, day=:day,`time`=:ptime WHERE id=:prid");
	$stmt->execute(['m_name'=>$m_name, 'quantity'=>$quantity, 'day'=>$day,'ptime'=>$time,'prid'=>$_POST['prid']]);
	}
}

catch(PDOException $e){
	$_SESSION['error'] = $e->getMessage();
}
$pdo->close();
header('location: patient-profile.php?pid='.$_POST['pid'].'');
}
else{
	$_SESSION['error'] = 'Fill up prescription form first';
	header('location: index.php');
	}
?>