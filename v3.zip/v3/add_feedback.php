<?php include 'includes/session.php'; ?>
<?php
if(isset($_POST['submit'])){
$did=$_POST['did'];
$rat=$_POST['rating'];
$rec=$_POST['recommended'];
$rev=$_POST['rev'];
$date=date("d M Y");

$conn = $pdo->open();

try{
	$stmt = $conn->prepare("INSERT INTO feedback (g_uid, did, review, rating, recommend,r_date) VALUES (:g_uid, :did,:review,:rating, :recommend,:r_date)");
	$stmt->execute([':g_uid'=>$user['id'], ':did'=>$did,':review'=>$rev,':rating'=>$rat, ':recommend'=>$rec,':r_date'=>$date]);
}

catch(PDOException $e){
$_SESSION['error'] = $e->getMessage();
}

$pdo->close();
}
else
	$_SESSION['error'] = 'Fill up feedback form first';

header('location: doctor-profile.php?id='.$did.'');

?>