-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 30, 2021 at 06:38 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `doc`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `id` bigint(255) NOT NULL,
  `pid` bigint(255) NOT NULL,
  `did` bigint(255) NOT NULL,
  `p_name` varchar(100) NOT NULL,
  `p_age` int(3) NOT NULL,
  `p_email` varchar(255) NOT NULL,
  `p_mobileno` varchar(10) NOT NULL,
  `a_date` varchar(100) NOT NULL,
  `a_time` varchar(10) NOT NULL,
  `payment_id` bigint(255) NOT NULL,
  `appointment_type` varchar(10) NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'Pending',
  `a_url` varchar(200) DEFAULT NULL,
  `a_pass` int(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`id`, `pid`, `did`, `p_name`, `p_age`, `p_email`, `p_mobileno`, `a_date`, `a_time`, `payment_id`, `appointment_type`, `status`, `a_url`, `a_pass`) VALUES
(1, 1, 2, 'Tushar Mungra', 20, 'bwind8082@gmail.com', '7778806784', '03 May 2021', '03:00 PM', 1, 'offline', 'Pending', '', 0),
(2, 1, 3, 'Tushar Mungra', 20, 'bwind8082@gmail.com', '7778806784', '22 Apr 2021', '01:00 PM', 2, 'offline', 'Confirm', '', 0),
(3, 1, 4, 'Tushar Mungra', 20, 'bwind8082@gmail.com', '7778806784', '22 Apr 2021', '03:00 PM', 3, 'offline', 'Completed', '', 0),
(8, 5, 3, 'Aadhya Patel', 20, 'aadhya@gmail.com', '7894561230', '22 Apr 2021', '07:00 PM', 9, 'offline', 'Completed', '', 0),
(9, 5, 3, 'Aadhya Patel', 20, 'aadhya@gmail.com', '7894561230', '27 Apr 2021', '11:00 AM', 10, 'offline', 'Confirm', '', 0),
(10, 2, 3, 'Trushant Limbani', 24, 'tru@gmail.com', '9856321478', '22 Apr 2021', '04:00 PM', 11, 'offline', 'Completed', '', 0),
(11, 2, 3, 'Trushant Limbani', 24, 'tru@gmail.com', '9856321478', '10 May 2021', '06:00 PM', 12, 'offline', 'Confirm', '', 0),
(12, 3, 3, 'Jenil Pansuriya', 19, 'jenil@gmail.com', '7845123690', '24 Apr 2021', '12:00 PM', 13, 'offline', 'Cancelled', '', 0),
(13, 4, 3, 'Henis Nakrani', 21, 'henis@gmail.com', '8456123079', '03 May 2021', '06:00 PM', 14, 'online', 'Confirm', '', 0),
(14, 1, 3, 'Sanket Mungra', 20, 'bwind8082@gmail.com', '7778806784', '07 May 2021', '06:00 PM', 15, 'offline', 'Pending', '', 0),
(15, 1, 3, 'Sanket Mungra', 20, 'bwind8082@gmail.com', '7778806784', '07 May 2021', '06:00 PM', 16, 'online', 'Pending', 'https://us05web.zoom.us/j/88282799732?pwd=L08zeWpPdytYREk0ZkJ6RmEvcGZTZz09', 301735690),
(16, 1, 3, 'Sanket Mungra', 20, 'bwind8082@gmail.com', '7778806784', '07 May 2021', '06:00 PM', 17, 'online', 'Pending', 'https://us05web.zoom.us/j/86889346197?pwd=STczaTg4SjVSOGx0UDQ0TStsblFzQT09', 1333258345),
(17, 1, 3, 'Sanket Mungra', 20, 'bwind8082@gmail.com', '7778806784', '03 May 2021', '12:00 PM', 18, 'offline', 'Cancelled', NULL, NULL),
(18, 1, 1, 'Sanket Mungra', 20, 'bwind8082@gmail.com', '7778806784', '05 May 2021', '04:00 PM', 19, 'offline', 'Pending', NULL, NULL),
(19, 1, 2, 'Sanket Mungra', 20, 'bwind8082@gmail.com', '7778806784', '13 May 2021', '04:00 PM', 20, 'offline', 'Pending', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `id` bigint(255) NOT NULL,
  `user_id` bigint(255) NOT NULL,
  `fees` varchar(100) DEFAULT NULL,
  `doc_type` text NOT NULL,
  `about_me` text DEFAULT NULL,
  `services` text DEFAULT NULL,
  `specializations` text DEFAULT NULL,
  `img` varchar(10) NOT NULL DEFAULT 'defult.jpg',
  `address_line_1` varchar(100) DEFAULT NULL,
  `address_line_2` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `postal_code` varchar(6) DEFAULT NULL,
  `degree` varchar(100) DEFAULT NULL,
  `institute` varchar(1000) DEFAULT NULL,
  `year_of_completion` varchar(100) DEFAULT NULL,
  `award` varchar(100) DEFAULT NULL,
  `a_year` varchar(100) DEFAULT NULL,
  `h_name` varchar(100) DEFAULT NULL,
  `etime` varchar(100) DEFAULT NULL,
  `designation` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`id`, `user_id`, `fees`, `doc_type`, `about_me`, `services`, `specializations`, `img`, `address_line_1`, `address_line_2`, `city`, `state`, `country`, `postal_code`, `degree`, `institute`, `year_of_completion`, `award`, `a_year`, `h_name`, `etime`, `designation`) VALUES
(1, 2, '200-700', 'Dentist', 'Dr. Sagar Bumtaria is one of the leading Endodontist based in Jamnagar. After acquiring his graduation degree from Gujarat University completed his post graduation from Gujarat University in 2014, with speciality in Conservative Dentistry and Endodontics. He has been an achiever throughout his life and has won numerous awards and medals.\r\n\r\nDr. Sagar Bumtaria is practicing as a Dental Surgeon at Nijanand Dental Care & Implant centre. He has a well equipped clinic with the latest instrument and the infrastructure is one of the best in the city.', 'Root Canal Treatment,Dental Implant,Crown & Bridges,Braces,Clear Braces,Dental Jewelry', 'Children Care,Dental Care,Oral and Maxillofacial Surgery ,Endodontist ,Orthodontist,Prosthodontics', '2.jpg', '305-306, Oskar Complex,', 'Opp. Rajlaxmi Bakery, Limda Lane, Near Lal Bungalow', 'Jamnagar', 'Gujarat', 'India', '361001', 'BDS@@MDS-Endodontist', 'Gujarat University@@Gujarat University', '2006-2012@@2012-2014', 'The Dental Professional of The Year Award', '2016', 'Nijanand DENTAL CARE', '2014-2021', 'Dentist'),
(2, 3, '100-600', 'Dentist', 'Rashmi Jasani topped among all the MDS students in her college and stood 5th in the Gujarat University. Dr. Rashmi proficiently is trained in all aspects of Periodontics and surgical treatment. She also has extensive training in the surgical placement of dental implants and hard tissue grafting. Her training focuses extensively on full mouth rehabilitative care with an interdisciplinary approach. She was honored with two national-level awards from Bright Smile Bright future Program. She is dedicated to delivering the highest quality dental treatment.', 'Dental Implant,Smile Makeover,Invisible Aligners,Pediatric dentistry', 'child dentistry,Orthodontist,pediatric dentistry', '3.jpg', 'Virani chowk, 1 st Floor', ' Vidyanagar main road & Commisonor Bunglow road corner', 'Rajkot', 'Gujarat', 'India', '360005', 'BDS@@MDS-orthodentist', 'Gujarat University@@Academy of dental excellence', '1999-2004@@2004-2007', 'Bright Smile Bright future Program', '2010', 'Comfort Care Dental Clinic@@Shiv Dental Clinic@@City Dental Hospital', '2004-2010@@2010-2015@@2015-2021', 'Dentist@@Orthodentist@@Consultant Dental Surgeon & C. Orthodontist'),
(3, 4, '1000-10000', 'Cardiologist', 'Dr. Keyur Parikh is an interventional cardiologist by profession having over more than 30 years of experience,Dr. Keyur Parikh is a Fellow of Cardiac Society of India (FCSI), Fellow of American College of Cardiology (FACC), Fellow of European Society of Cardiology (FESC), Fellow of Society for Cardiac Angiography and Interventions (FSCAI), Fellow of International Academy of Cardiovascular Sciences (FIACS), Member of American Medical Association (AMA), USA, Member of working group on Pathogenosis of Atherosclerosis of the ESC and Academy of TCT, USA.', 'ECG, ECHO, TMT, Holter Test,AICD,Pacemaker', 'Thoracic Surgery,Cardiovascular', '4.jpg', 'Science City Rd, Science City', 'Panchamrut Bunglows II, Sola', 'Ahmedabad', 'Gujarat', 'India', '380060', 'MBBS@@MD-Invasive and Noninvasive cardiology', 'Smt. N. H. L. Municipal Medical College@@Kaiser Permanente Medical Center (UCLA/USC)', '1976-1980@@1985-1987', NULL, NULL, 'Washington Township Hospital@@GRMI@@SAL Hospital@@CIMS Hospital', '1987-1995@@1995-2001@@2001-2010@@2010-2021', 'Cardiologist@@As Cardiologist (India) and Management@@As Cardiologist (India) and Managemen@@Chairma'),
(4, 5, '5000-20000', 'Urologist', 'Dr. RUPESH SHAH is an eminent Urologist, Andrologist and Kidney Transplant Surgeon in Ahmedabad, Gujarat, India. With over 40,000 operations over the past 25 years he brings an unmatched level of expertise in urology care in Ahmedabad. A Gold Medalist Alumni Doctor of Gujarat University and Chicago Reeze Hospital, he brings a combination of years of experience and modern technology. Hitesh Urological and Surgical Hospital is an ultra modern Urology Hospital equipped with 2 operation theatres, surgical microscopes, 2 third generation lithotripsy machines and the best of 21st century medical technology for complete urological and nephrology treatment. As a Uro Surgeon, he is a specialist in Kidney Stone treatment operation, Kidney Transplant, Male Infertility treatment, Prostate enlargement and prostate cancer treatment as well as other urological surgeries in Ahmedabad, Gujarat, India.', 'Prostatic Biopsy,PCNL,URS', 'Laparoscopic Prostatectom,Radical Prostatectomy ', '5.jpg', 'Science City Rd, Science City', 'Panchamrut Bunglows II, Sola', 'Ahmedabad ', 'Gujarat', 'INDIA', '380060', 'MBBS@@MS-SURGERY@@ DNB-URO SURGERY', 'B.J. Medical College@@B.J. Medical College@@GMERS', '2000-2005@@2005-2007@@2007-2010', NULL, NULL, 'APOLLO@@CIMS', '2010-2016@@2016-2021', 'Urologists@@Urologists'),
(5, 6, '100-450', 'Ophthalmologists', 'Dr. Sarita S. Begani completed his M.B.B.S from Goa Medical College in 2003. She did DNB (Ophthalmology) from Icare Eye hospital and postgraduate institute NOIDA. She finished 2 year surgical retina fellowship from Retina Foundation (Dr Nagpal eye hospital) Ahmedabad in 2011. He is practising vitreo retina and uvea since then. She has more than 50 publications in national and international journals and 20 publications in peer reviewed journals like Retina, JVRD, TJO and IJO.', 'Retinal Detachment,ARMD,Endophthalmitis,ROP,Mayopiya', 'Coroidal Neio,ERM', '6.jpg', 'swami vivekanand netra mandir 300-303/4th floor/shlok business centre', 'B/s Apple Hospital, Ring Rd, Udhana Darwaja', 'Surat', 'Gujarat ', 'India', '395002', 'MBBS@@MD-Ophthalmology@@DNB-Ophthalmology', 'Surat Municipal Institute of Medical Education and Research@@Jawaharlal Institute of Postgraduate Medical Education and Research@@Jawaharlal Institute of Postgraduate Medical Education and Research', '1995-2000@@2000-2002@@2002-2005', NULL, NULL, 'ASG Eye Hospital@@SVNM', '2005-2013@@2013-2021', 'Ophthalmologists@@Seniour Ophthalmologists'),
(6, 7, '300-700', 'Orthopedist', 'Dr. Snehal J Shah  is an experienced Orthopedic Doctor in Jivrajpark, Ahmedabad. She has been a successful Orthopedic Doctor for the last 29 years. She studied and completed MS-Ortho . She is currently practising at Namohari Orthopaedic Hospital in Jivrajpark, Ahmedabad.', 'knee replacement surgery,Hip Replacement Surgery,shoulder replacement surgery', 'knee replacement surgery', '7.jpg', '5 Jagannath Park', 'Near Malav Lake, Jivraj Park', 'Ahmedabad', 'Gujarat', 'India', '380051', 'MBBS@@MS-Orthopaedics@@Mch-Orthopaedics', 'All India Institute Of Medical Sciences@@Kasturba Medical College@@Kasturba Medical College', '1996-2001@@2001-2004@@2004-2005', 'Dr. B. C. Roy National Award in the year', '2019', 'krishna orthopaedic hospital@@Namohari Orthopaedic Hospital ', '2005-2014@@2014-2021', 'Orthopedist@@Orthopedist'),
(7, 8, '2000-7000', 'Neurologist', 'SHe has achieved his Neurology degree in P.D. Hinduja national hospital and medical research centre in Mumbai under guidance of Dr P.P. Ashok (stroke specialist), Dr Roop Gursahani (epilepsy and Multiple sclerosis specialist) and Dr Charulata Sankhala (Parkinson’s disease and movement disorder specialist). Hinduja Hospital is one of the largest hospitals in Mumbai with huge number of OPD, Indoor and electrophysiology work in neurology department.', 'BAER,VEP,RNS,EMG,NCV,EEG', 'EEG,VEP,EMG', '8.jpg', ' Okhla road', 'Sukhdev Vihar Metro Station', 'New Delhi', 'New Delhi', 'India', '110025', 'MBBS@@MD-Internal Medicine@@DM-Neurology', 'Government Medical College@@ P.G.I.M.S Rohtak@@P.D. Hinduja national hospital and medical research centre', '1995-2000@@2000-2003@@2003-2006', 'Best Paper Award of Indian Epilepsy Association', '2009', 'Safdarjung Hospital@@Max Hospital@@Artemis Hospital', '2006-2009@@2009-2015@@2015-2021', 'Consultant@@ Consultant and Neurology@@Senior Resident and Neurology'),
(8, 9, '100-500', 'Urologist', 'Dr Kunal Aterkar is an eminent Urologist & Kidney Transplant Surgeon in Ahmedabad And Gandhinagar, Gujarat. He has done Mch (Urology) from prestigious Lokmanya Tilak Medical College, Mumbai. Dr Kunal Aterkar is associated with several leading hospitals in Gandhinagar & Ahmedabad as Senior Consultant – Urology .His expertise covers all urology treatments: Urology stone, All Urology Surgeries, Uro-Oncology, Sexual Disorders, Kidney transplant etc.', 'PCNL,URS,ESWL', 'Stone Treatment', '9.jpg', 'Plot No 14611', 'Mr Panchdec Mandir, Sector-22, Sector-22', 'Gandhinagar', 'Gujarat', 'India', '382022', 'MBBS@@MS-General Surgery@@Mch-Urology', 'King George\'s Medical University@@King George\'s Medical University@@King George\'s Medical University', '2001-2006@@2006-2008@@2008-2011', NULL, NULL, 'Arogyam Hospital', '2013-2021', 'Urologists');

-- --------------------------------------------------------

--
-- Table structure for table `doctor_timing`
--

CREATE TABLE `doctor_timing` (
  `did` bigint(255) NOT NULL,
  `sunday` varchar(300) DEFAULT NULL,
  `monday` varchar(300) DEFAULT NULL,
  `tuesday` varchar(300) DEFAULT NULL,
  `wednesday` varchar(300) DEFAULT NULL,
  `thursday` varchar(300) DEFAULT NULL,
  `friday` varchar(300) DEFAULT NULL,
  `saturday` varchar(300) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `doctor_timing`
--

INSERT INTO `doctor_timing` (`did`, `sunday`, `monday`, `tuesday`, `wednesday`, `thursday`, `friday`, `saturday`) VALUES
(3, NULL, '10:00 am-12:00 pm,3:00 am-9:00 pm', '09:00 am -  12:00 pm,04:00 pm - 09:00 pm', '09:00 am - 12:00 pm,04:00 pm - 09:00 pm', '09:00 am - 12:00 pm,04:00 pm - 09:00 pm', '09:00 am - 12:00 pm,04:00 pm - 09:00 pm', '09:00 am -  03:00 pm'),
(1, NULL, '09:00 am -  12:00 pm,04:00 pm -  09:00 pm', '09:00 am -  12:00 pm,04:00 pm -  09:00 pm', '09:00 am -  12:00 pm,04:00 pm -  09:00 pm', '09:00 am -  12:00 pm,04:00 pm -  09:00 pm', '09:00 am -  12:00 pm,04:00 pm -  09:00 pm', '09:00 am -  04:00 pm'),
(2, NULL, '09:00 am -  12:00 pm,04:00 pm -  09:00 pm', '09:00 am -  12:00 pm,04:00 pm -  09:00 pm', '09:00 am -  12:00 pm,04:00 pm -  09:00 pm', '09:00 am -  12:00 pm,04:00 pm -  09:00 pm', '09:00 am -  12:00 pm,04:00 pm -  09:00 pm', '09:00 am -  04:00 pm'),
(4, NULL, '09:00 am -  12:00 pm,04:00 pm -  09:00 pm', '09:00 am -  12:00 pm,04:00 pm -  09:00 pm', '09:00 am -  12:00 pm,04:00 pm -  09:00 pm', '09:00 am -  12:00 pm,04:00 pm -  09:00 pm', '09:00 am -  12:00 pm,04:00 pm -  09:00 pm', '09:00 am -  04:00 pm'),
(5, NULL, '09:00 am -  12:00 pm,04:00 pm -  09:00 pm', '09:00 am -  12:00 pm,04:00 pm -  09:00 pm', '09:00 am -  12:00 pm,04:00 pm -  09:00 pm', '09:00 am -  12:00 pm,04:00 pm -  09:00 pm', '09:00 am -  12:00 pm,04:00 pm -  09:00 pm', '09:00 am -  04:00 pm'),
(6, NULL, '09:00 am -  12:00 pm,04:00 pm -  09:00 pm', '09:00 am -  12:00 pm,04:00 pm -  09:00 pm', '09:00 am -  12:00 pm,04:00 pm -  09:00 pm', '09:00 am -  12:00 pm,04:00 pm -  09:00 pm', '09:00 am -  12:00 pm,04:00 pm -  09:00 pm', '09:00 am -  04:00 pm'),
(7, NULL, '09:00 am -  12:00 pm,04:00 pm -  09:00 pm', '09:00 am -  12:00 pm,04:00 pm -  09:00 pm', '09:00 am -  12:00 pm,04:00 pm -  09:00 pm', '09:00 am -  12:00 pm,04:00 pm -  09:00 pm', '09:00 am -  12:00 pm,04:00 pm -  09:00 pm', '09:00 am -  04:00 pm'),
(8, NULL, '09:00 am -  12:00 pm,04:00 pm -  09:00 pm', '09:00 am -  12:00 pm,04:00 pm -  09:00 pm', '09:00 am -  12:00 pm,04:00 pm -  09:00 pm', '09:00 am -  12:00 pm,04:00 pm -  09:00 pm', '09:00 am -  12:00 pm,04:00 pm -  09:00 pm', '09:00 am -  04:00 pm');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` bigint(255) NOT NULL,
  `g_uid` bigint(255) NOT NULL,
  `did` bigint(255) NOT NULL,
  `review` text NOT NULL,
  `rating` int(1) NOT NULL,
  `recommend` int(1) NOT NULL,
  `r_date` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `g_uid`, `did`, `review`, `rating`, `recommend`, `r_date`) VALUES
(1, 1, 3, 'asdas', 5, 1, '24 Apr 2021'),
(2, 13, 3, 'sad', 2, 0, '22 Apr 2021'),
(3, 10, 3, 'asd', 2, 0, '20 Apr 2021'),
(4, 11, 3, 'ddd', 3, 1, '23 Apr 2021'),
(5, 12, 3, 'hhh', 4, 1, '25 Apr 2021'),
(7, 14, 3, 'dsdd', 5, 1, '16 Apr 2021'),
(13, 14, 1, 'good', 5, 1, '16 Apr 2021'),
(14, 1, 1, 'good', 5, 1, '18 Apr 2021'),
(15, 11, 1, 'nice', 5, 1, '18 Apr 2021'),
(16, 12, 1, 'bad', 1, 0, '18 Apr 2021'),
(17, 13, 1, 'note so good', 3, 3, '18 Apr 2021'),
(18, 11, 2, 'nice', 5, 1, '18 Apr 2021'),
(19, 12, 2, 'bad', 1, 0, '18 Apr 2021'),
(20, 13, 2, 'note so good', 3, 3, '18 Apr 2021'),
(21, 11, 4, 'nice', 5, 1, '18 Apr 2021'),
(22, 12, 4, 'bad', 1, 0, '18 Apr 2021'),
(23, 13, 4, 'note so good', 3, 3, '18 Apr 2021'),
(24, 11, 5, 'nice', 5, 1, '18 Apr 2021'),
(25, 12, 5, 'bad', 1, 0, '18 Apr 2021'),
(26, 13, 5, 'note so good', 3, 3, '18 Apr 2021'),
(27, 11, 6, 'nice', 5, 1, '18 Apr 2021'),
(28, 12, 6, 'bad', 1, 0, '18 Apr 2021'),
(29, 13, 6, 'note so good', 3, 3, '18 Apr 2021'),
(30, 11, 7, 'nice', 5, 1, '18 Apr 2021'),
(31, 12, 7, 'bad', 1, 0, '18 Apr 2021'),
(32, 13, 7, 'note so good', 3, 3, '18 Apr 2021'),
(33, 11, 8, 'nice', 5, 1, '18 Apr 2021'),
(34, 12, 8, 'bad', 1, 0, '18 Apr 2021'),
(35, 13, 8, 'note so good', 3, 3, '18 Apr 2021');

-- --------------------------------------------------------

--
-- Table structure for table `hospitals`
--

CREATE TABLE `hospitals` (
  `id` bigint(255) NOT NULL,
  `d_id` bigint(255) NOT NULL,
  `name` varchar(100) NOT NULL,
  `address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hospitals`
--

INSERT INTO `hospitals` (`id`, `d_id`, `name`, `address`) VALUES
(3, 1, 'Nijanand DENTAL CARE', '305-306, Oskar Complex, Opp. Rajlaxmi Bakery, Limda Lane, Near Lal Bungalow, Jamnagar-361001'),
(4, 2, 'City Dental Hospital', 'Virani chowk, 1 st Floor, Vidyanagar main road & Commisonor Bunglow road corner, Rajkot, Gujrat, India.'),
(5, 3, 'CIMS Hospital', 'Science City Rd, Science City, Panchamrut Bunglows II, Sola, Ahmedabad, Gujarat 380060'),
(6, 4, 'CIMS Hospital', 'Off Science City Road, Sola, Ahmedabad – 380060 Gujarat, INDIA'),
(7, 5, 'SVNM', 'swami vivekanand netra mandir 300-303/4th floor/shlok business centre B/s Apple Hospital, Ring Rd, Udhana Darwaja, Surat, Gujarat 395002'),
(8, 6, 'Namohari Orthopaedic Hospital ', '5 Jagannath Park, Near: Malav Lake, Jivraj Park ,  Ahmedabad'),
(9, 7, 'Artemis Hospital', ' Okhla road, Sukhdev Vihar Metro Station, New Delhi, Delhi '),
(10, 8, 'Arogyam Hospital', 'Plot No 14611, Mr Panchdec Mandir, Sector-22, Sector-22, Gandhinagar, Gujarat 382022');

-- --------------------------------------------------------

--
-- Table structure for table `medical_record`
--

CREATE TABLE `medical_record` (
  `id` bigint(255) NOT NULL,
  `pid` bigint(255) NOT NULL,
  `did` bigint(255) NOT NULL,
  `date` varchar(15) NOT NULL,
  `description` text DEFAULT NULL,
  `attachment` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `medical_record`
--

INSERT INTO `medical_record` (`id`, `pid`, `did`, `date`, `description`, `attachment`) VALUES
(4, 1, 3, '24/04/2021', 'General Checkup', '4.pdf'),
(5, 1, 3, '22/04/2021', 'General Checkup', '5.pdf'),
(6, 1, 4, '25 Apr 2021', 'General Checkup', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `id` bigint(255) NOT NULL,
  `user_id` bigint(255) NOT NULL,
  `img` varchar(10) NOT NULL DEFAULT 'defult.png',
  `blood_group` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `country` varchar(100) NOT NULL,
  `postal_code` varchar(6) NOT NULL,
  `favourite_did` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`id`, `user_id`, `img`, `blood_group`, `address`, `city`, `state`, `country`, `postal_code`, `favourite_did`) VALUES
(1, 1, '1.jpg', 'B+', 'Ploat no.203, Street no.6, GIDC', 'Jamnagar', 'Gujarat', 'India', '361005', '6,4,1,3,2'),
(2, 10, '10.jpg', 'A+', 'S–B, Suryoday Near D-Mart, 12, Chandrashekhar Azad Marg Bejanwala Complex, Adajan', 'Surat', 'Gujarat', 'India', '395003', NULL),
(3, 11, '11.jpg', 'B+', 'Toran Shopping Centre, Near Shri Nathji Sales, Baroda Pristage, Varachha Road Varachha Road', 'Ahmedabad', 'Gujarat', 'India', '380005', NULL),
(4, 12, '12.jpg', 'B-', 'Ascon City Complex (Opp) Maheshwari Bhavan CITYLIGHT ROAD', 'Ahmedabad', 'Gujarat', 'India', '380060', NULL),
(5, 13, '13.jpg', 'A-', ' falt no.144,Vidyanagar main road & Commisonor Bunglow road corner', 'Rajkot', 'Gujarat', 'India', '360005', NULL),
(6, 14, '14.jpg', 'O-', '1st Floor , Jilla Seva Sedan , Near HQ Post Office,', 'Gandhinagar', 'Gujarat', 'India', '382610', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `id` bigint(255) NOT NULL,
  `p_type` varchar(50) NOT NULL,
  `amount` int(255) NOT NULL,
  `is_paid` varchar(10) NOT NULL,
  `c_name` varchar(100) DEFAULT NULL,
  `c_no` varchar(16) DEFAULT NULL,
  `exm` varchar(2) DEFAULT NULL,
  `exy` varchar(2) DEFAULT NULL,
  `cvv` varchar(3) DEFAULT NULL,
  `upi` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`id`, `p_type`, `amount`, `is_paid`, `c_name`, `c_no`, `exm`, `exy`, `cvv`, `upi`) VALUES
(1, 'UPI', 110, 'y', NULL, NULL, NULL, NULL, NULL, '7486888595@upi'),
(2, 'Debit/Credit Card', 1010, 'y', 'Tushar Mungra', '1234567891234567', '11', '23', '333', NULL),
(3, 'COV', 5010, 'n', NULL, NULL, NULL, NULL, NULL, NULL),
(9, 'UPI', 1010, 'y', NULL, NULL, NULL, NULL, NULL, '7894561230@apl'),
(10, 'COV', 1010, 'n', NULL, NULL, NULL, NULL, NULL, NULL),
(11, 'COV', 1010, 'n', NULL, NULL, NULL, NULL, NULL, NULL),
(12, 'COV', 1010, 'n', NULL, NULL, NULL, NULL, NULL, NULL),
(13, 'Debit/Credit Card', 1010, 'y', 'Jenil Pansuriya', '1234567890147852', '04', '22', '156', ''),
(14, 'UPI', 1010, 'y', NULL, NULL, NULL, NULL, NULL, '8456123079@ybl'),
(15, 'COV', 1010, 'n', NULL, NULL, NULL, NULL, NULL, NULL),
(16, 'UPI', 1010, 'y', NULL, NULL, NULL, NULL, NULL, 'a@ypi'),
(17, 'UPI', 1010, 'y', NULL, NULL, NULL, NULL, NULL, 'a@ypi'),
(18, 'COV', 1010, 'n', NULL, NULL, NULL, NULL, NULL, NULL),
(19, 'COV', 210, 'n', NULL, NULL, NULL, NULL, NULL, NULL),
(20, 'COV', 110, 'n', NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `prescription`
--

CREATE TABLE `prescription` (
  `id` bigint(255) NOT NULL,
  `pid` bigint(255) NOT NULL,
  `did` bigint(255) NOT NULL,
  `date` varchar(15) DEFAULT NULL,
  `m_name` varchar(1000) DEFAULT NULL,
  `quantity` varchar(1000) DEFAULT NULL,
  `day` varchar(1000) DEFAULT NULL,
  `time` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `prescription`
--

INSERT INTO `prescription` (`id`, `pid`, `did`, `date`, `m_name`, `quantity`, `day`, `time`) VALUES
(1, 1, 3, '24 Apr 2021', 'CROCIN PAIN RELIEF@@Diphenhydramine', '1 tab@@2 tab', 'All@@All', 'Morning,Afternoon,Night@@Morning,Afternoon'),
(2, 1, 3, '24 Apr 2021', 'aa', '2', 'all', 'Morning'),
(3, 1, 4, '22 Apr 2021', 'bv', '1', 'All', 'Night');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(255) NOT NULL,
  `name` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `mobileno` varchar(10) NOT NULL,
  `email` varchar(30) NOT NULL,
  `gender` int(3) NOT NULL DEFAULT 0,
  `date_of_birth` date NOT NULL,
  `type` int(2) NOT NULL,
  `is_first_time` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `password`, `mobileno`, `email`, `gender`, `date_of_birth`, `type`, `is_first_time`) VALUES
(1, 'Sanket Mungra', 'Sk@123', '7778806784', 'bwind8082@gmail.com', 1, '2000-11-15', 1, 0),
(2, 'Sagar Bumtaria', 'Sa@123', '9427776565', 'sagarbumtaria@gmail.com', 1, '1968-04-17', 2, 0),
(3, 'Rashmi Jasani', 'Ra@123', '9428225282', 'rashmijasani@gmail.com', 2, '1966-07-13', 2, 0),
(4, 'Keyur Parikh', 'Ke@123', '9825026999', 'keyur.parikh@cims.org', 1, '1958-05-13', 2, 0),
(5, 'RUPESH SHAH', 'Ru@123', '9099838777', 'rupesh.shah@cims.org', 1, '1982-02-08', 2, 0),
(6, 'Sarita S. Begani', 'Sa@123', '9562483105', 'saritabegani@gmail.com', 2, '1978-03-17', 2, 0),
(7, ' Snehal J Shah ', 'Sn@123', '7485961234', 'snehalhah@gmail.com', 2, '1986-06-17', 2, 0),
(8, 'Vinny Sood', 'Vi@123', '7514863025', 'vinnysood@gmail.com', 2, '1982-03-18', 2, 0),
(9, 'Kunal Aterkar', 'Ku@123', '9632587410', 'kunalaterkar@outlook.com', 1, '1985-05-17', 2, 0),
(10, 'Trushant Limbani', 'Tr@123', '9856321478', 'tru@gmail.com', 1, '1996-06-17', 1, 0),
(11, 'Jenil Pansuriya', 'Je@123', '7845123690', 'jenil@gmail.com', 1, '2001-07-19', 1, 0),
(12, 'Henis Nakrani', 'He@123', '8456123079', 'henis@gmail.com', 1, '1999-08-21', 1, 0),
(13, 'Aadhya Patel', 'Aa@123', '7894561230', 'aadhya@gmail.com', 2, '2000-10-27', 1, 0),
(14, 'Aanya  Patel', 'Aa@123', '9562314789', 'anya@gmail.com', 2, '1999-02-06', 1, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `f_did` (`did`),
  ADD KEY `f_patment_id` (`payment_id`),
  ADD KEY `f_pid` (`pid`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fdid_uid_delete` (`user_id`);

--
-- Indexes for table `doctor_timing`
--
ALTER TABLE `doctor_timing`
  ADD KEY `f_dtiming_did` (`did`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ff_guid` (`g_uid`),
  ADD KEY `ff_did` (`did`);

--
-- Indexes for table `hospitals`
--
ALTER TABLE `hospitals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fhid_did` (`d_id`);

--
-- Indexes for table `medical_record`
--
ALTER TABLE `medical_record`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fm_pid` (`pid`),
  ADD KEY `fm_did` (`did`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`id`),
  ADD KEY `f_pid_userid` (`user_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prescription`
--
ALTER TABLE `prescription`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pf_pid` (`pid`),
  ADD KEY `pf_did` (`did`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `id` bigint(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `id` bigint(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` bigint(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `hospitals`
--
ALTER TABLE `hospitals`
  MODIFY `id` bigint(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `medical_record`
--
ALTER TABLE `medical_record`
  MODIFY `id` bigint(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `id` bigint(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `id` bigint(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `prescription`
--
ALTER TABLE `prescription`
  MODIFY `id` bigint(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointments`
--
ALTER TABLE `appointments`
  ADD CONSTRAINT `f_did` FOREIGN KEY (`did`) REFERENCES `doctor` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `f_patment_id` FOREIGN KEY (`payment_id`) REFERENCES `payment` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `f_pid` FOREIGN KEY (`pid`) REFERENCES `patient` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `doctor`
--
ALTER TABLE `doctor`
  ADD CONSTRAINT `fdid_uid_delete` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fdid_uid_update` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `doctor_timing`
--
ALTER TABLE `doctor_timing`
  ADD CONSTRAINT `f_dtiming_did` FOREIGN KEY (`did`) REFERENCES `doctor` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `ff_did` FOREIGN KEY (`did`) REFERENCES `doctor` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ff_guid` FOREIGN KEY (`g_uid`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `hospitals`
--
ALTER TABLE `hospitals`
  ADD CONSTRAINT `fhid_did` FOREIGN KEY (`d_id`) REFERENCES `doctor` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `medical_record`
--
ALTER TABLE `medical_record`
  ADD CONSTRAINT `fm_did` FOREIGN KEY (`did`) REFERENCES `doctor` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fm_pid` FOREIGN KEY (`pid`) REFERENCES `patient` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `patient`
--
ALTER TABLE `patient`
  ADD CONSTRAINT `f_pid_userid` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `prescription`
--
ALTER TABLE `prescription`
  ADD CONSTRAINT `pf_did` FOREIGN KEY (`did`) REFERENCES `doctor` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `pf_pid` FOREIGN KEY (`pid`) REFERENCES `patient` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
