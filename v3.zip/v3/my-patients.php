<?php include 'includes/session.php'; ?>
<?php
$conn = $pdo->open();
		try{
		$stmt = $conn->prepare("SELECT img,name,degree FROM doctor as d JOIN users WHERE d.user_id = users.id AND users.id=:uid");
		$stmt->execute([":uid"=>$user['id']]);
		$row = $stmt->fetch();
		}
		catch(PDOException $e){
			$_SESSION['error'] = $e->getMessage();
		}
		$pdo->close();
?>
<!DOCTYPE html> 
<html lang="en">
	
<head>
		<meta charset="utf-8">
		<title>NearPsy</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
		
		<!-- Favicons -->
		<link href="assets/img/favicon.png" rel="icon">
		
		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="assets/css/bootstrap.min.css">
		
		<!-- Fontawesome CSS -->
		<link rel="stylesheet" href="assets/plugins/fontawesome/css/fontawesome.min.css">
		<link rel="stylesheet" href="assets/plugins/fontawesome/css/all.min.css">
		
		<!-- Main CSS -->
		<link rel="stylesheet" href="assets/css/style.css">

	</head>
	<body>

		<!-- Main Wrapper -->
		<div class="main-wrapper">
		
			<!-- Header -->
			<?php include 'includes/navbar.php'; ?>
			<!-- /Header -->
			
			<!-- Breadcrumb -->
			<div class="breadcrumb-bar">
				<div class="container-fluid">
					<div class="row align-items-center">
						<div class="col-md-12 col-12">
							<nav aria-label="breadcrumb" class="page-breadcrumb">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="index.php">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">My Patients</li>
								</ol>
							</nav>
							<h2 class="breadcrumb-title">My Patients</h2>
						</div>
					</div>
				</div>
			</div>
			<!-- /Breadcrumb -->
			
			<!-- Page Content -->
			<div class="content">
				<div class="container-fluid">

					<div class="row">
						<div class="col-md-5 col-lg-4 col-xl-3 theiaStickySidebar">
						
							<!-- Profile Sidebar -->
							<?php include 'includes/doc-profile-sidebar.php'; ?>
							<!-- /Profile Sidebar -->
							
						</div>
						<div class="col-md-7 col-lg-8 col-xl-9">
						
							<div class="row row-grid">
								<?php
								$conn = $pdo->open();
									try{
										$pstmt = $conn->prepare("SELECT DISTINCT pid FROM doctor as d JOIN users JOIN appointments WHERE d.user_id = users.id AND appointments.did=d.id AND users.id=:uid AND (status='Confirm' OR status='Completed')");
										$pstmt->execute([":uid"=>$user['id']]);
										$stmt = $conn->prepare("SELECT img,name,city,state,mobileno,gender,date_of_birth,blood_group FROM patient JOIN users WHERE users.id=patient.user_id AND patient.id=:pid");
										}
										catch(PDOException $e){
											$_SESSION['error'] = $e->getMessage();
										}
									$pdo->close();
									foreach($pstmt as $r){
										$stmt->execute([":pid"=>$r['pid']]);
										$row=$stmt->fetch();
										$age= date_diff(date_create($row['date_of_birth']), date_create(date("Y-m-d")));
										$age= $age->format('%y');
								echo'
								<div class="col-md-6 col-lg-4 col-xl-3">
									<div class="card widget-profile pat-widget-profile">
										<div class="card-body">
											<div class="pro-widget-content">
												<div class="profile-info-widget">
													<a href="patient-profile.php?pid='.$r['pid'].'" class="booking-doc-img">
														<img src="assets/img/patients/'.$row['img'].'" alt="User Image">
													</a>
													<div class="profile-det-info">
														<h3><a href="patient-profile.php?pid='.$r['pid'].'">'.$row['name'].'</a></h3>
														
														<div class="patient-details">
															<h5><b>Patient ID :</b> P'.$r['pid'].'</h5>
															<h5 class="mb-0"><i class="fas fa-map-marker-alt"></i> '.$row['city'].', '.$row['state'].'</h5>
														</div>
													</div>
												</div>
											</div>
											<div class="patient-info">
												<ul>
													<li>Phone <span>+91 '.$row['mobileno'].'</span></li>
													<li>Age <span>'.$age.' Years, '.(($row['gender']==1)?'Male':'Female').'</span></li>
													<li>Blood Group <span>'.$row['blood_group'].'</span></li>
												</ul>
											</div>
										</div>
									</div>
								</div>';}?>
																
							</div>

						</div>
					</div>

				</div>

			</div>		
			<!-- /Page Content -->
   
			<!-- Footer -->
			<?php include 'includes/footer.php'; ?>
			<!-- /Footer -->
		   
		</div>
		<!-- /Main Wrapper -->
	  
		<!-- jQuery -->
		<script src="assets/js/jquery.min.js"></script>
		
		<!-- Bootstrap Core JS -->
		<script src="assets/js/popper.min.js"></script>
		<script src="assets/js/bootstrap.min.js"></script>
		
		<!-- Sticky Sidebar JS -->
        <script src="assets/plugins/theia-sticky-sidebar/ResizeSensor.js"></script>
        <script src="assets/plugins/theia-sticky-sidebar/theia-sticky-sidebar.js"></script>
		
		<!-- Custom JS -->
		<script src="assets/js/script.js"></script>
		
	</body>
</html>