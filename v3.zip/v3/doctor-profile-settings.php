<?php include 'includes/session.php'; ?>
<?php
	if(!isset($_SESSION['user'])){
		header('location: index.php');
	}
?>
<?php
$conn = $pdo->open();
try{
$stmt = $conn->prepare("SELECT * FROM doctor as d JOIN users WHERE d.user_id = users.id AND users.id=:uid");
$stmt->execute([":uid"=>$user['id']]);
$row = $stmt->fetch();
$stmt = $conn->prepare("SELECT hospitals.name,hospitals.address FROM hospitals JOIN doctor WHERE d_id=doctor.id AND doctor.user_id=:uid");
$stmt->execute([":uid"=>$user['id']]);
$row1 = $stmt->fetch();

}
catch(PDOException $e){
			$_SESSION['error'] = $e->getMessage();
}
$pdo->close();
?>

<!DOCTYPE html> 
<html lang="en">
<head>

		<meta charset="utf-8">
		<title>OHAS</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
		
		<!-- Favicons -->
		<link href="assets/img/favicon.png" rel="icon">
		
		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="assets/css/bootstrap.min.css">
		
		<!-- Fontawesome CSS -->
		<link rel="stylesheet" href="assets/plugins/fontawesome/css/fontawesome.min.css">
		<link rel="stylesheet" href="assets/plugins/fontawesome/css/all.min.css">
		
		<!-- Datetimepicker CSS -->
		<link rel="stylesheet" href="assets/css/bootstrap-datetimepicker.min.css">

		<!-- Select2 CSS -->
		<link rel="stylesheet" href="assets/plugins/select2/css/select2.min.css">
		
		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="assets/plugins/bootstrap-tagsinput/css/bootstrap-tagsinput.css">
		
		<link rel="stylesheet" href="assets/plugins/dropzone/dropzone.min.css">
		
		<!-- Main CSS -->
		<link rel="stylesheet" href="assets/css/style.css">
	
	</head>
	<body>

		<!-- Main Wrapper -->
		<div class="main-wrapper">
		
			<!-- Header -->
			<?php include 'includes/navbar.php'; ?>
			<!-- /Header -->
			
			<!-- Breadcrumb -->
			<div class="breadcrumb-bar">
				<div class="container-fluid">
					<div class="row align-items-center">
						<div class="col-md-12 col-12">
							<nav aria-label="breadcrumb" class="page-breadcrumb">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="index.php">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Profile Settings</li>
								</ol>
							</nav>
							<h2 class="breadcrumb-title">Profile Settings</h2>
						</div>
					</div>
				</div>
			</div>
			<!-- /Breadcrumb -->
			
			<!-- Page Content -->
			<div class="content">
				<div class="container-fluid">
						<div>
						<?php
						      if(isset($_SESSION['error'])){
						        echo "
						          <div class='callout callout-danger text-center'>
						            <p>".$_SESSION['error']."</p><br> 
						          </div>
						        ";
						        unset($_SESSION['error']);
						      }
						      if(isset($_SESSION['success'])){
						        echo "
						          <div class='callout callout-success text-center'>
						            <p>".$_SESSION['success']."</p><br>
						          </div>
						        ";
						        unset($_SESSION['success']);
						      }
						?>
						</div>
					<div class="row">
						<div class="col-md-5 col-lg-4 col-xl-3 theiaStickySidebar">
						
							<!-- Profile Sidebar -->
							<?php include 'includes/doc-profile-sidebar.php'; ?>
							<!-- /Profile Sidebar -->
							
						</div>
						<div class="col-md-7 col-lg-8 col-xl-9">
						
							<!-- Basic Information -->
							<div class="card">
								<div class="card-body">
									<h4 class="card-title">Basic Information</h4>
									<div class="row form-row">
										<div class="col-md-12">
											<div class="form-group">
												<div class="change-avatar">
													<div class="profile-img">
														<img src="assets/img/doctors/<?php echo $row['img'];?>" alt="User Image">
													</div>
													<form action="upload.php" method="POST" enctype="multipart/form-data">
													<div class="upload-img">
														<div class="change-photo-btn">
															<span><i class="fa fa-upload"></i> Select Photo</span>
															<input type="file" class="upload" name="fileToUpload" id="fileToUpload">

														</div><button type="submit" class="change-photo-btn" style="border:none;" name="upload">Upload</button>
														<small class="form-text text-muted">Allowed JPG, GIF or PNG. Max size of 2MB</small>
													</div>
												</div>
											</div>
										</div>
										</form>
										
										<div class="col-md-6">
											<div class="form-group">
												<form action="doc_update.php" method="POST">
												<label>Name <span class="text-danger"> *</span></label>
												<input type="text" class="form-control" value="<?php echo $row['name'];?>" name="name" required pattern="[a-zA-Z .]{3,}" oninvalid="this.setCustomValidity('Name shoud be atleast 3 Charcter long')" oninput="this.setCustomValidity('')">
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label>Email <span class="text-danger"> *</span></label>
												<input type="email" class="form-control" value="<?php echo $row['email'];?>" name="email" required pattern="^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$" oninvalid="this.setCustomValidity('Plase Enter Valid Email Address')" oninput="this.setCustomValidity('')">
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label>Phone Number <span class="text-danger"> *</span></label>
												<input type="text" class="form-control" value="<?php echo $row['mobileno'];?>" name="mobileno" required pattern="[0-9]{10}" oninvalid="this.setCustomValidity('Plase Enter your 10 digit mobile No.')" oninput="this.setCustomValidity('')">
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label>Gender <span class="text-danger"> *</span></label>
												<select class="form-control select" name="gender" required oninvalid="this.setCustomValidity('Plase Select Gender')" onchange="this.setCustomValidity('')">
													<option value="" <?php echo ($row['gender']==0)?'selected':''; ?>>Select</option>
													<option value="1" <?php echo ($row['gender']==1)?'selected':''; ?>>Male</option>
													<option value="2" <?php echo ($row['gender']==2)?'selected':''; ?>>Female</option>
												</select>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group mb-0">
												<label>Date of Birth <span class="text-danger"> *</span></label>
												<div class="cal-icon">
														<input type="text" class="form-control datetimepicker" value="<?php echo date("d/m/Y",strtotime($row['date_of_birth']));?>" required name="dob" oninvalid="this.setCustomValidity('Plase Enter Date of Birth')" onchange="this.setCustomValidity('')">
												</div>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group mb-0">
												<label>Medical Speciality <span class="text-danger"> *</span></label>
												<input type="text" class="form-control" value="<?php echo $row['doc_type'];?>" required name="doc_type" oninvalid="this.setCustomValidity('Plase Enter Area of your Specialization')" onchange="this.setCustomValidity('')">
											</div>
										</div>
									</div>
								</div>
							</div>
							<!-- /Basic Information -->
							
							<!-- About Me -->
							<div class="card">
								<div class="card-body">
									<h4 class="card-title">About Me</h4>
									<div class="form-group mb-0">
										<label>Biography</label>
										<textarea class="form-control" rows="5" name="bio"><?php echo ($row['about_me'] == null)? '': $row['about_me']; ?></textarea>
									</div>
								</div>
							</div>
							<!-- /About Me -->
							
							<!-- Clinic Info -->
							<div class="card">
								<div class="card-body">
									<h4 class="card-title">Clinic Info</h4>
									<div class="row form-row">
										<div class="col-md-6">
											<div class="form-group">
												<label>Clinic Name</label>
												<input type="text" class="form-control" value="<?php echo (isset($row1['name']))? $row1['name']:'' ;?>" name="cname">
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label>Clinic Address</label>
												<input type="text" class="form-control" value="<?php echo (isset($row1['address']))? $row1['address']:'' ;?>" name="cadd">
											</div>
										</div>
									</div>
								</div>
							</div>
							<!-- /Clinic Info -->

							<!-- Contact Details -->
							<div class="card contact-card">
								<div class="card-body">
									<h4 class="card-title">Contact Details</h4>
									<div class="row form-row">
										<div class="col-md-6">
											<div class="form-group">
												<label>Address Line 1</label>
												<input type="text" class="form-control" name="address_line_1" value="<?php echo $row['address_line_1'];?>">
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label class="control-label">Address Line 2</label>
												<input type="text" class="form-control" name="address_line_2" value="<?php echo $row['address_line_2'];?>">
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label class="control-label">City</label>
												<input type="text" class="form-control" name="city" value="<?php echo $row['city'];?>">
											</div>
										</div>

										<div class="col-md-6">
											<div class="form-group">
												<label class="control-label">State / Province</label>
												<input type="text" class="form-control" name="state" value="<?php echo $row['state'];?>">
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label class="control-label">Country</label>
												<input type="text" class="form-control" name="country" value="<?php echo $row['country'];?>">
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label class="control-label">Postal Code</label>
												<input type="text" class="form-control" name="postal_code" value="<?php echo $row['postal_code'];?>" pattern="[0-9]{6}" oninvalid="this.setCustomValidity('Plase Enter Valid Postal Code')" onchange="this.setCustomValidity('')">
											</div>
										</div>
									</div>
								</div>
							</div>
							<!-- /Contact Details -->
							
							<!-- Pricing -->
							<div class="card">
								<div class="card-body">
									<h4 class="card-title">Pricing</h4>
									<div class="col-md-6">
										<div class="form-group">
										<label class="control-label">Fee Range</label>
										<input type="text" class="form-control" name="fee" value="<?php echo $row['fees'];?>">
										</div>
									</div>
								</div>
							</div>
							<!-- /Pricing -->
							
							<!-- Services and Specialization -->
							<div class="card services-card">
								<div class="card-body">
									<h4 class="card-title">Services and Specialization</h4>
									<div class="form-group">
										<label>Services</label>
										<input type="text" data-role="tagsinput" class="input-tags form-control" placeholder="Enter Services" name="services" value="<?php echo $row['services'];?>" id="services">
										<small class="form-text text-muted">Note : Type & Press enter to add new services</small>
									</div> 
									<div class="form-group mb-0">
										<label>Specialization </label>
										<input class="input-tags form-control" type="text" data-role="tagsinput" placeholder="Enter Specialization" name="specialist" value="<?php echo $row['specializations'];?>" id="specialist">
										<small class="form-text text-muted">Note : Type & Press  enter to add new specialization</small>
									</div> 
								</div>              
							</div>
							<!-- /Services and Specialization -->

							<!-- Education -->
							<div class="card">
								<div class="card-body">
									<h4 class="card-title">Education</h4>
									<div class="education-info" id="education-info">
										 <?php
										 if(!is_null($row['degree'])){
										 $degree=explode("@@",$row['degree']);
										 $institute=explode("@@",$row['institute']);
										 $year_of_completion=explode("@@",$row['year_of_completion']);
										 $no_ed=count($degree);
									for($i=0;$i<$no_ed;$i++){ echo '
										<div class="row form-row education-cont">
											<div class="col-12 col-md-10 col-lg-11">
												<div class="row form-row">
													<div class="col-12 col-md-6 col-lg-4">
														<div class="form-group"><label>Degree</label>
															<input type="text" class="form-control" id="degree_'.$i.'" name="degree_'.$i.'" value="'.$degree[$i].'"></div></div>
															<div class="col-12 col-md-6 col-lg-4">
																<div class="form-group"><label>College/Institute</label>
																	<input type="text" class="form-control" id="institute_'.$i.'" name="institute_'.$i.'" value="'.$institute[$i].'"></div></div>
																	<div class="col-12 col-md-6 col-lg-4"><div class="form-group"><label>Duration</label>
																		<input type="text" class="form-control" id="year_of_completion_'.$i.'" name="year_of_completion_'.$i.'" value="'.$year_of_completion[$i].'"></div></div></div></div>
																		<div class="col-12 col-md-2 col-lg-1"><label class="d-md-block d-sm-none d-none">&nbsp;</label>
																<button class="btn btn-danger " id="tb_'.$i.'"><i class="far fa-trash-alt"></i></button></div></div>
									';}}?>
									<input type="hidden" name="no_ed" value="<?php echo $no_ed;?>">
									<div class="add-more">
										<a href="#none" onclick="add_new_edu()" ><i class="fa fa-plus-circle"></i> Add More</a>
									</div>
									</div>
								</div>
							</div>
							<script type="text/javascript">
								function add_new_edu() {
									
								 var b = document.createElement("div");
								   b.innerHTML='<div class="row form-row education-cont"><div class="col-12 col-md-10 col-lg-11"><div class="row form-row"><div class="col-12 col-md-6 col-lg-4"><div class="form-group"><label>Degree</label><input type="text" class="form-control" id="add_edu_deg"></div></div><div class="col-12 col-md-6 col-lg-4"><div class="form-group"><label>College/Institute</label><input type="text" class="form-control" id="add_edu_int"></div></div><div class="col-12 col-md-6 col-lg-4"><div class="form-group"><label>Duration</label><input type="text" class="form-control" id="add_edu_year"></div></div></div></div><div class="col-12 col-md-2 col-lg-1"><label class="d-md-block d-sm-none d-none">&nbsp;</label><button id="add_edu" class="btn btn-success" >Add</button></div></div>'
								   
								   var element = document.getElementById("education-info");
								   element.appendChild(b);}
							</script>

							
							<!-- /Education -->
						
							<!-- Experience -->
							<div class="card">
								<div class="card-body">
									<h4 class="card-title">Experience</h4>
									<div class="experience-info" id="experience-info">

										<?php
										 if(!is_null($row['h_name'])){
										 $hname=explode("@@",$row['h_name']);
										 $time=explode("@@",$row['etime']);
										 $designation=explode("@@",$row['designation']);
										 $no_we=count($hname);
									for($i=0;$i<$no_we;$i++){ echo '
										<div class="row form-row experience-cont">
											<div class="col-12 col-md-10 col-lg-11">
												<div class="row form-row">
													<div class="col-12 col-md-6 col-lg-4">
														<div class="form-group"><label>Hospital Name</label>
															<input type="text" class="form-control" id="hname_'.$i.'" name="hname_'.$i.'" value="'.$hname[$i].'"></div></div>
															<div class="col-12 col-md-6 col-lg-4">
																<div class="form-group"><label>From-To</label>
																	<input type="text" class="form-control" id="time_'.$i.'" name="etime_'.$i.'" value="'.$time[$i].'"></div></div>
																	<div class="col-12 col-md-6 col-lg-4"><div class="form-group"><label>Designation</label>
																		<input type="text" class="form-control" id="designation_'.$i.'" name="designation_'.$i.'" value="'.$designation[$i].'"></div></div></div></div>
																		<div class="col-12 col-md-2 col-lg-1"><label class="d-md-block d-sm-none d-none">&nbsp;</label>
																<button class="btn btn-danger" id="we_'.$i.'"><i class="far fa-trash-alt"></i></button></div></div>
									';}}?>
									</div>
									<input type="hidden" name="no_we" value="<?php echo $no_we;?>">
									<div class="add-more">
										<a href="#none" onclick="add_new_we()" ><i class="fa fa-plus-circle"></i> Add More</a>
									</div>
								</div>
							</div>
							<script type="text/javascript">
								function add_new_we() {
									
								 var b = document.createElement("div");
								   b.innerHTML='<div class="row form-row experience-cont"><div class="col-12 col-md-10 col-lg-11"><div class="row form-row"><div class="col-12 col-md-6 col-lg-4"><div class="form-group"><label>Hospital Name</label><input type="text" class="form-control" id="add_hn"></div></div><div class="col-12 col-md-6 col-lg-4"><div class="form-group"><label>From-To</label><input type="text" class="form-control" id="add_time"></div></div><div class="col-12 col-md-6 col-lg-4"><div class="form-group"><label>Designation</label><input type="text" class="form-control" id="add_des"></div></div></div></div><div class="col-12 col-md-2 col-lg-1"><label class="d-md-block d-sm-none d-none">&nbsp;</label><button id="add_we" class="btn btn-success" >Add</button></div></div>'
								   
								   var element = document.getElementById("experience-info");
								   element.appendChild(b);}
							</script>
							<!-- /Experience -->
							
							<!-- Awards -->
							<div class="card">
								<div class="card-body">
									<h4 class="card-title">Awards</h4>
									<div class="awards-info" id="awards-info">
										<?php
										 if(!is_null($row['award'])){
										 $award=explode("@@",$row['award']);
										 $a_year=explode("@@",$row['a_year']);
										 $no_aw=count($award);
										for($i=0;$i<$no_aw;$i++){ echo '
										<div class="row form-row awards-cont"><div class="col-12 col-md-5"><div class="form-group"><label>Awards</label><input type="text" class="form-control" id="award_'.$i.'" name="award_'.$i.'" value="'.$award[$i].'"></div></div><div class="col-12 col-md-5"><div class="form-group"><label>Year</label><input type="text" class="form-control" id="a_year_'.$i.'" name="a_year_'.$i.'" value="'.$a_year[$i].'"></div></div><div class="col-12 col-md-2"><label class="d-md-block d-sm-none d-none">&nbsp;</label><button id="aw_'.$i.'" class="btn btn-danger" ><i class="far fa-trash-alt"></i></button></div></div>'
										;}}?>
									</div>
									<input type="hidden" name="no_aw" value="<?php echo $no_aw;?>">
									<div class="add-more">
										<a href="#none" onclick="add_new_awd()"><i class="fa fa-plus-circle"></i> Add More</a>
									</div>
								</div>
							
							</div>
							<script type="text/javascript">
								function add_new_awd() {
								 var b = document.createElement("div");
								   b.innerHTML='<div class="row form-row awards-cont"><div class="col-12 col-md-5"><div class="form-group"><label>Awards</label><input type="text" class="form-control" id="add_awd_award"></div></div><div class="col-12 col-md-5"><div class="form-group"><label>Year</label><input type="text" class="form-control" id="add_awd_ayear"></div></div><div class="col-12 col-md-2"><label class="d-md-block d-sm-none d-none">&nbsp;</label><button id="add_awd" class="btn btn-success" >Add</button></div></div>'
								   
								   var element = document.getElementById("awards-info");
								   element.appendChild(b);}
							</script>
							<!-- /Awards -->
							
							<div class="submit-section submit-btn-bottom">
								<button type="submit" class="btn btn-primary submit-btn" name="update">Save Changes</button>
							</div>
							</form>
						</div>
					</div>

				</div>

			</div>
			<!-- /Page Content -->
   
			<!-- Footer -->
			<?php include 'includes/footer.php'; ?>
			
			<!-- /Footer -->
		   
		</div>
		<!-- /Main Wrapper -->
	   
		<!-- jQuery -->
		<script src="assets/js/jquery.min.js"></script>
		
		<!-- Bootstrap Core JS -->
		<script src="assets/js/popper.min.js"></script>
		<script src="assets/js/bootstrap.min.js"></script>
		
		<!-- Sticky Sidebar JS -->
        <script src="assets/plugins/theia-sticky-sidebar/ResizeSensor.js"></script>
        <script src="assets/plugins/theia-sticky-sidebar/theia-sticky-sidebar.js"></script>

        <!-- Datetimepicker JS -->
		<script src="assets/js/moment.min.js"></script>
		<script src="assets/js/bootstrap-datetimepicker.min.js"></script>
		
		<!-- Select2 JS -->
		<script src="assets/plugins/select2/js/select2.min.js"></script>
		
		<!-- Dropzone JS -->
		<script src="assets/plugins/dropzone/dropzone.min.js"></script>
		
		<!-- Bootstrap Tagsinput JS -->
		<script src="assets/plugins/bootstrap-tagsinput/js/bootstrap-tagsinput.js"></script>
		
		<!-- Profile Settings JS -->
		<script src="assets/js/profile-settings.js"></script>
		
		<!-- Custom JS -->
		<script src="assets/js/script.js"></script>
<script type="text/javascript">
	$(document).on('click', '#add_edu', function(e){
    e.preventDefault();
    var deg = $('#add_edu_deg').val();
    var int = $('#add_edu_int').val();
    var year = $('#add_edu_year').val();
    var mode='insert';

    $.ajax({
      type: 'POST',
      url: 'update_edu.php',
      data: {deg:deg,int:int,year:year,mode:mode},
      dataType: 'json',
      success: function(response){
        if(!response.error){
          location.reload();
          
        }
      }
    });
  });

	$(document).on('click', '#add_awd', function(e){
    e.preventDefault();
    var award = $('#add_awd_award').val();
    var ayear = $('#add_awd_ayear').val();
    var mode='insert';
    $.ajax({
      type: 'POST',
      url: 'update_awd.php',
      data: {award:award,ayear:ayear,mode:mode},
      dataType: 'json',
      success: function(response){

        if(!response.error){

          location.reload();
          
        }
      }
    });
  });

	$(document).on('click', '#add_we', function(e){
    e.preventDefault();
    var hn = $('#add_hn').val();
    var etime = $('#add_time').val();
    var des = $('#add_des').val();
    var mode='insert';

    $.ajax({
      type: 'POST',
      url: 'update_we.php',
      data: {hn:hn,etime:etime,des:des,mode:mode},
      dataType: 'json',
      success: function(response){
        if(!response.error){
          location.reload();
          
        }
      }
    });
  });
</script>

<script type='text/javascript'>
<?php for($i=0;$i<$no_aw;$i++){
echo"

	$(document).on('click','#aw_".$i."',function(e){
		e.preventDefault();
    var award = $('#award_".$i."').val();
    var ayear = $('#a_year_".$i."').val();
    var mode='delete';
    $.ajax({
      type: 'POST',
      url: 'update_awd.php',
      data: {award:award,ayear:ayear,mode:mode},
      dataType: 'json',
      success: function(response){
        if(!response.error){
          location.reload(); 
        }
      }
    });
  });
	";
							
}?>
</script>

<script type='text/javascript'>
<?php for($i=0;$i<$no_ed;$i++){
echo"

	$(document).on('click','#tb_".$i."',function(e){
		e.preventDefault();
    var deg = $('#degree_".$i."').val();
    var int = $('#institute_".$i."').val();
    var year = $('#year_of_completion_".$i."').val();
    var mode='delete';
    $.ajax({
      type: 'POST',
      url: 'update_edu.php',
      data: {deg:deg,int:int,year:year,mode:mode},
      dataType: 'json',
      success: function(response){
        if(!response.error){
          location.reload(); 
        }
      }
    });
  });
";}?>
	</script>

	<script type='text/javascript'>
<?php for($i=0;$i<$no_we;$i++){
echo"

	$(document).on('click','#we_".$i."',function(e){
		e.preventDefault();
    var hn = $('#hname_".$i."').val();
    var etime = $('#time_".$i."').val();
    var des = $('#designation_".$i."').val();
    var mode='delete';
    $.ajax({
      type: 'POST',
      url: 'update_we.php',
      data: {hn:hn,etime:etime,des:des,mode:mode},
      dataType: 'json',
      success: function(response){
        if(!response.error){
          location.reload(); 
        }
      }
    });
  });
	";
							
}?>
</script>
	</body>
</html>