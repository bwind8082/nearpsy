<?php include 'includes/session.php'; ?>
<?php
$conn = $pdo->open();
$output = array('error'=>false,'message'=>'');

$stmt = $conn->prepare("UPDATE appointments set status=:status where id=:aid");

try{
	if($_POST['mode']=='accept')		
		$stmt->execute([':status'=>"Confirm",':aid'=>$_POST['aid']]);
	elseif($_POST['mode']=='completed')
		$stmt->execute([':status'=>"Completed",':aid'=>$_POST['aid']]);
	else
		$stmt->execute([':status'=>"Cancelled",':aid'=>$_POST['aid']]);
	}	
	catch(PDOException $e){
	$output['error']=true;
	$output['message'] = $e->getMessage();
	}

$pdo->close();
	echo json_encode($output);
?>