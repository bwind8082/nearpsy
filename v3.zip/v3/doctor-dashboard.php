<?php include 'includes/session.php'; ?>
<?php
$conn = $pdo->open();
		try{
		$stmt = $conn->prepare("SELECT img,name,degree FROM doctor as d JOIN users WHERE d.user_id = users.id AND users.id=:uid");
		$stmt->execute([":uid"=>$user['id']]);
		$row = $stmt->fetch();
		}
		catch(PDOException $e){
			$_SESSION['error'] = $e->getMessage();
		}
		$pdo->close();
?>

<!DOCTYPE html> 
<html lang="en">
	
<head>
		<meta charset="utf-8">
		<title>NearPsy</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
		
		<!-- Favicons -->
		<link href="assets/img/favicon.png" rel="icon">
		
		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="assets/css/bootstrap.min.css">
		
		<!-- Fontawesome CSS -->
		<link rel="stylesheet" href="assets/plugins/fontawesome/css/fontawesome.min.css">
		<link rel="stylesheet" href="assets/plugins/fontawesome/css/all.min.css">
		
		<!-- Main CSS -->
		<link rel="stylesheet" href="assets/css/style.css">
	
	</head>
	<body>

		<!-- Main Wrapper -->
		<div class="main-wrapper">
		
			<!-- Header -->
			<?php include 'includes/navbar.php'; ?>
			<!-- /Header -->
			
			<!-- Breadcrumb -->
			<div class="breadcrumb-bar">
				<div class="container-fluid">
					<div class="row align-items-center">
						<div class="col-md-12 col-12">
							<nav aria-label="breadcrumb" class="page-breadcrumb">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="index.php">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Dashboard</li>
								</ol>
							</nav>
							<h2 class="breadcrumb-title">Dashboard</h2>
						</div>
					</div>
				</div>
			</div>
			<!-- /Breadcrumb -->
			
			<!-- Page Content -->
			<div class="content">
				<div class="container-fluid">

					<div class="row">
						<div class="col-md-5 col-lg-4 col-xl-3 theiaStickySidebar">
							
							<!-- Profile Sidebar -->
							<?php include 'includes/doc-profile-sidebar.php'; ?>
							<!-- /Profile Sidebar -->
							
						</div>
<?php
$conn = $pdo->open();
	try{
		$stmt = $conn->prepare("SELECT count(appointments.id) as tap FROM doctor as d JOIN users JOIN appointments WHERE d.user_id = users.id AND appointments.did=d.id AND users.id=:uid AND status!='Cancelled'");
		$stmt->execute([":uid"=>$user['id']]);
		$row = $stmt->fetch();
		$tap_of_doc=$row['tap'];
		$stmt = $conn->prepare("SELECT count(appointments.id) as tap FROM appointments");
		$stmt->execute();
		$row = $stmt->fetch();
		$tap=$row['tap'];
		$stmt = $conn->prepare("SELECT count(appointments.id) as tap FROM doctor as d JOIN users JOIN appointments WHERE d.user_id = users.id AND appointments.did=d.id AND users.id=:uid AND a_date=:today AND status!='Cancelled'");
		$today=date("d M Y");
		$stmt->execute([":uid"=>$user['id'],":today"=>$today]);
		$row = $stmt->fetch();
		$today_patient=$row['tap'];
		$stmt = $conn->prepare("SELECT count(appointments.id) as ucp FROM doctor as d JOIN users JOIN appointments WHERE d.user_id = users.id AND appointments.did=d.id AND users.id=:uid AND STR_TO_DATE(a_date, '%d %M %Y')>CURRENT_DATE() AND status!='Cancelled'");
		$stmt->execute([":uid"=>$user['id']]);
		$row = $stmt->fetch();
		$ucp=$row['ucp'];
		}
	catch(PDOException $e){
		$_SESSION['error'] = $e->getMessage();
	}
$pdo->close();
?>						
						<div class="col-md-7 col-lg-8 col-xl-9">

							<div class="row">
								<div class="col-md-12">
									<div class="card dash-card">
										<div class="card-body">
											<div class="row">
												<div class="col-md-12 col-lg-4">
													<div class="dash-widget dct-border-rht">
														<div class="circle-bar circle-bar1">
															<div class="circle-graph1" data-percent="<?php echo($tap_of_doc/$tap*100); ?>">
																<img src="assets/img/icon-01.png" class="img-fluid" alt="patient">
															</div>
														</div>
														<div class="dash-widget-info">
															<h6>Total Patient</h6>
															<h3><?php echo $tap_of_doc ?></h3>
															<p class="text-muted">Till Today</p>
														</div>
													</div>
												</div>
												
												<div class="col-md-12 col-lg-4">
													<div class="dash-widget dct-border-rht">
														<div class="circle-bar circle-bar2">
															<div class="circle-graph2" data-percent="<?php echo($today_patient/$tap_of_doc*100); ?>">
																<img src="assets/img/icon-02.png" class="img-fluid" alt="Patient">
															</div>
														</div>
														<div class="dash-widget-info">
															<h6>Today Patient</h6>
															<h3><?php echo $today_patient ?></h3>
															<p class="text-muted"><?php echo $today?></p>
														</div>
													</div>
												</div>
												
												<div class="col-md-12 col-lg-4">
													<div class="dash-widget">
														<div class="circle-bar circle-bar3">
															<div class="circle-graph3" data-percent="<?php echo($ucp/$tap_of_doc*100); ?>">
																<img src="assets/img/icon-03.png" class="img-fluid" alt="Patient">
															</div>
														</div>
														<div class="dash-widget-info">
															<h6>Upcoming<br>Appoinments</h6>
															<h3><?php echo $ucp ?></h3>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							
							<div class="row">
								<div class="col-md-12">
									<h4 class="mb-4">Patient Appoinment</h4>
									<div class="appointment-tab">
									
										<!-- Appointment Tab -->
										<ul class="nav nav-tabs nav-tabs-solid nav-tabs-rounded">
											<li class="nav-item">
												<a class="nav-link active" href="#today-appointments" data-toggle="tab">Today</a>
											</li> 
											<li class="nav-item">
												<a class="nav-link" href="#upcoming-appointments" data-toggle="tab">Upcoming</a>
											</li>
										</ul>
										<!-- /Appointment Tab -->
										
										<div class="tab-content">

											<!-- Today Appointment Tab -->
											<div class="tab-pane active" id="today-appointments">
												<div class="card card-table mb-0">
													<div class="card-body">
														<div class="table-responsive">
															<table class="table table-hover table-center mb-0">
																<thead>
																	<tr>
																		<th>Patient Name</th>
																		<th>Appt Date</th>
																		<th>Type</th>
																		<th>Payment Type</th>
																		<th class="text-center">Paid Amount</th>
																		<th></th>
																	</tr>
																</thead>
																<tbody>
																	<?php
																	$conn = $pdo->open();
																	try{
																	$p = $conn->prepare("SELECT img FROM patient WHERE id=:pid");
																	
																	$stmt = $conn->prepare("SELECT appointments.id as aid, pid,p_name,a_date,a_time,appointment_type,p_type,amount,status FROM doctor as d JOIN users JOIN appointments JOIN payment WHERE d.user_id = users.id AND appointments.did=d.id AND users.id=:uid AND payment.id=appointments.payment_id AND a_date=:today AND status='Pending' ORDER BY a_time");
																		$today=date("d M Y");
																		$stmt->execute([":uid"=>$user['id'],":today"=>$today]);
																	}
																	catch(PDOException $e){
																		$_SESSION['error'] = $e->getMessage();
																	}
																	$pdo->close();
																	$i=-1;
																	foreach($stmt as $row){
																		$i++;
																		$p->execute([":pid"=>$row['pid']]);
																		$img=$p->fetch();
																		$img=$img['img'];
																		echo'
																	<tr>
																		<td>
																			<h2 class="table-avatar">
																				<a href="patient-profile.php?pid='.$row['pid'].'" class="avatar avatar-sm mr-2"><img class="avatar-img rounded-circle" src="assets/img/patients/'.$img.'" alt="User Image"></a>
																				<a href="patient-profile.php?pid='.$row['pid'].'">'.$row['p_name'].' <span>#PT'.$row['pid'].'</span></a>
																			</h2>
																		</td>
																		<td>'.$row['a_date'].'<span class="d-block text-info">'.$row['a_time'].'</span></td>
																		<td>'.$row['appointment_type'].'</td>
																		<td>'.$row['p_type'].'</td>
																		<td class="text-center">&#8377; '.(($row['p_type']=='COV')?'0':$row['amount']).'</td>
																		<td class="text-right">
																			<div class="table-action">
																			<input type="hidden" id="tap_'.$i.'" value="'.$row['aid'].'">
																			<a href="#none" id="tap_a_'.$i.'" class="btn btn-sm bg-success-light">
																					<i class="fas fa-check"></i> Accept
																				</a>&nbsp;&nbsp;			
																				<a href="#none" id="tap_c_'.$i.'" class="btn btn-sm bg-danger-light">
																					<i class="fas fa-times"></i> Cancel
																				</a>
																			</div>
																		</td>';}?>
																</tbody>
															</table>		
														</div>	
													</div>	
												</div>	
											</div>
											<!-- /Today Appointment Tab -->

											<!-- Upcoming Appointment Tab -->
											<div class="tab-pane show" id="upcoming-appointments">
												<div class="card card-table mb-0">
													<div class="card-body">
														<div class="table-responsive">
															<table class="table table-hover table-center mb-0">
																<thead>
																	<tr>
																		<th>Patient Name</th>
																		<th>Appt Date</th>
																		<th>Type</th>
																		<th>Payment Type</th>
																		<th class="text-center">Paid Amount</th>
																		<th></th>
																	</tr>
																</thead>
																<tbody>
																	<?php
																	$conn = $pdo->open();
																	try{
																	$p = $conn->prepare("SELECT img FROM patient WHERE id=:pid");
																	
																	$stmt = $conn->prepare("SELECT appointments.id as aid, pid,p_name,a_date,a_time,appointment_type,p_type,amount,status FROM doctor as d JOIN users JOIN appointments JOIN payment WHERE d.user_id = users.id AND appointments.did=d.id AND users.id=:uid AND payment.id=appointments.payment_id AND STR_TO_DATE(a_date, '%d %M %Y')>CURRENT_DATE() AND status='Pending' ORDER BY STR_TO_DATE(a_date, '%d %M %Y'),a_time");
																		$stmt->execute([":uid"=>$user['id']]);
																	}
																	catch(PDOException $e){
																		$_SESSION['error'] = $e->getMessage();
																	}
																	$pdo->close();
																	$i=-1;
																	foreach($stmt as $row){
																		$i++;
																		$p->execute([":pid"=>$row['pid']]);
																		$img=$p->fetch();
																		$img=$img['img'];
																		echo'
																	<tr>
																		<td>
																			<h2 class="table-avatar">
																				<a href="patient-profile.php?pid='.$row['pid'].'" class="avatar avatar-sm mr-2"><img class="avatar-img rounded-circle" src="assets/img/patients/'.$img.'" alt="User Image"></a>
																				<a href="patient-profile.php?pid='.$row['pid'].'">'.$row['p_name'].' <span>#PT'.$row['pid'].'</span></a>
																			</h2>
																		</td>
																		<td>'.$row['a_date'].'<span class="d-block text-info">'.$row['a_time'].'</span></td>
																		<td>'.$row['appointment_type'].'</td>
																		<td>'.$row['p_type'].'</td>
																		<td class="text-center">&#8377; '.(($row['p_type']=='COV')?'0':$row['amount']).'</td>
																		<td class="text-right">
																			<div class="table-action">
																			<input type="hidden" id="uap_'.$i.'" value="'.$row['aid'].'">
																			<a href="#none" id="uap_a_'.$i.'" class="btn btn-sm bg-success-light">
																					<i class="fas fa-check"></i> Accept
																				</a>&nbsp;&nbsp;			
																				<a href="#none" id="uap_c_'.$i.'" class="btn btn-sm bg-danger-light">
																					<i class="fas fa-times"></i> Cancel
																				</a>
																			</div>
																		</td>';}?>
																</tbody>
															</table>		
														</div>	
													</div>	
												</div>
											</div>
											<!-- /Upcoming Appointment Tab -->
									   											
										</div>
									</div>
								</div>
							</div>

						</div>
					</div>

				</div>

			</div>		
			<!-- /Page Content -->
   
			<!-- Footer -->
			<?php include 'includes/footer.php'; ?>
			<!-- /Footer -->
		   
		</div>
		<!-- /Main Wrapper -->
	  
		<!-- jQuery -->
		<script src="assets/js/jquery.min.js"></script>

		<script type='text/javascript'>
		<?php for($i=0;$i<$today_patient;$i++){
		echo"
			$(document).on('click','#tap_a_".$i."',function(e){
			e.preventDefault();
		    var aid = $('#tap_".$i."').val();
		    var mode='accept';
		    $.ajax({
		      type: 'POST',
		      url: 'change_appoinment_status.php',
		      data: {aid:aid,mode:mode},
		      dataType: 'json',
		      success: function(response){
		        if(!response.error){
		          location.reload(); 
		        }
		      }
		    });
		  });
			";

		echo"
			$(document).on('click','#tap_c_".$i."',function(e){
			e.preventDefault();
		    var aid = $('#tap_".$i."').val();
		    var mode='cancel';
		    $.ajax({
		      type: 'POST',
		      url: 'change_appoinment_status.php',
		      data: {aid:aid,mode:mode},
		      dataType: 'json',
		      success: function(response){
		        if(!response.error){
		          location.reload(); 
		        }
		      }
		    });
		  });
			";}

			for($i=0;$i<$ucp;$i++){
			echo"
			$(document).on('click','#uap_a_".$i."',function(e){
			e.preventDefault();
		    var aid = $('#uap_".$i."').val();
		    var mode='accept';
		    $.ajax({
		      type: 'POST',
		      url: 'change_appoinment_status.php',
		      data: {aid:aid,mode:mode},
		      dataType: 'json',
		      success: function(response){
		        if(!response.error){
		          location.reload(); 
		        }
		      }
		    });
		  });
			";

		echo"
			$(document).on('click','#uap_c_".$i."',function(e){
			e.preventDefault();
		    var aid = $('#uap_".$i."').val();
		    var mode='cancel';
		    $.ajax({
		      type: 'POST',
		      url: 'change_appoinment_status.php',
		      data: {aid:aid,mode:mode},
		      dataType: 'json',
		      success: function(response){
		        if(!response.error){
		          location.reload(); 
		        }
		      }
		    });
		  });
			";
									
		}?>
		</script>
		
		<!-- Bootstrap Core JS -->
		<script src="assets/js/popper.min.js"></script>
		<script src="assets/js/bootstrap.min.js"></script>
		
		<!-- Sticky Sidebar JS -->
        <script src="assets/plugins/theia-sticky-sidebar/ResizeSensor.js"></script>
        <script src="assets/plugins/theia-sticky-sidebar/theia-sticky-sidebar.js"></script>
		
		<!-- Circle Progress JS -->
		<script src="assets/js/circle-progress.min.js"></script>
		
		<!-- Custom JS -->
		<script src="assets/js/script.js"></script>
		
	</body>
</html>