<?php include 'includes/session.php'; ?>
<?php
if(isset($_POST['change_time_slots'])){
	$no_slot=(int)$_POST['slots'];
	$day=$_POST['day_name'];
	$did=$_POST['did'];
	$time=null;
	for($i=0;$i<$no_slot;$i++){
		$time.=$_POST['stime_'.$i.''].'-'.$_POST['etime_'.$i.''].',';
	}
	$time=rtrim($time, ",");

	try{
		$stmt = $conn->prepare("UPDATE doctor_timing set {$day}=:slot where did=:did");
		$stmt->execute([':slot'=>$time,':did'=>$did]);

	}
	catch(PDOException $e){
		$_SESSION['error'] = $e->getMessage();
	}
	header('location: schedule-timings.php');
}

else{
$slot=$_POST['stime'].'-'.$_POST['etime'];
$day=$_POST['day'];
$did=$_POST['did'];
$mode=$_POST['mode'];
   
$conn = $pdo->open();
$output = array('error'=>false,'message'=>'');
if($mode=='insert'){
		try{
			$stmt = $conn->prepare("SELECT {$day} from doctor_timing where did=:did");
			$stmt->execute([':did'=>$did]);
			$row = $stmt->fetch();
			if(is_null($row[$day])){
				$stmt = $conn->prepare("UPDATE doctor_timing set {$day}=:slot where did=:did");
				$stmt->execute([':slot'=>$slot,':did'=>$did]);
			
			}
			else{
			$stmt = $conn->prepare("UPDATE doctor_timing set {$day}=CONCAT({$day}, ',', :slot) where did=:did");
			$stmt->execute([':slot'=>$slot,':did'=>$did]);
			}
		}
		catch(PDOException $e){
			
			$output['message'] = $e->getMessage();
		}
	}
	else{
		try{
			
			$stmt = $conn->prepare("UPDATE doctor_timing set {$day}=REPLACE({$day},:slot,'') where did=:did");
			$stmt->execute([':slot'=>$slot,':did'=>$did]);
			$stmt = $conn->prepare("UPDATE doctor_timing set {$day}=REPLACE({$day},',,',',') where did=:did");
			$stmt->execute([':did'=>$did]);
			
			
			$stmt = $conn->prepare("select RIGHT({$day},1) as l from doctor_timing  where did=:did");
			$stmt->execute([':did'=>$did]);
			$row = $stmt->fetch();
			if($row['l']==','){
				$stmt = $conn->prepare("UPDATE doctor_timing set {$day}=SUBSTR({$day}, 1, LENGTH({$day}) - 1) where did=:did");
				$stmt->execute([':did'=>$did]);
			}

			$stmt = $conn->prepare("SELECT {$day} from doctor_timing where did=:did");
			$stmt->execute([':did'=>$did]);
			$row = $stmt->fetch();
			
			if($row[$day]==''){
				$stmt = $conn->prepare("UPDATE doctor_timing set {$day}=NULL where did=:did");
				$stmt->execute([':did'=>$did]);
			
			}
			
		}
		catch(PDOException $e){
			$output['message'] = $e->getMessage();
		}

	}

$pdo->close();
echo json_encode($output);
}
?>