<?php
$out='';
if($_POST['mode']=="next")
	$date=date('d M Y', strtotime($_POST['date'] .' +7 day'));
else
	$date=date('d M Y', strtotime($_POST['date'] .' -7 day'));
$day=date('D');
for($i=0;$i<7;$i++){
$out.='
	<li id="date_'.$i.'">
	<span>'.date('D', strtotime($day .' +'.$i.' day')).'</span>
	<span class="slot-date">'.date('d M Y', strtotime($date .' +'.$i.' day')).'</span>
	<input type="hidden" id="da_'.$i.'" value="'.date('d M Y', strtotime($date .' +'.$i.' day')).'" name="da_'.$i.'">
	</li>';}

echo json_encode($out);
?>