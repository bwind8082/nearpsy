<?php include 'includes/session.php'; ?>
<?php 
	if(isset($_POST['signup'])){
		$name = $_POST['name'];
		$email = $_POST['email'];
		$mobileno=$_POST['mobileno'];
		$password = $_POST['password'];
		$type= (int)$_POST['type'];
		$_SESSION['firstname'] = $firstname;
		$_SESSION['mobileno'] = $mobileno;
		
			$conn = $pdo->open();

			$stmt = $conn->prepare("SELECT COUNT(*) AS numrows,type FROM users WHERE mobileno=:mobileno");
			$stmt1 = $conn->prepare("SELECT COUNT(*) AS numrows,type FROM users WHERE email=:email");
			$stmt->execute(['mobileno'=>$mobileno]);
			$stmt1->execute(['email'=>$email]);
			$row = $stmt->fetch();
			$row1 = $stmt1->fetch();
			if($row['numrows'] > 0 && $row['type']==$type){
				$_SESSION['error'] = 'Mobile No is already Registered';
				header('location: register.php');
			}
			else if($row1['numrows'] > 0 && $row1['type']==$type){
				$_SESSION['error'] = 'Email is already Registered';
				header('location: register.php');
			}
			else{

				try{
					$stmt = $conn->prepare("INSERT INTO users (name, mobileno, email, password, type) VALUES (:name, :mobileno,:email,:password, :type)");
					$stmt->execute(['name'=>$name, 'mobileno'=>$mobileno, 'email'=>$email, 'password'=>$password, 'type'=>$type]);
					$userid = $conn->lastInsertId();
					if($type==1){
					$stmt = $conn->prepare("INSERT INTO patient (user_id) VALUES (:userid)");
					$stmt->execute([':userid'=>$userid]);
					}
					else{
						$stmt = $conn->prepare("INSERT INTO doctor (user_id) VALUES (:userid)");
						$stmt->execute([':userid'=>$userid]);
						$did = $conn->lastInsertId();
						$stmt = $conn->prepare("INSERT INTO doctor_timing (did) VALUES (:did)");
						$stmt->execute([':did'=>$did]);
					}
					
				        unset($_SESSION['firstname']);
				        unset($_SESSION['mobileno']);

				        $_SESSION['success'] = '<h3>Account created. log in now.</h3>';
				        header('location: login.php');

				}
				catch(PDOException $e){
					$_SESSION['error'] = $e->getMessage();
					header('location: register.php');
				}

				$pdo->close();

			}
		
	}
		
	else{
		$_SESSION['error'] = 'Fill up signup form first';
		header('location: register.php');
	}

?>