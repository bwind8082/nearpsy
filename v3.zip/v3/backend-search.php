<?php include 'includes/session.php'; ?>
<?php
$conn = $pdo->open();
try{
    if(isset($_REQUEST["term"])){
        $term = '%'. $_REQUEST["term"] . '%';
        $city=$_REQUEST['location'];
        if($city!=''){
        $stmt = $conn->prepare("SELECT name,doctor.id as did FROM doctor JOIN users ON doctor.user_id=users.id WHERE city=:city AND name LIKE :term");
        $stmt->execute([":term"=>$term,":city"=>$city]);
        }
        else{
        $stmt = $conn->prepare("SELECT name,doctor.id as did FROM doctor JOIN users ON doctor.user_id=users.id WHERE name LIKE :term");
        $stmt->execute([":term"=>$term]);
        }
        if($stmt->rowCount() > 0){
            while($row = $stmt->fetch()){
                echo "<a href='doctor-profile.php?id=".$row['did']."'><p>" . $row["name"] . "</p></a>";
            }
        } else{
            echo "<p>No matches found</p>";
        }
    }  
} catch(PDOException $e){
    die("ERROR: Could not able to execute sql. " . $e->getMessage());
}
 
$pdo->close();
?>