<?php include 'includes/session.php'; ?>
<?php
$conn = $pdo->open();
	try{
	$stmt = $conn->prepare("SELECT d.id as did,img,name,degree FROM doctor as d JOIN users WHERE d.user_id = users.id AND users.id=:uid");
	$stmt->execute([":uid"=>$user['id']]);
	$row = $stmt->fetch();
	}
	catch(PDOException $e){
	$_SESSION['error'] = $e->getMessage();
	}
	$pdo->close();
?>
<!DOCTYPE html> 
<html lang="en">

<head>
		<meta charset="utf-8">
		<title>NearPsy</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
		
		<!-- Favicons -->
		<link href="assets/img/favicon.png" rel="icon">
		
		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="assets/css/bootstrap.min.css">
		
		<!-- Fontawesome CSS -->
		<link rel="stylesheet" href="assets/plugins/fontawesome/css/fontawesome.min.css">
		<link rel="stylesheet" href="assets/plugins/fontawesome/css/all.min.css">
		
		<!-- Main CSS -->
		<link rel="stylesheet" href="assets/css/style.css">
		
	</head>
	<body>

		<!-- Main Wrapper -->
		<div class="main-wrapper">
		
			<!-- Header -->
			<?php include 'includes/navbar.php'; ?>
			<!-- /Header -->
			
			<!-- Breadcrumb -->
			<div class="breadcrumb-bar">
				<div class="container-fluid">
					<div class="row align-items-center">
						<div class="col-md-12 col-12">
							<nav aria-label="breadcrumb" class="page-breadcrumb">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="index.php">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Reviews</li>
								</ol>
							</nav>
							<h2 class="breadcrumb-title">Reviews</h2>
						</div>
					</div>
				</div>
			</div>
			<!-- /Breadcrumb -->
			
			<!-- Page Content -->
			<div class="content">
				<div class="container-fluid">

					<div class="row">
						<div class="col-md-5 col-lg-4 col-xl-3 theiaStickySidebar">
						
							<!-- Profile Sidebar -->
							<?php include 'includes/doc-profile-sidebar.php'; ?>
							<!-- /Profile Sidebar -->
							
						</div>
						<div class="col-md-7 col-lg-8 col-xl-9">
							<div class="doc-review review-listing">
							
								<!-- Review Listing -->
								<ul class="comments-list">
									<?php
											$conn = $pdo->open();

											try{
											
											$stmt = $conn->prepare("SELECT name,img,review, rating, recommend, r_date FROM feedback JOIN users JOIN patient WHERE users.id=feedback.g_uid AND patient.user_id=users.id AND did=:did ORDER BY feedback.id DESC ");
											$stmt->execute([":did"=>$row['did']]);
											}
											catch(PDOException $e){
												$_SESSION['error'] = $e->getMessage();
											}
											$pdo->close();
											foreach ($stmt as $r) { 
											$t = date_diff(date_create($r['r_date']), date_create(date("d M Y")));
											$t=$t->format('%d');
											echo'
											<li>
												<div class="comment" style="position: relative;">
													<img class="avatar avatar-sm rounded-circle" alt="User Image" src="assets/img/patients/'.$r['img'].'">
													<div class="comment-body">
														<div class="meta-data">
															<span class="comment-author">'.$r['name'].'</span>
															<span class="comment-date">Reviewed '.$t.' Days ago</span>
															<div class="review-count rating" style="position: absolute;left: 920px">
																<i class="fas fa-star '.(($r['rating']>0)?'filled':'').'"></i>
																<i class="fas fa-star '.(($r['rating']>1)?'filled':'').'"></i>
																<i class="fas fa-star '.(($r['rating']>2)?'filled':'').'"></i>
																<i class="fas fa-star '.(($r['rating']>3)?'filled':'').'"></i>
																<i class="fas fa-star '.(($r['rating']>4)?'filled':'').'"></i>
															</div>
														</div>
														'.(($r['recommend']==1)?'<p class="recommended"><i class="far fa-thumbs-up"></i> I recommend the doctor</p>':(($r['recommend']==0)?'<p class="recommended" style="color: red"><i class="far fa-thumbs-down"></i> I do not recommend the doctor</p>':'')).'
														<p class="comment-content">
															'.$r['review'].'
														</p>
													</div>
												</div>
											</li>';}?>
									
								</ul>
								<!-- /Comment List -->
								
							</div>
						</div>
					</div>
				</div>

			</div>		
			<!-- /Page Content -->
   
			<!-- Footer -->
			<?php include 'includes/footer.php'; ?>
			<!-- /Footer -->
		   
		</div>
		<!-- /Main Wrapper -->
	  
		<!-- jQuery -->
		<script src="assets/js/jquery.min.js"></script>
		
		<!-- Bootstrap Core JS -->
		<script src="assets/js/popper.min.js"></script>
		<script src="assets/js/bootstrap.min.js"></script>
		
		<!-- Sticky Sidebar JS -->
        <script src="assets/plugins/theia-sticky-sidebar/ResizeSensor.js"></script>
        <script src="assets/plugins/theia-sticky-sidebar/theia-sticky-sidebar.js"></script>
		
		<!-- Custom JS -->
		<script src="assets/js/script.js"></script>
		
	</body>

</html>