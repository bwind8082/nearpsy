<div class="profile-sidebar">
							<div class="widget-profile pro-widget-content">
									<div class="profile-info-widget">
										<a href="#" class="booking-doc-img">
											<img src="assets/img/doctors/<?php echo $row['img'];?>" alt="User Image">
										</a>
										<div class="profile-det-info">
											<h3>Dr. <?php echo $user['name'];?></h3>
											
											<div class="patient-details">
												<h5 class="mb-0"><?php echo str_replace("@@",",",$row['degree']);?></h5>
											</div>
										</div>
									</div>
								</div>
								<div class="dashboard-widget">
									<nav class="dashboard-menu">
										<ul>
											<li id="doctor-dashboard">
												<a href="doctor-dashboard.php">
													<i class="fas fa-columns"></i>
													<span>Dashboard</span>
												</a>
											</li>
											<li id="appointments">
												<a href="appointments.php">
													<i class="fas fa-calendar-check"></i>
													<span>Appointments</span>
												</a>
											</li>
											<li id="my-patients">
												<a href="my-patients.php">
													<i class="fas fa-user-injured"></i>
													<span>My Patients</span>
												</a>
											</li>
											<li id="schedule-timings">
												<a href="schedule-timings.php">
													<i class="fas fa-hourglass-start"></i>
													<span>Schedule Timings</span>
												</a>
											</li>
											<li id="invoices">
												<a href="invoices.php">
													<i class="fas fa-file-invoice"></i>
													<span>Invoices</span>
												</a>
											</li>
											<li id="reviews">
												<a href="reviews.php">
													<i class="fas fa-star"></i>
													<span>Reviews</span>
												</a>
											</li>
											<li id="doctor-profile-settings">
												<a href="doctor-profile-settings.php">
													<i class="fas fa-user-cog"></i>
													<span>Profile Settings</span>
												</a>
											</li>
											<li id="change-password">
												<a href="change-password.php">
													<i class="fas fa-lock"></i>
													<span>Change Password</span>
												</a>
											</li>
											<li>
												<a href="logout.php">
													<i class="fas fa-sign-out-alt"></i>
													<span>Logout</span>
												</a>
											</li>
										</ul>
									</nav>
								</div>
							</div>
<script src="assets/js/jquery.min.js"></script>
<script type="text/javascript">
	$(document).ready(function () {
          var cp="<?php echo $_SERVER['REQUEST_URI'];?>";
          cp=cp.split("/")[2].replace('.php','');
          $('#'+cp).addClass('active');
       });
</script>