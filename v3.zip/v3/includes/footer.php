<footer class="footer">
				
				<!-- Footer Top -->
				<div class="footer-top">
					<div class="container-fluid">
						<div class="row">
							<div class="col-lg-3 col-md-6">
							
								<!-- Footer Widget -->
								<div class="footer-widget footer-about">
									<div class="footer-logo">
									<h2 class="footer-title">NearPsy</h2>
										
									</div>
									<div class="footer-about-content">
										
										<p>We are Care Giver.</p>
										<div class="social-icon">
											<ul>
												<li>
													<a href="https://www.facebook.com/Nearpsy-101718078897401" target="_blank"><i class="fab fa-facebook-f"></i> </a>
												</li>
												<li>
													<a href="https://twitter.com/Nearpsy1" target="_blank"><i class="fab fa-twitter"></i> </a>
												</li>
												<li>
													<a href="https://www.instagram.com/nearpsy/" target="_blank"><i class="fab fa-instagram"></i></a>
												</li>
											</ul>
										</div>
									</div>
								</div>
								<!-- /Footer Widget -->
								
							</div>
							
							<div class="col-lg-3 col-md-6">
							
								
								
							</div>
							
							<div class="col-lg-3 col-md-6">
							
							
							</div>
							
							<div class="col-lg-3 col-md-6">
							
								<!-- Footer Widget -->
								<div class="footer-widget footer-contact">
									<h2 class="footer-title">Contact Us</h2>
									<div class="footer-contact-info">
										
										<p>
											<i class="fas fa-phone-alt"></i>
											+91 9974542163 
										</p>
										<p class="mb-0">
											<i class="fas fa-envelope"></i>
											info[at]nearpsy[dot]com
										</p>
									</div>
								</div>
								<!-- /Footer Widget -->
								
							</div>
							
						</div>
					</div>
				</div>
				<!-- /Footer Top -->
				
				<!-- Footer Bottom -->
                <div class="footer-bottom">
					<div class="container-fluid">
					
						<!-- Copyright -->
						<div class="copyright">
							<div class="row">
								<div class="col-md-6 col-lg-6">
									<div class="copyright-text">
										<p class="mb-0">&#169; DigiAling</p>
									</div>
								</div>
								<div class="col-md-6 col-lg-6">
								
									<!-- Copyright Menu -->
									<div class="copyright-menu">
										<ul class="policy-menu">
											
											<li><a href="refund-policy.php">Payment Policy</a></li>
										</ul>
									</div>
									<!-- /Copyright Menu -->
									
								</div>
							</div>
						</div>
						<!-- /Copyright -->
						
					</div>
				</div>
				<!-- /Footer Bottom -->
				
			</footer>
