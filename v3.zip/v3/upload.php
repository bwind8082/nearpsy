<?php include 'includes/session.php'; ?>
<?php
if((int)$_POST['p_img']){
$target_dir = "assets/img/patients/";}
else{
  $target_dir = "assets/img/doctors/";
}
$imageFileType = strtolower(pathinfo($_FILES["fileToUpload"]["name"],PATHINFO_EXTENSION));
$target_file = $target_dir . $user['id'].".".$imageFileType;
$uploadOk = 1;


// Check if image file is a actual image or fake image
if(isset($_POST["upload"])) {
  $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
  if($check !== false) {
    $uploadOk = 1;
  } else {
    $_SESSION['error'] = "File is not an image.";
    $uploadOk = 0;
  }

// Check file size
if ($_FILES["fileToUpload"]["size"] > 500000) {
  $_SESSION['error'] =  "Sorry, your file is too large.";
  $uploadOk = 0;
}

// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
  $_SESSION['error'] = "Sorry, only JPG, PNG & GIF files are allowed.";
  $uploadOk = 0;
}

// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 1) {
  if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
    $_SESSION['success'] = "Photo has been uploaded successfully.";
    $conn = $pdo->open();
    try{
        if((int)$_POST['p_img']){
          $stmt = $conn->prepare("UPDATE patient SET img = :img WHERE user_id = :id ");
          $stmt->execute(['img'=>$user['id'].".".$imageFileType,'id'=>$user['id']]);
        }
        else
        {
          $stmt = $conn->prepare("UPDATE doctor SET img = :img WHERE user_id = :id ");
          $stmt->execute(['img'=>$user['id'].".".$imageFileType,'id'=>$user['id']]);
        }
        }
        catch(PDOException $e){
          $_SESSION['error'] = $e->getMessage();
        }

        $pdo->close();
  } else {
    $_SESSION['error']="Sorry, there was an error uploading your file.";
  }
}
}
else{
    $_SESSION['error'] = 'Upload Image First.';
  }
  if((int)$_POST['p_img'])
    header('location: profile-settings.php');
  else
    header('location: doctor-profile-settings.php');

?>