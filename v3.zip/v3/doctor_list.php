<?php include 'includes/session.php'; ?>
<!DOCTYPE php> 
<html lang="en">
<?php include 'includes/header.php'; ?>
<title>Consult with our care taker | top 1% Psychiatrist and Pshychologist</title>
<meta name="description" content="NearPsy offers Doctors the perfect mix of reliable income, and full support.">
</head>
	<body>

		<!-- Main Wrapper -->
		<div class="main-wrapper">
		<?php include 'includes/navbar.php'; ?>
			
			<!-- Breadcrumb -->
			<div class="breadcrumb-bar">
				<div class="container-fluid">
					<div class="row align-items-center">
						<div class="col-md-8 col-12">
							<nav aria-label="breadcrumb" class="page-breadcrumb">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="index.php">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Doctor List</li>
								</ol>
							</nav>
						</div>
					</div>
				</div>
			</div>
			<!-- /Breadcrumb -->
			
			<!-- Page Content -->
			<div class="content">
				<div class="container-fluid">

					<div class="row">
						
						<div class="col-md-12">

							<!-- Doctor Widget -->
							<?php
								$conn = $pdo->open();
								try{
								$s = $conn->prepare("SELECT COUNT(feedback.id) as nor,CAST(AVG(rating) AS INT) as rat FROM feedback WHERE did=:did ");
								$src = $conn->prepare("SELECT count(recommend) as norm FROM feedback JOIN users JOIN patient WHERE users.id=feedback.g_uid AND patient.user_id=users.id AND did=:did AND feedback.recommend=1");
								$strc = $conn->prepare("SELECT count(recommend) as norm FROM feedback JOIN users JOIN patient WHERE users.id=feedback.g_uid AND patient.user_id=users.id AND did=:did AND feedback.recommend!=3");
								$srv = $conn->prepare("SELECT count(feedback.id) as norv,CAST(AVG(rating) AS INT) as rat FROM feedback JOIN users JOIN patient WHERE users.id=feedback.g_uid AND patient.user_id=users.id AND did=:did ");

								$stmt = $conn->prepare("SELECT *,d.id as did FROM doctor as d JOIN users WHERE d.user_id = users.id");
								$stmt->execute();

								foreach($stmt as $row){
								$s->execute([":did"=>$row['did']]);
								$rat=$s->fetch();
								$src->execute([":did"=>$row['did']]);
								$rc=$src->fetch();
								$strc->execute([":did"=>$row['did']]);
								$tr=$strc->fetch();
								$rc=($tr['norm']>0)?round($rc['norm']/$tr['norm']*100,2):'N/A';
								$srv->execute([":did"=>$row['did']]);
								$rv_detail=$srv->fetch();
								$services=explode(',',$row['services']);
								echo'
							<div class="card">
								<div class="card-body">
									<div class="doctor-widget">
										<div class="doc-info-left">
											<div class="doctor-img">
												<a href="doctor-profile.php?id='.$row['did'].'">
													<img src="assets/img/doctors/'.$row['img'].'" class="img-fluid" alt="User Image">
												</a>
											</div>
											<div class="doc-info-cont">
												<h4 class="doc-name"><a href="doctor-profile.php?id='.$row['did'].'">Dr. '.$row['name'].'</a></h4>
												<p class="doc-speciality">'.str_replace("@@",",",$row['degree']).'</p>
											<!--	<h5 class="doc-department"><img src="assets/img/specialities/'.strtolower($row['doc_type']).'.png" class="img-fluid" alt="Speciality">'.$row['doc_type'].'</h5> -->
												<div class="rating">
													<i class="fas fa-star '.(($rat['rat']>0)?'filled':'').'"></i>
													<i class="fas fa-star '.(($rat['rat']>1)?'filled':'').'"></i>
													<i class="fas fa-star '.(($rat['rat']>2)?'filled':'').'"></i>
													<i class="fas fa-star '.(($rat['rat']>3)?'filled':'').'"></i>
													<i class="fas fa-star '.(($rat['rat']>4)?'filled':'').'"></i>
													<span class="d-inline-block average-rating">('.((!is_null($rat))?$rat['nor']:'0').')</span>
												</div>
												<div class="clinic-details">
													<p class="doc-location"><i class="fas fa-map-marker-alt"></i> '.$row['city'].','.$row['state'].'</p>
												</div>
												<div class="clinic-services">
											<span>'.$services[0].'</span>
											<span>'.$services[1].'</span>
												</div>
											</div>
										</div>
										<div class="doc-info-right">
											<div class="clini-infos">
												<ul>
													<li><i class="far fa-thumbs-up"></i> '.$rc.'%</li>
													<li><i class="far fa-comment"></i> '.$rv_detail['norv'].' Feedback</li>
													<li><i class="fas fa-map-marker-alt"></i> '.$row['city'].', '.$row['state'].'</li>
													<li><i class="far fa-money-bill-alt"></i>&#8377; '.$row['fees'].' per hour</li>
												</ul>
											</div>
											<div class="clinic-booking">
												<a class="view-pro-btn" href="doctor-profile.php?id='.$row['did'].'">View Profile</a>
												<a class="apt-btn" href="booking.php?did='.$row['did'].'">Book Appointment</a>
											</div>
										</div>
									</div>
								</div>
							</div>';}}
							catch(PDOException $e){
								$_SESSION['error'] = $e->getMessage();
							}
							$pdo->close();?>
							<!-- /Doctor Widget -->
	
						</div>
					</div>

				</div>

			</div>		
			<!-- /Page Content -->
   
			<!-- Footer -->
			<?php include 'includes/footer.php'; ?>
			<!-- /Footer -->

		</div>
		<!-- /Main Wrapper -->
	  <?php include 'includes/scripts.php'; ?>
	</body>
</html>
