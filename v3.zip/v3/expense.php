<?php include 'includes/session.php'; ?>
<!DOCTYPE html>
<html lang="en">
   <?php
  if(!isset($_SESSION['user']))
        header('location: login.php');
?>
<?php include 'includes/header.php'; ?>
<?php

if($user['type']){
$stmt = $conn->prepare("SELECT branch_id,branch_city FROM employee JOIN users JOIN branch ON employee.u_id=users.id AND branch.branch_code=employee.branch_id WHERE users.id=:uid");
$stmt->execute(['uid'=>$user['id']]);
$bid=$stmt->fetch();
}
if(isset($_GET['seid'])){
$stmt = $conn->prepare("SELECT from_branch,to_branch,`date` FROM stock_exchange WHERE id=:seid");
$stmt->execute(['seid'=>$_GET['seid']]);
$det=$stmt->fetch();
}
?>
<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        <title>Doccure - Basic Inputs</title>
		
		<!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.png">
		
		<!-- Bootstrap CSS -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
		
		<!-- Fontawesome CSS -->
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">
		
		<!-- Feathericon CSS -->
        <link rel="stylesheet" href="assets/css/feathericon.min.css">
		
		<!-- Main CSS -->
        <link rel="stylesheet" href="assets/css/style.css">
</head>
    <body>
	 <?php include ($user['type'])?'includes/em_navsidebar.php':'includes/navsidebar.php'; ?>
		<!-- Main Wrapper -->
        <div class="main-wrapper">
			
			<!-- Page Wrapper -->
            <div class="page-wrapper">
                <div class="content container-fluid">
				
					<!-- Page Header -->
					<div class="page-header">
						<div class="row">
							<div class="col">
								<h3 class="page-title">
							    Stock Exchange Detail
								</h3>
								<ul class="breadcrumb">
									<li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
									<li class="breadcrumb-item active">Stock Exchange Detail</li>
								</ul>
							</div>
						</div>
					</div>
					<!-- /Page Header -->

					
					
					<div class="row">
						<div class="col-lg-12">
							<div class="card">
								<div class="card-header">
									<h4 class="card-title">Add-Product</h4>
								</div>
								<div class="card-body">
									<div class="add-more">
										<a href="#none" onclick="add_new_prod()" ><i class="fa fa-plus-circle"></i> Add More</a>
									</div><br>
									<form action="edit_stock_exchange.php" method="POST" id="product_list">
									
										<input type="hidden" id="null_price" value="">
										
										<?php
										$no_row=-1;
										if(isset($_GET['seid'])){
										$stmt = $conn->prepare("SELECT p_codes,p_qty FROM stock_exchange WHERE id=:seid");
										$stmt->execute(['seid'=>$_GET['seid']]);
										$row=$stmt->fetch();
										
										if($row['p_codes']!=''){
										$p_code=explode('@@', $row['p_codes']);
										$p_qty=explode('@@', $row['p_qty']);
										$no_row=count($p_code);

										for($i=0;$i<$no_row;$i++){
											$stmt = $conn->prepare("SELECT product_code,product_name,product_unit FROM `inventory`");
											$stmt->execute();
											$op='<option id="null" value="null">Select</option>';
											foreach ($stmt as $row) {
											$op.='
											<option '.(($p_code[$i]==$row['product_code'])?'selected':'').' id="'.$row['product_code'].'" value="'.$row['product_code'].'" >'.$row['product_code'].'-'.$row['product_name'].'</option>';
											}

											echo'<div class="row form-row"><div class="col-12 col-md-10 col-lg-11"><div class="row form-row"><div class="col-12 col-md-6 col-lg-3"><div class="form-group"><label>Product-Name</label><select class="form-control" id="pname_'.$i.'" name="pname_'.$i.'">'.$op.'</select></div></div><div class="col-12 col-md-6 col-lg-3"><div class="form-group"><label>Qty</label><input type="text" class="form-control" id="qty_'.$i.'" name="qty_'.$i.'" onkeyup="check_qun(this.id)" value="'.$p_qty[$i].'"></div></div><div class="col-12 col-md-6 col-lg-3"></div></div></div></div>';

										}
										$no_row=count($p_code)-1;}}
										?>
										<?php 
										$stmt = $conn->prepare("SELECT product_code,product_name FROM `inventory`");
										$stmt->execute();
										$op='<option id="null" value="null">Select</option>';
										foreach ($stmt as $row) {
										$op.='
										<option id="'.$row['product_code'].'" value="'.$row['product_code'].'" >'.$row['product_code'].'-'.$row['product_name'].'</option>';
										
									}?>
										
										<script type="text/javascript">
										var i=`<?= $no_row?>`;
										var op=`<?php echo $op ?>`;

										function add_new_prod() {
											i++;
										 var b = document.createElement("div");
										   b.innerHTML='<div class="row form-row"><div class="col-12 col-md-10 col-lg-11"><div class="row form-row"><div class="col-12 col-md-6 col-lg-3"><div class="form-group"><label>Product-Name</label><select class="form-control" id="pname_'+i+'" name="pname_'+i+'" >'+op+'</select></div></div><div class="col-12 col-md-6 col-lg-3"><div class="form-group"><label>Qty</label><input type="text" class="form-control" id="qty_'+i+'" name="qty_'+i+'" ></div></div></div></div></div>'
										   
										   document.getElementById('i').value=i;
										   var element = document.getElementById("product_list");
										   element.prepend(b);}
									</script>
									</div>		
									
								</div>
								<div class="row">
						<div class="col-lg-12">
							<div class="card">
								<div class="card-header">
									<h4 class="card-title">Details</h4>
								</div>
								<div class="card-body">
									<div class="col-lg-9 row form-row">
									<div class="col-lg-3">
									<label class="col-form-label">From<span class="text-danger"> *</span></label><br>
									
									<select name="from_branch" class="btn btn-info dropdown-toggle dropdown-toggle-split" required style="background-color: white;color: black;width: 160px; height: 40px;" >
										<?php
										$branch1='<option value="Hq">Headquarter</option>';
										$branch2='';
										$stmt = $conn->prepare("SELECT branch_code,branch_city FROM branch");
										$stmt->execute();
										foreach($stmt as $row){
											$branch1.='
										<option '.((isset($_GET['seid']))?(($det['from_branch']==$row['branch_code'])?'selected':''):'').' value="'.$row['branch_code'].'">'.$row['branch_code'].'-'.$row['branch_city'].'</option>';
										if($user['type']){
											$branch2='
										<option value="'.$bid['branch_id'].'">'.$bid['branch_id'].'-'.$bid['branch_city'].'</option>';}	
										else{
										$branch2.='
										<option '.((isset($_GET['seid']))?(($det['to_branch']==$row['branch_code'])?'selected':''):'').' value="'.$row['branch_code'].'">'.$row['branch_code'].'-'.$row['branch_city'].'</option>';}
									}
										echo $branch1; ?>
									</select>
									</div>
									<div class="col-lg-3">
									<label class="col-form-label">To<span class="text-danger"> *</span></label><br>
									<select name="to_branch" class="btn btn-info dropdown-toggle dropdown-toggle-split" required style="background-color: white;color: black;width: 160px; height: 40px;" >
										<?= $branch2; ?>
									</select>
									</div>
									<div class="col-lg-3">
									<label class="col-form-label">Date<span class="text-danger"> *</span></label><br>
									<input type="text" name="date" class="form-control" placeholder="dd/mm/yyyy" required pattern="^(0[1-9]|[12][0-9]|3[01])/(0[1-9]|1[012])/(19|20)\d\d$" oninvalid="this.setCustomValidity('Plase Enter date like 21/01/2021')" oninput="this.setCustomValidity('')" value="<?= (isset($det['date']))?$det['date']:date('d/m/Y'); ?>">
									</div><br>
								</div>
								<input type="hidden" name="i" id="i" value="<?=$no_row?>">
								<input type="hidden" name="edit" value="<?= (isset($_GET['seid'])?'1':'0')?>">
								<input type="hidden" name="seid" value="<?= (isset($_GET['seid'])?$_GET['seid']:'')?>">
								<br>&emsp;<button class="btn btn-primary" type="submit" id="submit" name="submit">Submit</button>
								</form>
								</div>
							</div>
						</div>
					</div>
					</div>
							
						</div>
					</div>
				
				</div>			
			</div>
			<!-- /Main Wrapper -->
		
        </div>
		<!-- /Main Wrapper -->
		
		<!-- jQuery -->
        <script src="assets/js/jquery-3.2.1.min.js"></script>
		
		<!-- Bootstrap Core JS -->
        <script src="assets/js/popper.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
		
		<!-- Slimscroll JS -->
        <script src="assets/plugins/slimscroll/jquery.slimscroll.min.js"></script>
		
		<!-- Custom JS -->
		<script  src="assets/js/script.js"></script>
		
    </body>
</html>
