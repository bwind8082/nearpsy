<?php
include 'includes/session.php';
	
if(isset($_SESSION['user'])){

	if(isset($_POST['update'])){

		$name=$_POST['name'];
		$email=$_POST['email'];
		$mobileno=$_POST['mobileno'];
		$gender=(int)$_POST['gender'];
		$dob = str_replace('/', '-', $_POST['dob']);
		$dob=date('Y-m-d', strtotime($dob));
		$doc_type=$_POST['doc_type'];
		$bio=$_POST['bio'];
		$cname=$_POST['cname'];
		$cadd=$_POST['cadd'];
		$address_line_1=$_POST['address_line_1'];
		$address_line_2=$_POST['address_line_2'];
		$city=$_POST['city'];
		$state=$_POST['state'];
		$country=$_POST['country'];
		$postal_code=$_POST['postal_code'];
		$fee=$_POST['fee'];
		$services=$_POST['services'];
		$specialist=$_POST['specialist'];
		$no_ed=(int)$_POST['no_ed'];
		$degree=NULL;
		$institute=NULL;
		$year_of_completion=NULL;
		for($i=0;$i<$no_ed;$i++){
			$degree.=$_POST['degree_'.$i.''].',';
			$institute.=$_POST['institute_'.$i.''].',';
			$year_of_completion.=$_POST['year_of_completion_'.$i.''].',';
		}
		if($no_ed!=0){
		$degree=rtrim($degree, ",");
		$institute=rtrim($institute, ",");
		$year_of_completion=rtrim($year_of_completion, ",");}

		$no_aw=(int)$_POST['no_aw'];
		$award=NULL;
		$a_year=NULL;
		for($i=0;$i<$no_aw;$i++){
			$award.=$_POST['award_'.$i.''].',';
			$a_year.=$_POST['a_year_'.$i.''].',';
		}
		if($no_aw!=0){
		$award=rtrim($award, ",");
		$a_year=rtrim($a_year, ",");}

		$no_we=(int)$_POST['no_we'];
		$hname=NULL;
		$etime=NULL;
		$designation=NULL;
		for($i=0;$i<$no_we;$i++){
			$hname.=$_POST['hname_'.$i.''].',';
			$etime.=$_POST['etime_'.$i.''].',';
			$designation.=$_POST['designation_'.$i.''].',';
		}
		if($no_we!=0){
		$hname=rtrim($hname, ",");
		$etime=rtrim($etime, ",");
		$designation=rtrim($designation, ",");}

		$conn = $pdo->open();
		try{
			$stmt=$conn->prepare("UPDATE users SET is_first_time=0 WHERE id=:uid");
			$stmt->execute([':uid'=>$user['id']]);
		}
		catch(PDOException $e){
			$_SESSION['error'].= $e->getMessage();
		}

		try{
			$stmt=$conn->prepare("UPDATE users SET name=:name,gender=:gender,date_of_birth=:dob WHERE id=:uid");
			$stmt->execute([':name'=>$name,':gender'=>$gender,':dob'=>$dob,':uid'=>$user['id']]);
			$_SESSION['success'] = 'Account updated successfully';
			}
			catch(PDOException $e){
			$_SESSION['error'].= $e->getMessage();
			}

			if($mobileno!=$user['mobileno'] || $email!=$user['email'])
			{
				$stmt = $conn->prepare("SELECT COUNT(*) AS numrows FROM users WHERE mobileno=:mobileno");
				$stmt1 = $conn->prepare("SELECT COUNT(*) AS numrows FROM users WHERE email=:email");
				$stmt->execute(['mobileno'=>$mobileno]);
				$stmt1->execute(['email'=>$email]);
				$row = $stmt->fetch();
				$row1 = $stmt1->fetch();
					if($row['numrows'] == 0){
					try{
					$stmt=$conn->prepare("UPDATE users SET email=:email WHERE id=:uid");
					$stmt->execute([':email'=>$email,':uid'=>$user['id']]);
					$_SESSION['success'] = 'Account updated successfully';
					}
					catch(PDOException $e){
						$_SESSION['error'].= "<br>".$e->getMessage();
					}}
					else
						$_SESSION['error'].= '<br>Mobile No is already Registered';

					if($row1['numrows'] == 0){
						try{
						$stmt=$conn->prepare("UPDATE users SET mobileno=:mobileno WHERE id=:uid");
						$stmt->execute([':mobileno'=>$mobileno,':uid'=>$user['id']]);
						$_SESSION['success'] = 'Account updated successfully';
						}
						catch(PDOException $e){
							$_SESSION['error'].= "<br>".$e->getMessage();
						}

					}
					else
						$_SESSION['error'].= '<br>Email is already Registered';
			}
			

				try{

					$stmt = $conn->prepare("UPDATE doctor SET fees=:fee,doc_type=:doc_type,about_me=:bio,services=:services,specializations=:specialist,address_line_1=:address_line_1,address_line_2=:address_line_2,city=:city,state=:state,country=:country,postal_code=:postal_code,degree=:degree,institute=:institute,year_of_completion=:year_of_completion,award=:award,a_year=:a_year,h_name=:hname,etime=:etime,designation=:designation WHERE user_id=:uid");
					$stmt->execute([':fee'=>$fee,':doc_type'=>$doc_type,':bio'=>$bio,':services'=>$services,':specialist'=>$specialist,':address_line_1'=>$address_line_1,':address_line_2'=>$address_line_2,':city'=>$city,':state'=>$state,':country'=>$country,':postal_code'=>$postal_code,':degree'=>$degree,':institute'=>$institute,':year_of_completion'=>$year_of_completion,':award'=>$award,':a_year'=>$a_year,':hname'=>$hname,':etime'=>$etime,':designation'=>$designation,':uid'=>$user['id']]);

					$_SESSION['success'] = 'Account updated successfully';
				}
				catch(PDOException $e){
					$_SESSION['error'].= "<br>".$e->getMessage();
				}
				
				try{
					$stmt=$conn->prepare("SELECT doctor.id as did from doctor join users WHERE doctor.user_id=users.id and users.id=:uid");
					$stmt->execute([':uid'=>$user['id']]);
					$row=$stmt->fetch();
					$did=$row['did'];
					$stmt=$conn->prepare("SELECT COUNT(*) as d from hospitals WHERE d_id=:did");
					$stmt->execute([':did'=>$did]);
					$row=$stmt->fetch();
					if($row['d']==0)
					$stmt=$conn->prepare("INSERT INTO hospitals(d_id, name, address) VALUES (:did,:cname,:cadd)");
					else
					$stmt=$conn->prepare("UPDATE hospitals SET name=:cname,address=:cadd WHERE d_id=:did");
						$stmt->execute([':cname'=>$cname,':cadd'=>$cadd,':did'=>$did]);
						$_SESSION['success'] = 'Account updated successfully';
				}
				catch(PDOException $e){
					$_SESSION['error'].= "<br>".$e->getMessage();
				}
				
				$pdo->close();
	}
	else
		$_SESSION['error'].= '<br>Fill up edit form first';

	header('location: doctor-profile-settings.php');
}
else
header('location: index.php');