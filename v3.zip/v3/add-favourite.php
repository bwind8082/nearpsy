<?php include 'includes/session.php'; ?>
<?php
$conn = $pdo->open();
$output = array('error'=>false,'message'=>'','css'=>'');

$did=$_POST['did'];

if(isset($_SESSION['user'])){
		try{
			$stmt = $conn->prepare("SELECT favourite_did from patient where user_id=:uid");
			$stmt->execute([':uid'=>$user['id']]);
			$row = $stmt->fetch();
			if(is_null($row['favourite_did'])){
				$stmt = $conn->prepare("UPDATE patient set favourite_did=:did where user_id=:uid");
				$stmt->execute([':did'=>$did,':uid'=>$user['id']]);
				$output['css']='fav';
			
			}
			else{
				$d=explode(',',$row['favourite_did']);

				if(!in_array($did, $d)){

				$stmt = $conn->prepare("UPDATE patient set favourite_did=CONCAT(favourite_did, ',', :did) where user_id=:uid");
				$stmt->execute([':did'=>$did,':uid'=>$user['id']]);
				$output['css']='fav';

				}

				else{

				$stmt = $conn->prepare("UPDATE patient set favourite_did=REPLACE(favourite_did,:did,'') where user_id=:uid");
				$stmt->execute([':did'=>$did,':uid'=>$user['id']]);
				$stmt = $conn->prepare("UPDATE patient set favourite_did=REPLACE(favourite_did,',,',',') where user_id=:uid");
				$stmt->execute([':uid'=>$user['id']]);

				$output['css']='no';

				$stmt = $conn->prepare("select RIGHT(favourite_did,1) as l from patient where user_id=:uid");
				$stmt->execute([':uid'=>$user['id']]);
				$row = $stmt->fetch();
				if($row['l']==','){
					$stmt = $conn->prepare("UPDATE patient set favourite_did=SUBSTR(favourite_did, 1, LENGTH(favourite_did) - 1) where user_id=:uid");
					$stmt->execute([':uid'=>$user['id']]);
				}

				$stmt = $conn->prepare("SELECT favourite_did from patient where user_id=:uid");
				$stmt->execute([':uid'=>$user['id']]);
				$row = $stmt->fetch();
				
				if($row['favourite_did']==''){
					$stmt = $conn->prepare("UPDATE patient set favourite_did=NULL where user_id=:uid");
					$stmt->execute([':uid'=>$user['id']]);
				
				}
				
				}
			}
		}
		catch(PDOException $e){
			$output['message'] = $e->getMessage();
		}
}

$pdo->close();
	echo json_encode($output);
?>