<?php include 'includes/session.php'; ?>
<!DOCTYPE html> 
<html lang="en">
<?php
$conn = $pdo->open();
try{
$stmt = $conn->prepare("SELECT * FROM patient as p JOIN users WHERE p.user_id = users.id AND users.id=:uid");
$stmt->execute([":uid"=>$user['id']]);
$row = $stmt->fetch();
$age=$user['date_of_birth'];
$age = date_diff(date_create($user['date_of_birth']), date_create(date("Y-m-d")));
$age=$age->format('%y');
}
catch(PDOException $e){
			$_SESSION['error'] = $e->getMessage();
}
$pdo->close();
?>
<head>
		<meta charset="utf-8">
		<title>NearPsy</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
		
		<!-- Favicons -->
		<link href="assets/img/favicon.png" rel="icon">
		
		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="assets/css/bootstrap.min.css">
		
		<!-- Fontawesome CSS -->
		<link rel="stylesheet" href="assets/plugins/fontawesome/css/fontawesome.min.css">
		<link rel="stylesheet" href="assets/plugins/fontawesome/css/all.min.css">
		
		<!-- Datetimepicker CSS -->
		<link rel="stylesheet" href="assets/css/bootstrap-datetimepicker.min.css">
		
		<!-- Select2 CSS -->
		<link rel="stylesheet" href="assets/plugins/select2/css/select2.min.css">
		
		<!-- Main CSS -->
		<link rel="stylesheet" href="assets/css/style.css">
	
	</head>
	<body>

		<!-- Main Wrapper -->
		<div class="main-wrapper">
		
			<!-- Header -->
			<?php include 'includes/navbar.php'; ?>
			<!-- /Header -->
			
			<!-- Breadcrumb -->
			<div class="breadcrumb-bar">
				<div class="container-fluid">
					<div class="row align-items-center">
						<div class="col-md-12 col-12">
							<nav aria-label="breadcrumb" class="page-breadcrumb">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="index.php">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Profile Settings</li>
								</ol>
							</nav>
							<h2 class="breadcrumb-title">Profile Settings</h2>
						</div>
					</div>
				</div>
			</div>
			<!-- /Breadcrumb -->
			
			<!-- Page Content -->
			<div class="content">
				<div class="container-fluid">
					<div>
						<?php
						      if(isset($_SESSION['error'])){
						        echo "
						          <div class='callout callout-danger text-center'>
						            <p>".$_SESSION['error']."</p><br> 
						          </div>
						        ";
						        unset($_SESSION['error']);
						      }
						      if(isset($_SESSION['success'])){
						        echo "
						          <div class='callout callout-success text-center'>
						            <p>".$_SESSION['success']."</p><br>
						          </div>
						        ";
						        unset($_SESSION['success']);
						      }
						?>
						</div>
					<div class="row">
					
						<!-- Profile Sidebar -->
						<div class="col-md-5 col-lg-4 col-xl-3 theiaStickySidebar">
						<?php include 'includes/profile-sidebar.php' ?>
						</div>
						<!-- /Profile Sidebar -->
						
						<div class="col-md-7 col-lg-8 col-xl-9">
							<div class="card">
								<div class="card-body">
									
									<!-- Profile Settings Form -->
									
										<div class="row form-row">
											<div class="col-12 col-md-12">
												<div class="form-group">
													<div class="change-avatar">
														<div class="profile-img">
															<img src="assets/img/patients/<?php echo $row['img'];?>" alt="User Image">
														</div>
														<form action="upload.php" method="POST" enctype="multipart/form-data">
														<div class="upload-img">
															<div class="change-photo-btn">
																<span><i class="fa fa-upload"></i> Select Photo</span>
															<input type="file" class="upload" name="fileToUpload" id="fileToUpload">
															<input type="hidden" name="p_img" value='1'>
														</div><button type="submit" class="change-photo-btn" style="border:none;" name="upload">Upload</button>
															<small class="form-text text-muted">Allowed JPG, GIF or PNG. Max size of 2MB</small>
														</div>
													</div>
												</div>
											</div></form>

											<div class="col-12 col-md-6">
												<div class="form-group">
													<form action="pat_update.php" method="POST">
													<label>Name<span class="text-danger"> *</span></label>
													<input type="text" class="form-control" value="<?php echo $row['name'];?>" name="name" required pattern="[a-zA-Z .]{3,}" oninvalid="this.setCustomValidity('Name shoud be atleast 3 Charcter long')" oninput="this.setCustomValidity('')">
												</div>
											</div>
											<div class="col-12 col-md-6">
												<div class="form-group">
													<label>Gender<span class="text-danger"> *</span></label>
													<select class="form-control select" name="gender" required oninvalid="this.setCustomValidity('Plase Select Gender')" onchange="this.setCustomValidity('')">
													<option value="" <?php echo ($row['gender']==0)?'selected':''; ?>>Select</option>
													<option value="1" <?php echo ($row['gender']==1)?'selected':''; ?>>Male</option>
													<option value="2" <?php echo ($row['gender']==2)?'selected':''; ?>>Female</option>
												</select>
												</div>
											</div>
											<div class="col-12 col-md-6">
												<div class="form-group">
													<label>Date of Birth<span class="text-danger"> *</span></label>
													<div class="cal-icon">
														<input type="text" class="form-control datetimepicker" value="<?php echo date("d/m/Y",strtotime($row['date_of_birth']));?>" required name="dob" oninvalid="this.setCustomValidity('Plase Enter Date of Birth')" onchange="this.setCustomValidity('')">
													</div>
												</div>
											</div>
											<div class="col-12 col-md-6">
												<div class="form-group">
													<label>Blood Group</label>
													<select class="form-control select" name="blood_group">
														<option value="A-" <?php echo ($row['blood_group']=='A-')?'selected':''; ?>>A-</option>
														<option value="A+" <?php echo ($row['blood_group']=='A+')?'selected':''; ?>>A+</option>
														<option value="B-" <?php echo ($row['blood_group']=='B-')?'selected':''; ?>>B-</option>
														<option value="B+" <?php echo ($row['blood_group']=='B+')?'selected':''; ?>>B+</option>
														<option value="AB-" <?php echo ($row['blood_group']=='AB-')?'selected':''; ?>>AB-</option>
														<option value="AB+" <?php echo ($row['blood_group']=='AB+')?'selected':''; ?>>AB+</option>
														<option value="O-" <?php echo ($row['blood_group']=='O-')?'selected':''; ?>>O-</option>
														<option value="O+" <?php echo ($row['blood_group']=='O+')?'selected':''; ?>>O+</option>
													</select>
												</div>
											</div>
											<div class="col-12 col-md-6">
												<div class="form-group">
													<label>Email ID<span class="text-danger"> *</span></label>
													<input type="email" class="form-control" value="<?php echo $row['email'];?>" name="email" required pattern="^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$" oninvalid="this.setCustomValidity('Plase Enter Valid Email Address')" oninput="this.setCustomValidity('')">
												</div>
											</div>
											<div class="col-12 col-md-6">
												<div class="form-group">
													<label>Mobile<span class="text-danger"> *</span></label>
													<input type="text" class="form-control" value="<?php echo $row['mobileno'];?>" name="mobileno" required pattern="[0-9]{10}" oninvalid="this.setCustomValidity('Plase Enter your 10 digit mobile No.')" oninput="this.setCustomValidity('')">
												</div>
											</div>
											<div class="col-12">
												<div class="form-group">
												<label>Address</label>
													<input type="text" class="form-control" name="address" value="<?php echo $row['address'];?>">
												</div>
											</div>
											<div class="col-12 col-md-6">
												<div class="form-group">
													<label>City</label>
													<input type="text" class="form-control" name="city" value="<?php echo $row['city'];?>">
												</div>
											</div>
											<div class="col-12 col-md-6">
												<div class="form-group">
													<label>State</label>
													<input type="text" class="form-control" name="state" value="<?php echo $row['state'];?>">
												</div>
											</div>
											<div class="col-12 col-md-6">
												<div class="form-group">
													<label>Country</label>
													<input type="text" class="form-control" name="country" value="<?php echo $row['country'];?>">
												</div>
											</div>
											<div class="col-12 col-md-6">
												<div class="form-group">
													<label>Postal Code</label>
													<input type="text" class="form-control" name="postal_code" value="<?php echo $row['postal_code'];?>" pattern="[0-9]{6}" oninvalid="this.setCustomValidity('Plase Enter Valid Postal Code')" onchange="this.setCustomValidity('')">
												</div>
											</div>
										</div>
										<div class="submit-section">
											<button type="submit" class="btn btn-primary submit-btn" name="update">Save Changes</button>
										</div>
									</form>
									<!-- /Profile Settings Form -->
									
								</div>
							</div>
						</div>
					</div>
				</div>

			</div>		
			<!-- /Page Content -->
   
			<!-- Footer -->
			<?php include 'includes/footer.php'; ?>
			<!-- /Footer -->
		   
		</div>
		<!-- /Main Wrapper -->
	  
		<!-- jQuery -->
		<script src="assets/js/jquery.min.js"></script>
		
		<!-- Bootstrap Core JS -->
		<script src="assets/js/popper.min.js"></script>
		<script src="assets/js/bootstrap.min.js"></script>
		
		<!-- Select2 JS -->
		<script src="assets/plugins/select2/js/select2.min.js"></script>
		
		<!-- Datetimepicker JS -->
		<script src="assets/js/moment.min.js"></script>
		<script src="assets/js/bootstrap-datetimepicker.min.js"></script>
		
		<!-- Sticky Sidebar JS -->
        <script src="assets/plugins/theia-sticky-sidebar/ResizeSensor.js"></script>
        <script src="assets/plugins/theia-sticky-sidebar/theia-sticky-sidebar.js"></script>
		
		<!-- Custom JS -->
		<script src="assets/js/script.js"></script>
		
	</body>

</html>