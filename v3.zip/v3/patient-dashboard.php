<?php include 'includes/session.php'; ?>
<!DOCTYPE html> 
<html lang="en">
<?php
$conn = $pdo->open();
try{
$stmt = $conn->prepare("SELECT p.id as pid,img,name,date_of_birth,city,state FROM patient as p JOIN users WHERE p.user_id = users.id AND users.id=:uid");
$stmt->execute([":uid"=>$user['id']]);
$row = $stmt->fetch();
$age=$user['date_of_birth'];
$age = date_diff(date_create($user['date_of_birth']), date_create(date("Y-m-d")));
$age=$age->format('%y');
$pid=$row['pid'];
}
catch(PDOException $e){
	$_SESSION['error'] = $e->getMessage();
}
$pdo->close();
?>
<head>
		<meta charset="utf-8">
		<title>OHAS</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
		
		<!-- Favicons -->
		<link href="assets/img/favicon.png" rel="icon">
		
		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="assets/css/bootstrap.min.css">
		
		<!-- Fontawesome CSS -->
		<link rel="stylesheet" href="assets/plugins/fontawesome/css/fontawesome.min.css">
		<link rel="stylesheet" href="assets/plugins/fontawesome/css/all.min.css">
		
		<!-- Datetimepicker CSS -->
		<link rel="stylesheet" href="assets/css/bootstrap-datetimepicker.min.css">
		
		<!-- Main CSS -->
		<link rel="stylesheet" href="assets/css/style.css">
	
	</head>
	<body>

		<!-- Main Wrapper -->
		<div class="main-wrapper">
		
			<!-- Header -->
			<?php include 'includes/navbar.php'; ?>
			<!-- /Header -->
			
			<!-- Breadcrumb -->
			<div class="breadcrumb-bar">
				<div class="container-fluid">
					<div class="row align-items-center">
						<div class="col-md-12 col-12">
							<nav aria-label="breadcrumb" class="page-breadcrumb">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="index.php">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Dashboard</li>
								</ol>
							</nav>
							<h2 class="breadcrumb-title">Dashboard</h2>
						</div>
					</div>
				</div>
			</div>
			<!-- /Breadcrumb -->
			
			<!-- Page Content -->
			<div class="content">
				<div class="container-fluid">

					<div class="row">
						<div class="col-md-5 col-lg-4 col-xl-3 theiaStickySidebar">
						
							<!-- Profile Widget -->
							<?php include 'includes/profile-sidebar.php'; ?>
							<!-- /Profile Widget -->
														
						</div>

						<div class="col-md-7 col-lg-8 col-xl-9 dct-appoinment">
							<div class="card">
								<div class="card-body pt-0">
									<div class="user-tabs">
										<ul class="nav nav-tabs nav-tabs-bottom nav-justified flex-wrap">
											<li class="nav-item">
												<a class="nav-link active" href="#pat_appointments" data-toggle="tab">Appointments</a>
											</li>
											<li class="nav-item">
												<a class="nav-link" href="#pres" data-toggle="tab"><span>Prescription</span></a>
											</li>
											<li class="nav-item">
												<a class="nav-link" href="#medical" data-toggle="tab"><span class="med-records">Medical Records</span></a>
											</li>
											<li class="nav-item">
												<a class="nav-link" href="#billing" data-toggle="tab"><span>Billing</span></a>
											</li> 
										</ul>
									</div>
									<div class="tab-content">
										
										<!-- Appointment Tab -->
										<div id="pat_appointments" class="tab-pane fade show active">
											<div class="card card-table mb-0">
												<div class="card-body">
													<div class="table-responsive">
														<table class="table table-hover table-center mb-0">
															<thead>
																<tr>
																	<th>Doctor</th>
																	<th>Appt Date</th>
																	<th>Appt Type</th>
																	<th>Payment Type</th>
																	<th>Amount</th>
																	<th>Appt Status</th>
																</tr>
															</thead>
															<tbody>
																<?php
																	$conn = $pdo->open();
																	$bgc=['Pending'=>'warning','Cancelled'=>'danger','Confirm'=>'success','Completed'=>'info'];
																	try{
																	$stmt = $conn->prepare("SELECT doctor.id as did,img,name,doc_type,a_date,a_time,appointment_type,amount,status,p_type FROM appointments JOIN doctor JOIN users JOIN payment WHERE users.id = doctor.user_id AND doctor.id=appointments.did AND payment.id=appointments.payment_id AND appointments.pid=:pid ORDER BY appointments.id DESC");
																	$stmt->execute([":pid"=>$pid]);
																	}
																	catch(PDOException $e){
																				$_SESSION['error'] = $e->getMessage();
																	}
																	$pdo->close();
																foreach ($stmt as $row) {
																echo'
																<tr>
																	<td>
																		<h2 class="table-avatar">
																			<a href="doctor-profile.php?id='.$row['did'].'" class="avatar avatar-sm mr-2">
																				<img class="avatar-img rounded-circle" src="assets/img/doctors/'.$row['img'].'" alt="User Image">
																			</a>
																			<a href="doctor-profile.php?id='.$row['did'].'">Dr. '.$row['name'].' <span>'.$row['doc_type'].'</span></a>
																		</h2>
																	</td>
																	<td>'.$row['a_date'].' <span class="d-block text-info">'.$row['a_time'].'</span></td>
																	<td>'.$row['appointment_type'].'</td>
																	<td>'.$row['p_type'].'</td>
																	<td>&#8377; '.$row['amount'].'</td>
																	<td><span class="badge badge-pill bg-'.$bgc[$row['status']].'-light">'.$row['status'].'</span></td>
																</tr>';}?>
															</tbody>
														</table>
													</div>
												</div>
											</div>
										</div>
										<!-- /Appointment Tab -->
										
										<!-- Prescription Tab -->
										<div class="tab-pane fade" id="pres">
											<div class="card card-table mb-0">
												<div class="card-body">
													<div class="table-responsive">
														<table class="table table-hover table-center mb-0">
															<thead>
																<tr>
																	<th>ID</th>
																	<th>Date </th>									
																	<th>Created by </th>
																	<th></th>
																</tr>     
															</thead>
															<tbody>
																<?php
																	$conn = $pdo->open();
																	
																	try{
																	$stmt = $conn->prepare("SELECT prescription.id as prid,doctor.id as did,doctor.user_id as duid,img,name,doc_type,`date` FROM doctor JOIN users JOIN prescription WHERE users.id = doctor.user_id AND doctor.id=prescription.did AND prescription.pid=:pid ORDER BY prescription.id DESC");
																	$stmt->execute([":pid"=>$pid]);
																	}
																	catch(PDOException $e){
																				$_SESSION['error'] = $e->getMessage();
																	}
																	$pdo->close();
																foreach ($stmt as $row) {
																echo'
																<tr>
																	<td>#PR-'.$row['prid'].'</td>
																	<td>'.$row['date'].'</td>
																	<td>
																		<h2 class="table-avatar">
																			<a href="doctor-profile.php?id='.$row['did'].'" class="avatar avatar-sm mr-2">
																				<img class="avatar-img rounded-circle" src="assets/img/doctors/'.$row['img'].'" alt="User Image">
																			</a>
																			<a href="doctor-profile.php?id='.$row['did'].'">Dr. '.$row['name'].' <span>'.$row['doc_type'].'</span></a>
																		</h2>
																	</td>
																	<td class="text-right">
																		<div class="table-action">
																			<a href="prescription-view.php?prid='.$row['prid'].'" class="btn btn-sm bg-info-light">
																				<i class="far fa-eye"></i> View
																			</a>
																		</div>
																	</td>
																</tr>';}?>
																
															</tbody>	
														</table>
													</div>
												</div>
											</div>
										</div>
										<!-- /Prescription Tab -->

										<!-- Medical Records Tab -->
										<div class="tab-pane fade" id="medical">
											<div class="card card-table mb-0">
												<div class="card-body">
													<div class="table-responsive">
														<table class="table table-hover table-center mb-0">
															<thead>
																<tr>
																	<th>ID</th>
																	<th>Date </th>
																	<th>Description</th>
																	<th>Attachment</th>
																	<th>Created By</th>
																</tr>     
															</thead>
															<tbody>
																<?php
																	$conn = $pdo->open();
																	
																	try{
																	$stmt = $conn->prepare("SELECT medical_record.id as mrid,doctor.id as did,doctor.user_id as duid,img,name,doc_type,`date`,description,attachment FROM doctor JOIN users JOIN medical_record WHERE users.id = doctor.user_id AND doctor.id=medical_record.did AND medical_record.pid=:pid ORDER BY medical_record.id DESC");
																	$stmt->execute([":pid"=>$pid]);
																	}
																	catch(PDOException $e){
																		$_SESSION['error'] = $e->getMessage();
																	}
																	$pdo->close();
																	$i=-1;
																foreach ($stmt as $row) {
																echo'
																<tr>
																	<td><a href="javascript:void(0);">#MR-'.$row['mrid'].'</a></td>
																	<td>'.$row['date'].'</td>
																	<td>'.$row['description'].'</td>
																	<td>'.(!(is_null($row['attachment']))?'<a href="assets/m_file/'.$row['attachment'].'">MR_'.$row['attachment'].'</a>':'').'</td>
																	<td>
																		<h2 class="table-avatar">
																			<a href="doctor-profile.php?id='.$row['did'].'" class="avatar avatar-sm mr-2">
																				<img class="avatar-img rounded-circle" src="assets/img/doctors/'.$row['img'].'" alt="User Image">
																			</a>
																			<a href="doctor-profile.php?id='.$row['did'].'">Dr. '.$row['name'].' <span>'.$row['doc_type'].'</span></a>
																		</h2>
																	</td>
																</tr>';}
																?>
																
															</tbody>  	
														</table>
													</div>
												</div>
											</div>
										</div>
										<!-- /Medical Records Tab -->
										
										<!-- Billing Tab -->
										<div class="tab-pane" id="billing">
											<div class="card card-table mb-0">
												<div class="card-body">
													<div class="table-responsive">
													
														<table class="table table-hover table-center mb-0">
															<thead>
																<tr>
																	<th>Invoice No</th>
																	<th>Doctor</th>
																	<th>Payment Type</th>
																	<th>Amount</th>
																	<th>Paid On</th>
																</tr>
															</thead>
															<tbody>
																<?php
																	$conn = $pdo->open();
																	try{
																	$stmt = $conn->prepare("SELECT doctor.id as did,appointments.id as aid,img,name,doc_type,a_date,amount,p_type FROM appointments JOIN doctor JOIN users JOIN payment WHERE users.id = doctor.user_id AND doctor.id=appointments.did AND payment.id=appointments.payment_id AND appointments.pid=:pid ORDER BY appointments.id DESC");
																	$stmt->execute([":pid"=>$pid]);
																	}
																	catch(PDOException $e){
																				$_SESSION['error'] = $e->getMessage();
																	}
																	$pdo->close();
																foreach ($stmt as $row) {
																echo'
																<tr>
																	<td>
																		<a href="invoice-view.php?aid='.$row['aid'].'">#INV-'.$row['aid'].'</a>
																	</td>
																	<td>
																		<h2 class="table-avatar">
																			<a href="doctor-profile.php?id='.$row['did'].'" class="avatar avatar-sm mr-2">
																				<img class="avatar-img rounded-circle" src="assets/img/doctors/'.$row['img'].'" alt="User Image">
																			</a>
																			<a href="doctor-profile.php?id='.$row['did'].'">Dr. '.$row['name'].' <span>'.$row['doc_type'].'</span></a>
																		</h2>
																	</td>
																	<td>'.$row['p_type'].'</td>
																	<td>&#8377; '.$row['amount'].'</td>
																	<td>'.$row['a_date'].'</td>
																	<td class="text-right">
																		<div class="table-action">
																			<a href="invoice-view.php?aid='.$row['aid'].'" class="btn btn-sm bg-info-light">
																				<i class="far fa-eye"></i> View
																			</a>
																		</div>
																	</td>
																</tr>';}?>
															</tbody>
														</table>
													</div>
												</div>
											</div>
										</div>
										<!-- Billing Tab -->
												
									</div>
								</div>
							</div>
						</div>
					</div>

				</div>

			</div>		
			<!-- /Page Content -->
   
			<!-- Footer -->
			<?php include 'includes/footer.php'; ?>
			<!-- /Footer -->
		   
		</div>
		<!-- /Main Wrapper -->
		
	  
		<!-- jQuery -->
		<script src="assets/js/jquery.min.js"></script>
		
		
		<!-- Bootstrap Core JS -->
		<script src="assets/js/popper.min.js"></script>
		<script src="assets/js/bootstrap.min.js"></script>
		
		<!-- Datetimepicker JS -->
		<script src="assets/js/moment.min.js"></script>
		<script src="assets/js/bootstrap-datetimepicker.min.js"></script>
		
		<!-- Sticky Sidebar JS -->
        <script src="assets/plugins/theia-sticky-sidebar/ResizeSensor.js"></script>
        <script src="assets/plugins/theia-sticky-sidebar/theia-sticky-sidebar.js"></script>
		
		<!-- Custom JS -->
		<script src="assets/js/script.js"></script>
		
	</body>

</html>