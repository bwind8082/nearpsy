<?php include 'includes/session.php'; ?>
<!DOCTYPE html> 
<html lang="en">

<head>
		<meta charset="utf-8">
		<title>Psychiatrists in Vadodara</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
		
		<!-- Favicons -->
		<link href="assets/img/favicon.png" rel="icon">
		
		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="assets/css/bootstrap.min.css">
		
		<!-- Fontawesome CSS -->
		<link rel="stylesheet" href="assets/plugins/fontawesome/css/fontawesome.min.css">
		<link rel="stylesheet" href="assets/plugins/fontawesome/css/all.min.css">
		
		<!-- Main CSS -->
		<link rel="stylesheet" href="assets/css/style.css">
	
	</head>
	<body>

		<!-- Main Wrapper -->
		<div class="main-wrapper">
		
			<!-- Header -->
			<?php include 'includes/navbar.php'; ?>
			<!-- /Header -->
			
			<!-- Breadcrumb -->
			<div class="breadcrumb-bar">
				<div class="container-fluid">
					<div class="row align-items-center">
						<div class="col-md-12 col-12">
							<nav aria-label="breadcrumb" class="page-breadcrumb">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="index.php">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Psychiatrists in Vadodara</li>
								</ol>
							</nav>
					
						</div>
					</div>
				</div>
			</div>
			<!-- /Breadcrumb -->
				
			<!-- Page Content -->
			<div class="content">
				<div class="container">
					<div class="row">
						<div class="col-12">
							<div class="terms-content">
								<div class="terms-text" style="text-align: justify; text-justify: inter-word;">
									<p>In general, psychiatrists work to diagnose diseases of the brain and suggest treatment cycles to treat the disease. It takes a different amount of time to detect and be treated for different psychological disorders. For example, psychiatrists treat diseases like Alzheimer's disease and attention deficit hyperactivity disorder (ADHD). Regularly seeing renowned psychiatrists can be helpful for detecting any disorder early and treating it promptly. Government aided clinics are also run by many psychiatrists, so patients with lower financial backgrounds can obtain treatment here. To be able to welcome patients from all income levels, all of these doctors maintain affordable rates. Payments are accepted in cash and by most kinds of cards. In Vadodara, you will find a number of psychiatrists who are available to you.</p><br>																</div>
						</div>
					</div>
				</div>
<!-- Popular Section -->
<section class="section section-doctor">
				<div class="container-fluid">
				   <div class="row">
						<div class="col-lg-4">
							<div class="section-header ">
								<h3>Connect with India’s top 1% psychologist and psychiatrist to get best online therapy within 24 hours. </h3><br>
								
							</div>
						
							<div class="about-content">
								<p>Here you find top 1% Doctores for you. Just Register and  book an Appointment.</p>
								<p>We provide 24x7 online service and Wating for you take appointment now.</p>					
								<a href="/aboutus.php">Read More..</a>
							</div>
						</div>
						<div class="col-lg-8">
							<div class="doctor-slider slider">
							
								<!-- Doctor Widget -->
								<?php
								$conn = $pdo->open();
								try{
								$s = $conn->prepare("SELECT COUNT(feedback.id) as nor,CAST(AVG(rating) AS INT) as rat FROM feedback WHERE did=:did ");
								$stmt = $conn->prepare("SELECT *,d.id as did FROM doctor as d JOIN users WHERE d.user_id = users.id LIMIT 8");
								$stmt->execute();

								foreach($stmt as $row){
								$s->execute([":did"=>$row['did']]);
								$rat=$s->fetch();
								echo'

								<div class="profile-widget">
									<div class="doc-img">
										<a href="doctor-profile.php?id='.$row['did'].'">
											<img class="" alt="Doctor Image" src="assets/img/doctors/'.$row['img'].'" width="300" height="228">
										</a>	
									</div>
									<div class="pro-content">
										<h3 class="title">
											<a href="doctor-profile.php?id='.$row['did'].'">'.$row['name'].'</a> 
											<i class="fas fa-check-circle verified"></i>
										</h3>
										<p class="speciality">'.str_replace("@@",",",$row['degree']).'</p>
										<div class="rating">
											<i class="fas fa-star '.(($rat['rat']>0)?'filled':'').'"></i>
											<i class="fas fa-star '.(($rat['rat']>1)?'filled':'').'"></i>
											<i class="fas fa-star '.(($rat['rat']>2)?'filled':'').'"></i>
											<i class="fas fa-star '.(($rat['rat']>3)?'filled':'').'"></i>
											<i class="fas fa-star '.(($rat['rat']>4)?'filled':'').'"></i>
											<span class="d-inline-block average-rating">('.((!is_null($rat))?$rat['nor']:'0').')</span>
										</div>
										<ul class="available-info">
											<li>
												<i class="fas fa-map-marker-alt"></i>'.$row['city'].','.$row['state'].'
											</li>
											<li>
												<i class="far fa-money-bill-alt"></i> &#8377; '.$row['fees'].' 
												
											</li>
										</ul>
										<div class="row row-sm">
											<div class="col-6">
												<a href="doctor-profile.php?id='.$row['did'].'" class="btn view-btn">View Profile</a>
											</div>
											<div class="col-6">
												<a href="booking.php?did='.$row['did'].'" class="btn book-btn">Book Now</a>
											</div>
										</div>
									</div>
								</div>'; }}
								catch(PDOException $e){
											$_SESSION['error'] = $e->getMessage();
								}
								$pdo->close();?>
								<!-- /Doctor Widget -->
							</div>
						</div>
				   </div>
				</div>
			</section>
			<!-- /Popular Section -->
			</div>		
			<!-- /Page Content -->
   
			<!-- Footer -->
			<?php include 'includes/footer.php'; ?>
			<!-- /Footer -->
		   
		</div>
		<!-- /Main Wrapper -->
	  
		<!-- jQuery -->
		<script src="assets/js/jquery.min.js"></script>
		
		<!-- Bootstrap Core JS -->
		<script src="assets/js/popper.min.js"></script>
		<script src="assets/js/bootstrap.min.js"></script>
		
		<!-- Custom JS -->
		<script src="assets/js/script.js"></script>
		
	</body>
</html>
