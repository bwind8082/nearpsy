<?php include 'includes/session.php'; ?>
<?php
if(isset($_POST['change_password'])){
	if($user['password']!=$_POST['old_password']){
		$_SESSION['error'] = "Old Password is Wrong!!";
	}
	else
	{	$conn = $pdo->open();
		try{
		$stmt = $conn->prepare("UPDATE users set password=:password WHERE id=:uid");
		$stmt->execute([":password"=>$_POST['new_password'],":uid"=>$user['id']]);
		$_SESSION['success']="Password Changed Successfully.";
		}
		catch(PDOException $e){
					$_SESSION['error'] = $e->getMessage();
		}
		$pdo->close();
	}
}
?>
<!DOCTYPE html> 
<html lang="en">
<?php
$conn = $pdo->open();
try{
if($user['type']==1){
$stmt = $conn->prepare("SELECT img,name,date_of_birth,city,state FROM patient as p JOIN users WHERE p.user_id = users.id AND users.id=:uid");
$stmt->execute([":uid"=>$user['id']]);
$row = $stmt->fetch();
$age=$user['date_of_birth'];
$age = date_diff(date_create($user['date_of_birth']), date_create(date("Y-m-d")));
$age=$age->format('%y');
}
else{
$stmt = $conn->prepare("SELECT img,name,degree FROM doctor as d JOIN users WHERE d.user_id = users.id AND users.id=:uid");
$stmt->execute([":uid"=>$user['id']]);
$row = $stmt->fetch();
}
}
catch(PDOException $e){
			$_SESSION['error'] = $e->getMessage();
}
$pdo->close();
?>	
<head>
		<meta charset="utf-8">
		<title>NearPsy</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
		
		<!-- Favicons -->
		<link href="assets/img/favicon.png" rel="icon">
		
		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="assets/css/bootstrap.min.css">
		
		<!-- Fontawesome CSS -->
		<link rel="stylesheet" href="assets/plugins/fontawesome/css/fontawesome.min.css">
		<link rel="stylesheet" href="assets/plugins/fontawesome/css/all.min.css">
		
		<!-- Main CSS -->
		<link rel="stylesheet" href="assets/css/style.css">
		
	</head>
	<body>

		<!-- Main Wrapper -->
		<div class="main-wrapper">
		
			<!-- Header -->
			<?php include 'includes/navbar.php'; ?>
			<!-- /Header -->
			
			<!-- Breadcrumb -->
			<div class="breadcrumb-bar">
				<div class="container-fluid">
					<div class="row align-items-center">
						<div class="col-md-12 col-12">
							<nav aria-label="breadcrumb" class="page-breadcrumb">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="index.php">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Change Password</li>
								</ol>
							</nav>
							<h2 class="breadcrumb-title">Change Password</h2>
						</div>
					</div>
				</div>
			</div>
			<!-- /Breadcrumb -->
			
			<!-- Page Content -->
			<div class="content">
				<div class="container-fluid">
							<div>
								<?php
							      if(isset($_SESSION['error'])){
							        echo "
							          <div class='callout callout-danger text-center'>
							            <p>".$_SESSION['error']."</p><br>
							          </div>
							        ";
							        unset($_SESSION['error']);
							      }

							      if(isset($_SESSION['success'])){
							        echo "
							          <div class='callout callout-success text-center'>
							            <p>".$_SESSION['success']."</p><br>
							          </div>
							        ";
							        unset($_SESSION['success']);
							      }
							    ?>
							</div>
					<div class="row">
						<div class="col-md-5 col-lg-4 col-xl-3 theiaStickySidebar">
						
							<!-- Profile Sidebar -->
							<?php
							if($user['type']==1){
								include 'includes/profile-sidebar.php';
							}
							else
								include 'includes/doc-profile-sidebar.php';
							?>
							<!-- /Profile Sidebar -->
							
						</div>
						<div class="col-md-7 col-lg-8 col-xl-9">
							<div class="card">
								<div class="card-body">
									<div class="row">
										<div class="col-md-12 col-lg-6">
										
											<!-- Change Password Form -->
											<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
												<div class="form-group">
													<label>Old Password</label>
													<input type="password" class="form-control" name="old_password" required pattern="^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*_=+-]).{6,}$" oninvalid="this.setCustomValidity('Password leanth Must be grater then 6 and it contain atleast 1 digit,1 Upper Case Latter,1 Lower Case Latter and 1 Special Charcter')" oninput="this.setCustomValidity('')">
												</div>
												<div class="form-group">
													<label>New Password</label>
													<input type="password" class="form-control" id="new_password" name="new_password" required pattern="^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*_=+-]).{6,}$" oninvalid="this.setCustomValidity('Password leanth Must be grater then 6 and it contain atleast 1 digit,1 Upper Case Latter,1 Lower Case Latter and 1 Special Charcter')" oninput="this.setCustomValidity('')">
												</div>
												<div class="form-group">
													<label>Confirm Password</label>
													<input type="password" class="form-control" id="confirm_password" name="confirm_password" required onfocusout="check_pass()">
												</div>
												<div id='pass_check' style="color: red;"></div><br>
												<div class="submit-section">
													<button type="submit" class="btn btn-primary submit-btn" id="change_password" name="change_password">Save Changes</button>
													<script type="text/javascript">
														function check_pass() {
														if(document.getElementById('new_password').value!=document.getElementById('confirm_password').value){
															document.getElementById('pass_check').innerHTML='Password and Confirm password does not match.'
															document.getElementById("change_password").disabled = true;
														}
														else{
															document.getElementById('pass_check').innerHTML=''
															document.getElementById("change_password").disabled = false;
													}}
													</script>
												</div>
											</form>										
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>		
			<!-- /Page Content -->
   
			<!-- Footer -->
			<?php include 'includes/footer.php'; ?>
			<!-- /Footer -->
		   
		</div>
		<!-- /Main Wrapper -->
	  
		<!-- jQuery -->
		<script src="assets/js/jquery.min.js"></script>
		
		<!-- Bootstrap Core JS -->
		<script src="assets/js/popper.min.js"></script>
		<script src="assets/js/bootstrap.min.js"></script>
		
		<!-- Sticky Sidebar JS -->
        <script src="assets/plugins/theia-sticky-sidebar/ResizeSensor.js"></script>
        <script src="assets/plugins/theia-sticky-sidebar/theia-sticky-sidebar.js"></script>
		
		<!-- Custom JS -->
		<script src="assets/js/script.js"></script>
		
	</body>
</html>