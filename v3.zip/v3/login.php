
<?php include 'includes/session.php'; ?>
<?php
  if(isset($_SESSION['user'])){
  	if($user['is_first_time']){
  		if($user['type']==1)
  			header('location: profile-settings.php');
  		else
    		header('location: doctor-profile-settings.php');
  	}
    else
    	header('location: index.php');
  } 
?>
<!DOCTYPE html> 
<html lang="en">

<?php include 'includes/header.php'; ?>
<body class="account-page">

		<!-- Main Wrapper -->
		<div class="main-wrapper">
		
			<!-- Header -->
			<?php include 'includes/navbar.php'; ?>
			<!-- /Header -->
			
			<!-- Page Content -->
			<div class="content">
				<div class="container-fluid">
					<div>
						<?php
						      if(isset($_SESSION['error'])){
						        echo "
						          <div class='callout callout-danger text-center'>
						            <p>".$_SESSION['error']."</p><br> 
						          </div>
						        ";
						        unset($_SESSION['error']);
						      }
						      if(isset($_SESSION['success'])){
						        echo "
						          <div class='callout callout-success text-center'>
						            <p>".$_SESSION['success']."</p><br>
						          </div>
						        ";
						        unset($_SESSION['success']);
						      }
						?>
						</div>
					<div class="row">
						<div class="col-md-8 offset-md-2">
							
							<!-- Login Tab Content -->
							<div class="account-content">
								<div class="row align-items-center justify-content-center">
		
									<div class="col-md-12 col-lg-6 login-right">
										<div class="login-header">
											<h3>Login</h3>
										</div>
										<form action="verify.php" method="POST">
											<div class="form-group form-focus">
												<input id="email" name="email" type="email" class="form-control floating" required pattern="^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$" oninvalid="this.setCustomValidity('Plase Enter Valid Email Address')" oninput="this.setCustomValidity('')" value="<?php echo (isset($_SESSION['email'])) ? $_SESSION['email'] : '' ?>" >
												<label class="focus-label">Email</label>
											</div>
											<div class="form-group form-focus">
												<input id="password" name="password" type="password" class="form-control floating" required pattern="^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*_=+-]).{6,}$" oninvalid="this.setCustomValidity('Password leanth Must be grater then 6 and it contain atleast 1 digit,1 Upper Case Latter,1 Lower Case Latter and 1 Special Charcter')" oninput="this.setCustomValidity('')">
												<label class="focus-label">Password</label>
											</div>
											<div class="text-right">
												<a class="forgot-link" href="forgot-password.php">Forgot Password ?</a>
											</div>
											<button class="btn btn-primary btn-block btn-lg login-btn" type="submit" name="login">Login</button>
											<div class="text-center dont-have">Don’t have an account? <a href="register.php">Register</a></div>
										</form>
									</div>
								</div>
							</div>
							<!-- /Login Tab Content -->
								
						</div>
					</div>

				</div>

			</div>		
			<!-- /Page Content -->
   
			<!-- Footer -->
			<?php include 'includes/footer.php'; ?>
			<!-- /Footer -->
		   
		</div>
		<!-- /Main Wrapper -->
	  <?php include 'includes/scripts.php'; ?>

</body>
</html>
