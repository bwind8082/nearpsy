<?php include 'includes/session.php'; ?>
<?php
$conn = $pdo->open();
$output = array('error'=>false,'message'=>'');

$mode=$_POST['mode'];
$award=$_POST['award'];
$a_year=$_POST['ayear'];

if(isset($_SESSION['user'])){
	if($mode=='insert'){
		try{
			$stmt = $conn->prepare("SELECT award from doctor where user_id=:uid");
			$stmt->execute([':uid'=>$user['id']]);
			$row = $stmt->fetch();
			if(is_null($row['award'])){
				$stmt = $conn->prepare("UPDATE doctor set award=:award,a_year=:a_year where user_id=:uid");
				$stmt->execute([':award'=>$award,':a_year'=>$a_year,':uid'=>$user['id']]);
			
			}
			else{
			$stmt = $conn->prepare("UPDATE doctor set award=CONCAT(award, '@@', :award),a_year=CONCAT(a_year, '@@', :a_year) where user_id=:uid");
			$stmt->execute([':award'=>$award,':a_year'=>$a_year,':uid'=>$user['id']]);
			}
		}
		catch(PDOException $e){
			$output['message'] = $e->getMessage();
		}
	}
	else{
		try{
			
			$stmt = $conn->prepare("UPDATE doctor set award=REPLACE(award,:award,''),a_year=REPLACE(a_year,:a_year,'') where user_id=:uid");
			$stmt->execute([':award'=>$award,':a_year'=>$a_year,':uid'=>$user['id']]);
			$stmt = $conn->prepare("UPDATE doctor set award=REPLACE(award,'@@@@','@@'),a_year=REPLACE(a_year,'@@@@','@@') where user_id=:uid");
			$stmt->execute([':uid'=>$user['id']]);
			
			
			$stmt = $conn->prepare("select RIGHT(award,2) as l from doctor  where user_id=:uid");
			$stmt->execute([':uid'=>$user['id']]);
			$row = $stmt->fetch();
			if($row['l']=='@@'){
				$stmt = $conn->prepare("UPDATE doctor set award=SUBSTR(award, 1, LENGTH(award) - 2),a_year=SUBSTR(a_year, 1, LENGTH(a_year) - 2) where user_id=:uid");
				$stmt->execute([':uid'=>$user['id']]);
			}

			$stmt = $conn->prepare("select LEFT(award,2) as l from doctor  where user_id=:uid");
			$stmt->execute([':uid'=>$user['id']]);
			$row = $stmt->fetch();
			if($row['l']=='@@'){
				$stmt = $conn->prepare("UPDATE doctor set award=SUBSTR(award, 3, LENGTH(award)),a_year=SUBSTR(a_year, 3, LENGTH(a_year)) where user_id=:uid");
				$stmt->execute([':uid'=>$user['id']]);
			}

			$stmt = $conn->prepare("SELECT award from doctor where user_id=:uid");
			$stmt->execute([':uid'=>$user['id']]);
			$row = $stmt->fetch();
			
			if($row['award']==''){
				$stmt = $conn->prepare("UPDATE doctor set award=NULL,a_year=NULL where user_id=:uid");
				$stmt->execute([':uid'=>$user['id']]);
			
			}
			
		}
		catch(PDOException $e){
			$output['message'] = $e->getMessage();
		}

	}
}

	$pdo->close();
	echo json_encode($output);
?>