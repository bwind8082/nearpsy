<?php include 'includes/session.php'; ?>
<!DOCTYPE html> 
<html lang="en">
<?php
$pid=$_GET['pid'];
$conn = $pdo->open();
try{
$stmt = $conn->prepare("SELECT img,name,city,state,mobileno,date_of_birth,blood_group,gender FROM patient JOIN users WHERE users.id = patient.user_id AND patient.id=:pid");
$stmt->execute([":pid"=>$pid]);
$row = $stmt->fetch();
$age= date_diff(date_create($row['date_of_birth']), date_create(date("Y-m-d")));
$age= $age->format('%y');
$stmt = $conn->prepare("SELECT doctor.id as did,name,doc_type,city,state FROM doctor JOIN users WHERE users.id = doctor.user_id AND doctor.user_id=:uid");
$stmt->execute([":uid"=>$user['id']]);
$doc = $stmt->fetch();

}
catch(PDOException $e){
	$_SESSION['error'] = $e->getMessage();
}
$pdo->close();
?>
<head>
		<meta charset="utf-8">
		<title>Doccure</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
		
		<!-- Favicons -->
		<link href="assets/img/favicon.png" rel="icon">
		
		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="assets/css/bootstrap.min.css">
		
		<!-- Fontawesome CSS -->
		<link rel="stylesheet" href="assets/plugins/fontawesome/css/fontawesome.min.css">
		<link rel="stylesheet" href="assets/plugins/fontawesome/css/all.min.css">
		
		<!-- Main CSS -->
		<link rel="stylesheet" href="assets/css/style.css">
	
	</head>
	<body>

		<!-- Main Wrapper -->
		<div class="main-wrapper">
		
			<!-- Header -->
			<?php include 'includes/navbar.php'; ?>
			<!-- /Header -->
			
			<!-- Breadcrumb -->
			<div class="breadcrumb-bar">
				<div class="container-fluid">
					<div class="row align-items-center">
						<div class="col-md-12 col-12">
							<nav aria-label="breadcrumb" class="page-breadcrumb">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="index.php">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Add Prescription</li>
								</ol>
							</nav>
							<h2 class="breadcrumb-title">Add Prescription</h2>
						</div>
					</div>
				</div>
			</div>
			<!-- /Breadcrumb -->
			
			<!-- Page Content -->
			<div class="content">
				<div class="container-fluid">

					<div class="row">
						<div class="col-md-5 col-lg-4 col-xl-3 theiaStickySidebar">
						
							<!-- Profile Widget -->
							<div class="card widget-profile pat-widget-profile">
								<div class="card-body">
									<div class="pro-widget-content">
										<div class="profile-info-widget">
											<a href="#" class="booking-doc-img">
												<img src="assets/img/patients/<?php echo $row['img']?>" alt="User Image">
											</a>
											<div class="profile-det-info">
												<h3><?php echo $row['name']?></h3>
												
												<div class="patient-details">
													<h5><b>Patient ID :</b> PT<?php echo $pid?></h5>
													<h5 class="mb-0"><i class="fas fa-map-marker-alt"></i> <?php echo $row['city']?>, <?php echo $row['state']?></h5>
												</div>
											</div>
										</div>
									</div>
									<div class="patient-info">
										<ul>
											<li>Phone <span>+91 <?php echo $row['mobileno']?></span></li>
											<li>Age <span><?php echo $age?> Years, <?php echo ($row['gender']==1)?'Male':'Female' ?></span></li>
											<li>Blood Group <span><?php echo $row['blood_group']?></span></li>
										</ul>
									</div>
								</div>
							</div>
							<!-- /Profile Widget -->
							
						</div>

						<div class="col-md-7 col-lg-8 col-xl-9">
							<div class="card">
								<div class="card-header">
									<h4 class="card-title mb-0">Add Prescription</h4>
								</div>
								<div class="card-body">
									<div class="row">
										<div class="col-sm-6">
											<div class="biller-info">
												<h4 class="d-block">Dr. <?php echo $doc['name'] ?></h4>
												<span class="d-block text-sm text-muted"><?php echo $doc['doc_type'] ?></span>
												<span class="d-block text-sm text-muted"><?php echo $doc['city'] ?>, <?php echo $doc['state'] ?></span>
											</div>
										</div>
										<div class="col-sm-6 text-sm-right">
											<div class="billing-info">
												<h4 class="d-block"><?php echo date("d M Y") ?></h4>
												<span class="d-block text-muted"><?php echo date("l") ?></span>
											</div>
										</div>
									</div>
									
									<!-- Add Item -->
									<div class="add-more-item text-right">
										<a href="#none" onclick="add_new_prescription()" ><i class="fas fa-plus-circle"></i> Add Item</a>
									</div>
									<!-- /Add Item -->
									
									<!-- Prescription Item -->
									<form action="edit_prescription.php" method="POST">
									<div class="card card-table">
										<div class="card-body">
											<div class="table-responsive">
												<table class="table table-hover table-center">
													<thead>
														<tr>
															<th style="min-width: 200px">Name</th>
															<th style="min-width: 100px">Quantity</th>
															<th style="min-width: 100px">Days</th>
															<th style="min-width: 100px;">Time</th>
														</tr>
													</thead>

													<tbody id="tbody">
														<?php
															if($_GET['e']==1){
															$conn = $pdo->open();
															try{
																$stmt = $conn->prepare("SELECT m_name, quantity, day,`time` FROM prescription WHERE id=:prid");
																$stmt->execute(['prid'=>$_GET['id']]);
																$row=$stmt->fetch();
															}
															catch(PDOException $e){
																$_SESSION['error'] = $e->getMessage();
															}
															$pdo->close();
															$m_name=explode('@@',$row['m_name']);
															$quantity=explode('@@', $row['quantity']);
															$day=explode('@@', $row['day']);
															$time=explode('@@', $row['time']);
															for($i=0;$i<count($m_name);$i++){
																$t=explode(',',$time[$i]);
																echo'<tr>
															<td>
																<input class="form-control" type="text" name="prname_'.$i.'" value="'.$m_name[$i].'">
															</td>
															<td>
																<input class="form-control" type="text" name="prqun_'.$i.'" value="'.$quantity[$i].'">
															</td>
															<td>
																<input class="form-control" type="text" name="prday_'.$i.'" value="'.$day[$i].'">
															</td>
															<td>
																<div class="form-check form-check-inline">
																	<label class="form-check-label">
																		<input class="form-check-input" type="checkbox" name="prtime_'.$i.'[]" value="Morning" '.((in_array("Morning", $t))?'checked':'').'> Morning
																	</label>
																</div>
																<div class="form-check form-check-inline">
																	<label class="form-check-label">
																		<input class="form-check-input" type="checkbox" name="prtime_'.$i.'[]" value="Afternoon" '.((in_array("Afternoon", $t))?'checked':'').'> Afternoon
																	</label>
																</div>
																<div class="form-check form-check-inline">
																	<label class="form-check-label" '.((in_array("Evening", $t))?'checked':'').'>
																		<input class="form-check-input" type="checkbox" name="prtime_'.$i.'[]" value="Evening" '.((in_array("Evening", $t))?'checked':'').'> Evening
																	</label>
																</div>
																<div class="form-check form-check-inline">
																	<label class="form-check-label" >
																		<input class="form-check-input" type="checkbox" name="prtime_'.$i.'[]" value="Night" '.((in_array("Night", $t))?'checked':'').'> Night
																	</label>
																</div>
															</td>
														</tr>';}
														echo'<input type="hidden" name="prid" value="'.$_GET['id'].'">
														<input type="hidden" name="e" value="1">';
															}
														else{
															echo'
														<tr>
															<td>
																<input class="form-control"  type="text" name="prname_0">
															</td>
															<td>
																<input class="form-control" type="text" name="prqun_0">
															</td>
															<td>
																<input class="form-control" type="text" name="prday_0">
															</td>
															<td>
																<div class="form-check form-check-inline">
																	<label class="form-check-label">
																		<input class="form-check-input" type="checkbox" name="prtime_0[]" value="Morning"> Morning
																	</label>
																</div>
																<div class="form-check form-check-inline">
																	<label class="form-check-label">
																		<input class="form-check-input" type="checkbox" name="prtime_0[]" value="Afternoon"> Afternoon
																	</label>
																</div>
																<div class="form-check form-check-inline">
																	<label class="form-check-label">
																		<input class="form-check-input" type="checkbox" name="prtime_0[]" value="Evening"> Evening
																	</label>
																</div>
																<div class="form-check form-check-inline">
																	<label class="form-check-label">
																		<input class="form-check-input" type="checkbox" name="prtime_0[]" value="Night"> Night
																	</label>
																</div>
															</td>
														</tr><input type="hidden" name="e" value="0">';}?>
													</tbody>
												</table>
											</div>
										</div>
									</div>
									<!-- /Prescription Item -->
									<script type="text/javascript">

										function add_new_prescription() {
										var element = document.getElementById("tbody");
										var i=element.getElementsByTagName("tr").length;			
										 var b = document.createElement("tr");
										   b.innerHTML='<td><input class="form-control" type="text" name="prname_'+i+'" ></td><td><input class="form-control" type="text"  name="prqun_'+i+'"></td><td><input class="form-control" type="text" name="prday_'+i+'"></td><td><div class="form-check form-check-inline"><label class="form-check-label"><input class="form-check-input" type="checkbox"  name="prtime_'+i+'[]" value="Morning"> Morning </label></div><div class="form-check form-check-inline"><label class="form-check-label">&nbsp;<input class="form-check-input" type="checkbox" name="prtime_'+i+'[]" value="Afternoon"> Afternoon </label></div><div class="form-check form-check-inline"><label class="form-check-label">&nbsp;<input class="form-check-input" type="checkbox" name="prtime_'+i+'[]" value="Evening"> Evening </label></div><div class="form-check form-check-inline"><label class="form-check-label">&nbsp;<input class="form-check-input" type="checkbox" name="prtime_'+i+'[]" value="Night"> Night </label></div></td>';								   
										   element.appendChild(b);
										   document.getElementById('nopr').value=i+1;
										}
									</script>		
									<!-- Submit Section -->
									<div class="row">
										<div class="col-md-12">
											<div class="submit-section">
												<input type="hidden" id="nopr" name="nopr" value="1">
												<input type="hidden" name="pid" value="<?php echo $pid ?>">
												<input type="hidden" name="did" value="<?php echo $doc['did'] ?>">
												<button type="submit" class="btn btn-primary submit-btn" name="add_prescription">Save</button>
												<?php
													if($_GET['e']==1){
														echo '
															<script type="text/javascript">document.getElementById("nopr").value=document.getElementById("tbody").getElementsByTagName("tr").length</script>';
													}?>
											</div>
										</div>
									</div>
									<!-- /Submit Section -->
									</form>
								</div>
							</div>
						</div>
					</div>

				</div>

			</div>		
			<!-- /Page Content -->
   
			<!-- Footer -->
			<?php include 'includes/footer.php'; ?>
			<!-- /Footer -->
		   
		</div>
		<!-- /Main Wrapper -->
	  
		<!-- jQuery -->
		<script src="assets/js/jquery.min.js"></script>

				
		<!-- Bootstrap Core JS -->
		<script src="assets/js/popper.min.js"></script>
		<script src="assets/js/bootstrap.min.js"></script>
		
		<!-- Sticky Sidebar JS -->
        <script src="assets/plugins/theia-sticky-sidebar/ResizeSensor.js"></script>
        <script src="assets/plugins/theia-sticky-sidebar/theia-sticky-sidebar.js"></script>
		
		<!-- Custom JS -->
		<script src="assets/js/script.js"></script>
		
	</body>
</html>