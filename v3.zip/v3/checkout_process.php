<?php include 'includes/session.php'; ?>
<?php
if(isset($_POST['book'])){
	$conn = $pdo->open();
	if($_POST['radio']=="Debit/Credit Card" || $_POST['radio']=="UPI"){
		try{
				$stmt = $conn->prepare("INSERT INTO payment(p_type,amount,is_paid) VALUES (:p_type,:amount,'y')");
				$stmt->execute([':p_type'=>$_POST['radio'],':amount'=>$_POST['amount']]);
				$payment_id = $conn->lastInsertId();
				
				if($_POST['radio']=="Debit/Credit Card"){
				$stmt = $conn->prepare("UPDATE payment set c_name=:c_name, c_no=:c_no, exm=:exm, exy=:exy, cvv=:cvv where id=:payment_id");
				$stmt->execute(['c_name'=>$_POST['noc'],'c_no'=>$_POST['cno'],'exm'=>$_POST['exm'],'exy'=>$_POST['exy'],'cvv'=>$_POST['cvv'],'payment_id'=>$payment_id,]);
				}
				else{
				$stmt = $conn->prepare("UPDATE payment set upi=:upi where id=:payment_id");
				$stmt->execute(['upi'=>$_POST['upi_id'],'payment_id'=>$payment_id,]);
				}
		}
		catch(PDOException $e){
			$_SESSION['error'] = $e->getMessage();
			header('location: checkout.php');
		}
	}
	else{
		try{
				$stmt = $conn->prepare("INSERT INTO payment(p_type, amount, is_paid) VALUES (:p_type,:amount,'n')");
				$stmt->execute([':p_type'=>$_POST['radio'],':amount'=>(int)$_POST['amount']]);
				$payment_id = $conn->lastInsertId();
		}
		catch(PDOException $e){
			$_SESSION['error'] = $e->getMessage();
			header('location: checkout.php');
		}
	}
	try{
		$stmt= $conn->prepare("SELECT id from patient where user_id=:uid");
		$stmt->execute([':uid'=>$user['id']]);
		$pid=$stmt->fetch();
		$pid=$pid['id'];
		$stmt = $conn->prepare("INSERT INTO appointments(pid, did, p_name, p_age, p_email, p_mobileno, a_date, a_time, payment_id,appointment_type) VALUES (:pid, :did, :p_name, :p_age, :p_email, :p_mobileno, :a_date, :a_time, :payment_id,:appointment_type)");
		$stmt->execute([':pid'=>$pid, ':did'=>$_POST['did'], ':p_name'=>$_POST['name'], ':p_age'=>$_POST['age'], ':p_email'=>$_POST['email'], ':p_mobileno'=>$_POST['mobileno'], ':a_date'=>$_POST['date'], ':a_time'=>$_POST['time'], ':payment_id'=>$payment_id,':appointment_type'=>$_POST['aptype']]);
		$aid = $conn->lastInsertId();

		if($_POST['aptype']=='online'){
		include 'zoom/zoom.php';
		$stmt= $conn->prepare("UPDATE appointments SET a_url=:a_url,a_pass=:a_pass  where id=:aid");
		$stmt->execute([':a_url'=>$response->join_url,':a_pass'=>$response->password,':aid'=>$aid]);
		}
		
	}
	catch(PDOException $e){
		$_SESSION['error'] = $e->getMessage();
		header('location: checkout.php');
	}
	$pdo->close();
	header('location: booking-success.php?aid='.$aid.'');
}
else{
	$_SESSION['error']="Confirm The Appointment First.";
	header('location: checkout.php');
}
?>