<?php include 'includes/session.php'; ?>
<!DOCTYPE html> 
<html lang="en">
<?php include 'includes/header.php'; ?>
<body>
<div class="main-wrapper">
		<?php include 'includes/navbar.php'; ?>
        <section class="section section-search">
				<div class="container-fluid">
					<div class="banner-wrapper">
<div class="banner-header text-center">
    
<h1>Coming Soon ... </h1>
</div>
</div>
</section>
</div>
</div>                        

</body>
</html>
