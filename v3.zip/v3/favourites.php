<?php include 'includes/session.php'; ?>
<?php
$conn = $pdo->open();
try{
$stmt = $conn->prepare("SELECT p.id as pid,img,name,date_of_birth,city,state FROM patient as p JOIN users WHERE p.user_id = users.id AND users.id=:uid");
$stmt->execute([":uid"=>$user['id']]);
$row = $stmt->fetch();
$age=$user['date_of_birth'];
$age = date_diff(date_create($user['date_of_birth']), date_create(date("Y-m-d")));
$age=$age->format('%y');
$pid=$row['pid'];
}
catch(PDOException $e){
	$_SESSION['error'] = $e->getMessage();
}
$pdo->close();
?>
<!DOCTYPE html> 
<html lang="en">

<head>
		<meta charset="utf-8">
		<title>OHAS</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
		
		<!-- Favicons -->
		<link href="assets/img/favicon.png" rel="icon">
		
		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="assets/css/bootstrap.min.css">
		
		<!-- Fontawesome CSS -->
		<link rel="stylesheet" href="assets/plugins/fontawesome/css/fontawesome.min.css">
		<link rel="stylesheet" href="assets/plugins/fontawesome/css/all.min.css">
		
		<!-- Main CSS -->
		<link rel="stylesheet" href="assets/css/style.css">
	
	</head>
	<body>

		<!-- Main Wrapper -->
		<div class="main-wrapper">
		
			<!-- Header -->
			<?php include 'includes/navbar.php'; ?>
			<!-- /Header -->
			
			<!-- Breadcrumb -->
			<div class="breadcrumb-bar">
				<div class="container-fluid">
					<div class="row align-items-center">
						<div class="col-md-12 col-12">
							<nav aria-label="breadcrumb" class="page-breadcrumb">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="index.php">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Favourites</li>
								</ol>
							</nav>
							<h2 class="breadcrumb-title">Favourites</h2>
						</div>
					</div>
				</div>
			</div>
			<!-- /Breadcrumb -->
			
			<!-- Page Content -->
			<div class="content">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-5 col-lg-4 col-xl-3 theiaStickySidebar">
						<?php include 'includes/profile-sidebar.php'; ?>
						</div>
						<div class="col-md-7 col-lg-8 col-xl-9" >
							<div class="row row-grid">
								<?php
								$conn = $pdo->open();
																	
								try{
									$stmt = $conn->prepare("SELECT favourite_did FROM patient WHERE patient.id=:pid ");
									$stmt->execute([":pid"=>$pid]);
									$p=$stmt->fetch();
								}
								catch(PDOException $e){
									$_SESSION['error'] = $e->getMessage();
								}
								$pdo->close();

								if(!is_null($p['favourite_did'])){
									$did=explode(",",$p['favourite_did']);
									$no_d=count($did);
									$s = $conn->prepare("SELECT COUNT(feedback.id) as nor,CAST(AVG(rating) AS INT) as rat FROM feedback WHERE did=:did ");
									$stmt = $conn->prepare("SELECT doctor.id as did,img,name,degree,city,state,fees FROM doctor JOIN users WHERE doctor.user_id=users.id AND doctor.id=:did");
									for($i=0;$i<$no_d;$i++){ 
									$stmt->execute([":did"=>$did[$i]]);
									$row=$stmt->fetch();
									$s->execute([":did"=>$did[$i]]);
									$rat=$s->fetch();
										echo '
								<div class="col-md-6 col-lg-4 col-xl-3">
									<div class="profile-widget">
									<div class="doc-img">
										<a href="doctor-profile.php?id='.$row['did'].'">
											<img class="" alt="Doctor Image" src="assets/img/doctors/'.$row['img'].'" style="height: 200px">
										</a>	
									</div>
									<div class="pro-content">
										<h3 class="title">
											<a href="doctor-profile.php?id='.$row['did'].'">'.$row['name'].'</a> 
											<i class="fas fa-check-circle verified"></i>
										</h3>
										<p class="speciality">'.$row['degree'].'</p>
										<div class="rating">
											<i class="fas fa-star '.(($rat['rat']>0)?'filled':'').'"></i>
											<i class="fas fa-star '.(($rat['rat']>1)?'filled':'').'"></i>
											<i class="fas fa-star '.(($rat['rat']>2)?'filled':'').'"></i>
											<i class="fas fa-star '.(($rat['rat']>3)?'filled':'').'"></i>
											<i class="fas fa-star '.(($rat['rat']>4)?'filled':'').'"></i>
											<span class="d-inline-block average-rating">('.((!is_null($rat))?$rat['nor']:'0').')</span>
										</div>
										<ul class="available-info">
											<li>
												<i class="fas fa-map-marker-alt"></i>'.$row['city'].','.$row['state'].'
											</li>
											<li>
												<i class="far fa-money-bill-alt"></i> &#8377; '.$row['fees'].' 
												
											</li>
										</ul>
										<div class="row row-sm">
											<div class="col-6">
												<a href="doctor-profile.php?id='.$row['did'].'" class="btn view-btn">View Profile</a>
											</div>
											<div class="col-6">
												<a href="booking.php?did='.$row['did'].'" class="btn book-btn">Book Now</a>
											</div>
										</div>
									</div>
								</div>
								</div>';}}?>
							</div>
						</div>
					</div>
				</div>

			</div>		
			<!-- /Page Content -->
   
			<!-- Footer -->
			<?php include 'includes/footer.php'; ?>
			<!-- /Footer -->
		   
		</div>
		<!-- /Main Wrapper -->
	  
		<!-- jQuery -->
		<script src="assets/js/jquery.min.js"></script>
		
		<!-- Bootstrap Core JS -->
		<script src="assets/js/popper.min.js"></script>
		<script src="assets/js/bootstrap.min.js"></script>
		
		<!-- Sticky Sidebar JS -->
        <script src="assets/plugins/theia-sticky-sidebar/ResizeSensor.js"></script>
        <script src="assets/plugins/theia-sticky-sidebar/theia-sticky-sidebar.js"></script>
		
		<!-- Custom JS -->
		<script src="assets/js/script.js"></script>
		
	</body>

</html>