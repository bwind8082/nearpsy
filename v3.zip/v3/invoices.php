<?php include 'includes/session.php'; ?>
<?php
$conn = $pdo->open();
		try{
		$stmt = $conn->prepare("SELECT img,name,degree FROM doctor as d JOIN users WHERE d.user_id = users.id AND users.id=:uid");
		$stmt->execute([":uid"=>$user['id']]);
		$row = $stmt->fetch();
		}
		catch(PDOException $e){
			$_SESSION['error'] = $e->getMessage();
		}
		$pdo->close();
?>
<!DOCTYPE html> 
<html lang="en">
	
<head>
		<meta charset="utf-8">
		<title>NearPsy</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
		
		<!-- Favicons -->
		<link href="assets/img/favicon.png" rel="icon">
		
		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="assets/css/bootstrap.min.css">
		
		<!-- Fontawesome CSS -->
		<link rel="stylesheet" href="assets/plugins/fontawesome/css/fontawesome.min.css">
		<link rel="stylesheet" href="assets/plugins/fontawesome/css/all.min.css">
		
		<!-- Main CSS -->
		<link rel="stylesheet" href="assets/css/style.css">

	
	</head>
	<body>

		<!-- Main Wrapper -->
		<div class="main-wrapper">
		
			<!-- Header -->
			<?php include 'includes/navbar.php'; ?>
			<!-- /Header -->
			
			<!-- Breadcrumb -->
			<div class="breadcrumb-bar">
				<div class="container-fluid">
					<div class="row align-items-center">
						<div class="col-md-12 col-12">
							<nav aria-label="breadcrumb" class="page-breadcrumb">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="index.php">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Invoices</li>
								</ol>
							</nav>
							<h2 class="breadcrumb-title">Invoices</h2>
						</div>
					</div>
				</div>
			</div>
			<!-- /Breadcrumb -->
			
			<!-- Page Content -->
			<div class="content">
				<div class="container-fluid">

					<div class="row">
						<div class="col-md-5 col-lg-4 col-xl-3 theiaStickySidebar">
						
							<!-- Profile Sidebar -->
							<?php include 'includes/doc-profile-sidebar.php'; ?>
							<!-- /Profile Sidebar -->
							
						</div>
						<div class="col-md-7 col-lg-8 col-xl-9">
							<div class="card card-table">
								<div class="card-body">
								
									<!-- Invoice Table -->
									<div class="table-responsive">
										<table class="table table-hover table-center mb-0">
											<thead>
												<tr>
													<th>Invoice No</th>
													<th>Patient</th>
													<th>Amount</th>
													<th>Paid On</th>
													<th></th>
												</tr>
											</thead>
											<tbody>
											<?php
											$conn = $pdo->open();
												try{
													$pstmt = $conn->prepare("SELECT img FROM patient JOIN users WHERE users.id=patient.user_id AND patient.id=:pid");
													$stmt = $conn->prepare("SELECT appointments.id as aid,pid,payment_id,p_name,amount,a_date FROM doctor as d JOIN users JOIN appointments JOIN payment WHERE d.user_id = users.id AND appointments.did=d.id AND appointments.payment_id=payment.id AND users.id=:uid AND (status='Confirm' OR status='Completed') ");
													$stmt->execute([":uid"=>$user['id']]);
													}
													catch(PDOException $e){
														$_SESSION['error'] = $e->getMessage();
													}
												$pdo->close();
												foreach($stmt as $row){
													$pstmt->execute([":pid"=>$row['pid']]);
													$r=$pstmt->fetch();
											echo'
												<tr>
													<td>
														<a href="invoice-view.php?aid='.$row['aid'].'">#INV-'.$row['payment_id'].'</a>
													</td>
													<td>
														<h2 class="table-avatar">
															<a href="patient-profile.php?pid='.$row['pid'].'" class="avatar avatar-sm mr-2">
																<img class="avatar-img rounded-circle" src="assets/img/patients/'.$r['img'].'" alt="User Image">
															</a>
															<a href="patient-profile.php?pid='.$row['pid'].'">'.$row['p_name'].' <span>#PT'.$row['pid'].'</span></a>
														</h2>
													</td>
													<td>&#8377; '.$row['amount'].'</td>
													<td>'.$row['a_date'].'</td>
													<td class="text-right">
														<div class="table-action">
															<a style="display:none;" href="invoice-view.php" class="btn btn-sm bg-info-light">
																<i class="far fa-eye"></i> View
															</a>
															<a href="invoice-view.php?aid='.$row['aid'].'" class="btn btn-sm bg-info-light">
																<i class="far fa-eye"></i> View
															</a>
														</div>
													</td>
												</tr>';}?>
											</tbody>
										</table>
									</div>
									<!-- /Invoice Table -->
									
								</div>
							</div>
						</div>
					</div>

				</div>

			</div>		
			<!-- /Page Content -->
   
			<!-- Footer -->
			<?php include 'includes/footer.php'; ?>
			<!-- /Footer -->
		   
		</div>
		<!-- /Main Wrapper -->
	  
		<!-- jQuery -->
		<script src="assets/js/jquery.min.js"></script>
		
		<!-- Bootstrap Core JS -->
		<script src="assets/js/popper.min.js"></script>
		<script src="assets/js/bootstrap.min.js"></script>
		
		<!-- Sticky Sidebar JS -->
        <script src="assets/plugins/theia-sticky-sidebar/ResizeSensor.js"></script>
        <script src="assets/plugins/theia-sticky-sidebar/theia-sticky-sidebar.js"></script>
		
		<!-- Custom JS -->
		<script src="assets/js/script.js"></script>
		
	</body>
</html>