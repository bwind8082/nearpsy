<?php include 'includes/session.php'; ?>
<?php
$conn = $pdo->open();
try{
$stmt = $conn->prepare("SELECT * FROM doctor JOIN prescription as p JOIN users WHERE doctor.id=p.did AND users.id=doctor.user_id AND p.id=:prid");
$stmt->execute([":prid"=>$_GET['prid']]);
$row = $stmt->fetch();
$stmt = $conn->prepare("SELECT name FROM doctor JOIN hospitals WHERE hospitals.d_id=doctor.id AND doctor.id=:did");
$stmt->execute([":did"=>$row['did']]);
$hospital = $stmt->fetch();
$stmt = $conn->prepare("SELECT name,address,city,state,postal_code FROM patient JOIN users WHERE users.id=patient.user_id AND patient.id=:pid");
$stmt->execute([":pid"=>$row['pid']]);
$patient = $stmt->fetch();
}
catch(PDOException $e){
	$error = $e->getMessage();
}
$pdo->close();
?>
<!DOCTYPE html> 
<html lang="en">
<head>
		<meta charset="utf-8">
		<title>OHAS</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
		
		<!-- Favicons -->
		<link href="assets/img/favicon.png" rel="icon">
		
		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="assets/css/bootstrap.min.css">
		
		<!-- Fontawesome CSS -->
		<link rel="stylesheet" href="assets/plugins/fontawesome/css/fontawesome.min.css">
		<link rel="stylesheet" href="assets/plugins/fontawesome/css/all.min.css">
		
		<!-- Main CSS -->
		<link rel="stylesheet" href="assets/css/style.css">
		<style type="text/css" media="print">
    @media print {
  @page { margin: 0; }
  body { margin: 1.6cm; }
  header, nav,footer,.noprint{display: none;}
  .print{display: inline !important}
  html, body {
        height: 90% !important;    
    }

    th, td {
    border: solid #000 !important;
    border-width: 0 0 1px 0 !important;
}
}
</style>

</head>
	<body>

		<!-- Main Wrapper -->
		<div class="main-wrapper">
		
			<!-- Header -->
			<?php include 'includes/navbar.php'; ?>
			<!-- /Header -->
			
			<!-- Breadcrumb -->
			<div class="breadcrumb-bar">
				<div class="container-fluid">
					<div class="row align-items-center">
						<div class="col-md-12 col-12">
							<nav aria-label="breadcrumb" class="page-breadcrumb">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="index.php">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Prescription View</li>
								</ol>
							</nav>
							<h2 class="breadcrumb-title noprint">Prescription View</h2>
							<center><h2 class="print" style="display: none">Prescription</h2></center>
						</div>
					</div>
				</div>
			</div>
			<!-- /Breadcrumb -->
			
			<!-- Page Content -->
			<div class="content">
				<div class="container-fluid">
					<div class="row">
						<div class="col-lg-8 offset-lg-2">
							<div class="invoice-content">
								<div class="invoice-item">
									<div class="row">
										<div class="col-md-6">
											<div class="invoice-logo">
												<img src="assets/img/logo.png" alt="logo">
											</div>
										</div>
										<div class="col-md-6">
											<p class="invoice-details">
												<strong>Prescription:</strong> #PR-<?php echo $_GET['prid']?><br>
												<strong>Issued:</strong> <?php echo $row['date']?>
											</p>
										</div>
									</div>
								</div>
								
								<!-- Invoice Item -->
								<div class="invoice-item">
									<div class="row">
										<div class="col-md-6">
											<div class="invoice-info">
												<strong class="customer-text">Created by</strong>
												<p class="invoice-details invoice-details-two">
													Dr. <?php echo $row['name']?> <br>
													<?php echo $hospital['name'].','?> <br>
													<?php echo $row['address_line_1'].',';?> <br>
													<?php echo $row['address_line_2'].','?> <br>
													<?php echo $row['city'].', '.$row['state'].'- '.$row['postal_code'].'.'?> <br>
												</p>
											</div>
										</div>
										<div class="col-md-6">
											<div class="invoice-info invoice-info2">
												<strong class="customer-text">To</strong>
												<p class="invoice-details">
													<?php echo $patient['name']?> <br>
													<?php echo $patient['address']?> <br>
													<?php echo $patient['city'].', '.$patient['state'].'- '.$patient['postal_code']?> <br>
												</p>
											</div>
										</div>
									</div>
								</div>
								<!-- /Invoice Item -->
								
								<!-- Invoice Item -->
								<div class="invoice-item invoice-table-wrap">
									<div class="row">
										<div class="col-md-12">
											<div class="table-responsive">
												<table class="invoice-table table table-bordered">
													<thead>
														<tr>
															<th>Name</th>
															<th class="text-center">Quantity</th>
															<th class="text-center">Days</th>
															<th class="text-right">Time</th>
														</tr>
													</thead>
													<tbody>
														<?php
														$m_name=explode('@@',$row['m_name']);
														$quantity=explode('@@', $row['quantity']);
														$day=explode('@@', $row['day']);
														$time=explode('@@', $row['time']);
														for($i=0;$i<count($m_name);$i++){
															echo'
														<tr>
															<td>'.$m_name[$i].'</td>
															<td class="text-center">'.$quantity[$i].'</td>
															<td class="text-center">'.$day[$i].'</td>
															<td class="text-right">'.$time[$i].'</td>
														</tr>';}?>
														
													</tbody>
												</table>
											</div>
										</div>
									</div>
								</div>
								<!-- /Invoice Item -->
								<center><br><button class="btn btn-bg bg-primary-light noprint" onclick="window.print();"><i class="fas fa-print"></i> Print</button></center>
							</div>
						</div>
					</div>

				</div>

			</div>		
			<!-- /Page Content -->
   
			<!-- Footer -->
			<?php include 'includes/footer.php'; ?>
			<!-- /Footer -->
		   
		</div>
		<!-- /Main Wrapper -->
	  
		<!-- jQuery -->
		<script src="assets/js/jquery.min.js"></script>
		
		<!-- Bootstrap Core JS -->
		<script src="assets/js/popper.min.js"></script>
		<script src="assets/js/bootstrap.min.js"></script>
		
		<!-- Custom JS -->
		<script src="assets/js/script.js"></script>
		
	</body>
</html>