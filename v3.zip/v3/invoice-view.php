<?php include 'includes/session.php'; ?>
<?php
$conn = $pdo->open();
try{
$stmt = $conn->prepare("SELECT *,a.id as aid,doctor.id as did FROM doctor JOIN appointments as a JOIN users JOIN payment WHERE doctor.id=a.did AND users.id=doctor.user_id AND a.payment_id=payment.id AND a.id=:aid");
$stmt->execute([":aid"=>$_GET['aid']]);
$row = $stmt->fetch();
$stmt = $conn->prepare("SELECT name FROM doctor JOIN hospitals WHERE hospitals.d_id=doctor.id AND doctor.id=:did");
$stmt->execute([":did"=>$row['did']]);
$hospital = $stmt->fetch();
$stmt = $conn->prepare("SELECT address,city,state,postal_code FROM patient WHERE id=:pid");
$stmt->execute([":pid"=>$row['pid']]);
$patient = $stmt->fetch();
}
catch(PDOException $e){
	$error = $e->getMessage();
}
$pdo->close();
?>
<!DOCTYPE html> 
<html lang="en">
<head>
		<meta charset="utf-8">
		<title>OHAS</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
		
		<!-- Favicons -->
		<link href="assets/img/favicon.png" rel="icon">
		
		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="assets/css/bootstrap.min.css">
		
		<!-- Fontawesome CSS -->
		<link rel="stylesheet" href="assets/plugins/fontawesome/css/fontawesome.min.css">
		<link rel="stylesheet" href="assets/plugins/fontawesome/css/all.min.css">
		
		<!-- Main CSS -->
		<link rel="stylesheet" href="assets/css/style.css">
		<style type="text/css" media="print">
    @media print {
  @page { margin: 0; }
  body { margin: 1.6cm; }
  header, nav,footer,.noprint{display: none;}
  .print{display: inline !important}
  html, body {
        height: 90% !important;    
    }

    th, td {
    border: solid #000 !important;
    border-width: 0 0 1px 0 !important;
}
}
</style>

</head>
	<body>

		<!-- Main Wrapper -->
		<div class="main-wrapper">
		
			<!-- Header -->
			<?php include 'includes/navbar.php'; ?>
			<!-- /Header -->
			
			<!-- Breadcrumb -->
			<div class="breadcrumb-bar">
				<div class="container-fluid">
					<div class="row align-items-center">
						<div class="col-md-12 col-12">
							<nav aria-label="breadcrumb" class="page-breadcrumb">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="index.php">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Invoice View</li>
								</ol>
							</nav>
							<h2 class="breadcrumb-title noprint">Invoice View</h2>
							<center><h2 class="print" style="display: none">Invoice</h2></center>
						</div>
					</div>
				</div>
			</div>
			<!-- /Breadcrumb -->
			
			<!-- Page Content -->
			<div class="content">
				<div class="container-fluid">
					<div class="row">
						<div class="col-lg-8 offset-lg-2">
							<div class="invoice-content">
								<div class="invoice-item">
									<div class="row">
										<div class="col-md-6">
											<div class="invoice-logo">
												<img src="assets/img/logo.png" alt="logo">
											</div>
										</div>
										<div class="col-md-6">
											<p class="invoice-details">
												<strong>Appointment:</strong> #<?php echo $row['aid']?><br>
												<strong>Issued:</strong> <?php echo date("d/m/Y")?>
											</p>
										</div>
									</div>
								</div>
								
								<!-- Invoice Item -->
								<div class="invoice-item">
									<div class="row">
										<div class="col-md-6">
											<div class="invoice-info">
												<strong class="customer-text">Invoice From</strong>
												<p class="invoice-details invoice-details-two">
													Dr. <?php echo $row['name']?> <br>
													<?php echo $hospital['name'].','?> <br>
													<?php echo $row['address_line_1'].',';?> <br>
													<?php echo $row['address_line_2'].','?> <br>
													<?php echo $row['city'].', '.$row['state'].'- '.$row['postal_code'].'.'?> <br>
												</p>
											</div>
										</div>
										<div class="col-md-6">
											<div class="invoice-info invoice-info2">
												<strong class="customer-text">Invoice To</strong>
												<p class="invoice-details">
													<?php echo $row['p_name']?> <br>
													<?php echo $patient['address']?> <br>
													<?php echo $patient['city'].', '.$patient['state'].'- '.$patient['postal_code']?> <br>
												</p>
											</div>
										</div>
									</div>
								</div>
								<!-- /Invoice Item -->
								
								<!-- Invoice Item -->
								<div class="invoice-item">
									<div class="row">
										<div class="col-md-12">
											<div class="invoice-info">
												<strong class="customer-text">Payment Method</strong>
												<p class="invoice-details invoice-details-two">
													<?php echo $row['p_type']?> <br>
													<?php
													if($row['p_type']=="Debit/Credit Card")
														echo "XXXX-XXXX-XXXX-".substr($row['c_no'], -4);
													
													if($row['p_type']=="UPI")
														echo substr($row['upi'], 0, 4)."XXXXXXXXXX".'@'.explode('@',$row['upi'])[1];
													?> <br>
												</p>
											</div>
										</div>
									</div>
								</div>
								<!-- /Invoice Item -->
								
								<!-- Invoice Item -->
								<div class="invoice-item invoice-table-wrap">
									<div class="row">
										<div class="col-md-12">
											<div class="table-responsive">
												<table class="invoice-table table table-bordered">
													<thead>
														<tr>
															<th>Description</th>
															<th class="text-center">Fees</th>
															<th class="text-center">VAT</th>
															<th class="text-right">Total</th>
														</tr>
													</thead>
													<tbody>
														<tr>
															<td>General Consultation</td>
															<td class="text-center">&#8377; <?php echo explode('-', $row['fees'])[0]?></td>
															<td class="text-center">&#8377; 0</td>
															<td class="text-right">&#8377; <?php echo explode('-', $row['fees'])[0]?></td>
														</tr>
														<tr>
															<td>Booking Charge</td>
															<td class="text-center">&#8377; 10</td>
															<td class="text-center">&#8377; 0</td>
															<td class="text-right">&#8377; 10</td>
														</tr>
													</tbody>
												</table>
											</div>
										</div>
										<div class="col-md-6 col-xl-4 ml-auto">
											<div class="table-responsive">
												<table class="invoice-table-two table">
													<tbody>
													<tr>
														<th>Subtotal:</th>
														<td><span>&#8377; <?php echo ((int)explode('-', $row['fees'])[0]+10) ?></span></td>
													</tr>
													<tr>
														<th>Discount:</th>
														<td><span>-10%</span></td>
													</tr>
													<tr>
														<th>Total Amount:</th>
														<td><span>&#8377; <?php echo (((int)explode('-', $row['fees'])[0]+10)-((int)explode('-', $row['fees'])[0]+10)*0.1) ?></span></td>
													</tr>
													</tbody>
												</table>
											</div>
										</div>
									</div>
								</div>
								<!-- /Invoice Item -->
								<center><br><button class="btn btn-bg bg-primary-light noprint" onclick="window.print();"><i class="fas fa-print"></i> Print</button></center>
							</div>
						</div>
					</div>

				</div>

			</div>		
			<!-- /Page Content -->
   
			<!-- Footer -->
			<?php include 'includes/footer.php'; ?>
			<!-- /Footer -->
		   
		</div>
		<!-- /Main Wrapper -->
	  
		<!-- jQuery -->
		<script src="assets/js/jquery.min.js"></script>
		
		<!-- Bootstrap Core JS -->
		<script src="assets/js/popper.min.js"></script>
		<script src="assets/js/bootstrap.min.js"></script>
		
		<!-- Custom JS -->
		<script src="assets/js/script.js"></script>
		
	</body>
</html>