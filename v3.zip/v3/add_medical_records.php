<?php include 'includes/session.php'; ?>
<?php

$pid=$_POST['pid'];
$did=$_POST['did'];
$des=$_POST['m_des'];
$date=$_POST['m_date'];

$conn = $pdo->open();
try{
  if($_POST['e']=='0'){
  $stmt = $conn->prepare("INSERT INTO medical_record(pid,did,`date`,description) VALUES(:pid,:did,:mdate,:des)");
  $stmt->execute(['pid'=>$pid,'did'=>$did,'mdate'=>$date,'des'=>$des]);
  $mid=$conn->lastInsertId();
  }
  else{
  $mid=$_POST['mrid'];
  $stmt = $conn->prepare("UPDATE medical_record SET `date`=:mdate,description=:des WHERE id=:mid");
  $stmt->execute(['mdate'=>$date,'des'=>$des,'mid'=>$mid]);
  }
}
catch(PDOException $e){
  $_SESSION['error'] = $e->getMessage();        
}
$pdo->close();

?>

<?php
if(isset($_FILES["fileToUpload"])){
$target_dir = "assets/m_file/";

$FileType = strtolower(pathinfo($_FILES["fileToUpload"]["name"],PATHINFO_EXTENSION));
$target_file = $target_dir . $mid.".".$FileType;
$uploadOk = 1;

// Allow certain file formats
if($FileType != "pdf" ) {
  $_SESSION['error'] = "Sorry, only PDF file is allowed.";
  $uploadOk = 0;
}

// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 1) {
  if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
    $conn = $pdo->open();
    try{
          $stmt = $conn->prepare("UPDATE medical_record SET attachment =:attachment WHERE id = :mid ");
          $stmt->execute(['attachment'=>$mid.".".$FileType,'mid'=>$mid]);
        }
        catch(PDOException $e){
          $_SESSION['error'] = $e->getMessage();
          
        }

        $pdo->close();
  } else {
    $_SESSION['error']= "Sorry, there was an error uploading your file.";
  }
}}
header('location: patient-profile.php?pid='.$_POST['pid'].'');

?>