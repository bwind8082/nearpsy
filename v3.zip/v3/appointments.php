<?php include 'includes/session.php'; ?>
<?php
$conn = $pdo->open();
		try{
		$stmt = $conn->prepare("SELECT img,name,degree FROM doctor as d JOIN users WHERE d.user_id = users.id AND users.id=:uid");
		$stmt->execute([":uid"=>$user['id']]);
		$row = $stmt->fetch();
		}
		catch(PDOException $e){
			$_SESSION['error'] = $e->getMessage();
		}
		$pdo->close();
?>
<!DOCTYPE html> 
<html lang="en">
	
<head>
		<meta charset="utf-8">
		<title>OHAS</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
		
		<!-- Favicons -->
		<link href="assets/img/favicon.png" rel="icon">
		
		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="assets/css/bootstrap.min.css">
		
		<!-- Fontawesome CSS -->
		<link rel="stylesheet" href="assets/plugins/fontawesome/css/fontawesome.min.css">
		<link rel="stylesheet" href="assets/plugins/fontawesome/css/all.min.css">
		
		<!-- Main CSS -->
		<link rel="stylesheet" href="assets/css/style.css">

	</head>
	<body>

		<!-- Main Wrapper -->
		<div class="main-wrapper">
		
			<!-- Header -->
			<?php include 'includes/navbar.php'; ?>
			<!-- /Header -->
			
			<!-- Breadcrumb -->
			<div class="breadcrumb-bar">
				<div class="container-fluid">
					<div class="row align-items-center">
						<div class="col-md-12 col-12">
							<nav aria-label="breadcrumb" class="page-breadcrumb">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="index
										.php">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Appointments</li>
								</ol>
							</nav>
							<h2 class="breadcrumb-title">Appointments</h2>
						</div>
					</div>
				</div>
			</div>
			<!-- /Breadcrumb -->
			
			<!-- Page Content -->
			<div class="content">
				<div class="container-fluid">

					<div class="row">
						<div class="col-md-5 col-lg-4 col-xl-3 theiaStickySidebar">
						
							<!-- Profile Sidebar -->
							<?php include 'includes/doc-profile-sidebar.php'; ?>
							<!-- /Profile Sidebar -->
							
						</div>
						
						<div class="col-md-7 col-lg-8 col-xl-9">
							<div class="appointments">
								<!-- Appointment List -->
							<?php
							$conn = $pdo->open();
							try{
							$stmt = $conn->prepare("SELECT count(appointments.id) as noa FROM doctor as d JOIN users JOIN appointments WHERE d.user_id = users.id AND appointments.did=d.id AND users.id=:uid AND status='Confirm'");
							$stmt->execute([":uid"=>$user['id']]);
							$no_ap=$stmt->fetch();
							$no_ap=$no_ap['noa'];
							$stmt = $conn->prepare("SELECT count(appointments.id) as nota FROM doctor as d JOIN users JOIN appointments WHERE d.user_id = users.id AND appointments.did=d.id AND users.id=:uid AND status!='Cancelled' AND status!='Pending'");
							$stmt->execute([":uid"=>$user['id']]);
							$nota=$stmt->fetch();
							$nota=$nota['nota'];
							$p = $conn->prepare("SELECT img,city,state,email,mobileno FROM patient JOIN users WHERE users.id=patient.user_id AND patient.id=:pid");
							$stmt = $conn->prepare("SELECT appointments.id as aid, pid,p_name,a_date,a_time,appointment_type,p_type,amount,status FROM doctor as d JOIN users JOIN appointments JOIN payment WHERE d.user_id = users.id AND appointments.did=d.id AND users.id=:uid AND payment.id=appointments.payment_id AND status!='Cancelled' AND status!='Pending' ORDER BY status DESC,STR_TO_DATE(a_date, '%d %M %Y'),a_time");
							$stmt->execute([":uid"=>$user['id']]);
							}
							catch(PDOException $e){
							$_SESSION['error'] = $e->getMessage();
							}
							$pdo->close();
							
							$i=-1;
							foreach($stmt as $row){
							$i++;
							$p->execute([":pid"=>$row['pid']]);
							$row1=$p->fetch();
							echo'
								<div class="appointment-list">
									<div class="profile-info-widget">
										<a href="patient-profile.php?pid='.$row['pid'].'" class="booking-doc-img">
											<img src="assets/img/patients/'.$row1['img'].'" alt="User Image">
										</a>
										<div class="profile-det-info">
											<h3><a href="patient-profile.php?pid='.$row['pid'].'">'.$row['p_name'].'</a></h3>
											<div class="patient-details">
												<h5><i class="far fa-clock"></i> '.$row['a_date'].', '.$row['a_time'].'</h5>
												<h5><i class="fas fa-map-marker-alt"></i> '.$row1['city'].', '.$row1['state'].'</h5>
												<h5><i class="fas fa-envelope"></i> '.$row1['email'].'</h5>
												<h5 class="mb-0"><i class="fas fa-phone"></i> +91 '.$row1['mobileno'].'</h5>
											</div>
										</div>
									</div>
									<div class="appointment-action">
										<input type="hidden" id="ap_'.$i.'" value="'.$row['aid'].'">
										<a href="#" class="btn btn-sm bg-info-light" id="ad_'.$i.'" data-toggle="modal" data-target="#appt_details">
											<i class="far fa-eye"></i> View
										</a>&nbsp;&nbsp;
										'.(($row['status']=='Completed')?'':'<a href="#none" id="ap_c_'.$i.'" class="btn btn-sm bg-danger-light">
										<i class="fas fa-times"></i> Cancel</a>').'
									</div>
								</div>';}?>
								<!-- /Appointment List -->
							</div>
						</div>
					</div>

				</div>

			</div>		
			<!-- /Page Content -->
   
			<!-- Footer -->
			<?php include 'includes/footer.php'; ?>
			<!-- /Footer -->
		   
		</div>
		<!-- /Main Wrapper -->
		
		<!-- Appointment Details Modal -->
		<div class="modal fade custom-modal" id="appt_details">
			<div class="modal-dialog modal-dialog-centered">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title">Appointment Details</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body">
						<ul class="info-details">
						</ul>
					</div>
				</div>
			</div>
		</div>
		<!-- /Appointment Details Modal -->
	  
		<!-- jQuery -->
		<script src="assets/js/jquery.min.js"></script>

		<script type='text/javascript'>
		<?php for($i=0;$i<$no_ap;$i++){
		echo"
			$(document).on('click','#ap_c_".$i."',function(e){
			e.preventDefault();
		    var aid = $('#ap_".$i."').val();
		    var mode='cancel';
		    $.ajax({
		      type: 'POST',
		      url: 'change_appoinment_status.php',
		      data: {aid:aid,mode:mode},
		      dataType: 'json',
		      success: function(response){
		        if(!response.error){
		          location.reload(); 
		        }
		      }
		    });
		  });
			";}?>

		<?php
		$conn = $pdo->open();
		try{
		$stmt = $conn->prepare("SELECT appointments.id as aid, pid,p_name,a_date,a_time,appointment_type,p_type,amount,status FROM doctor as d JOIN users JOIN appointments JOIN payment WHERE d.user_id = users.id AND appointments.did=d.id AND users.id=:uid AND payment.id=appointments.payment_id AND status!='Cancelled' AND status!='Pending' ORDER BY status DESC,STR_TO_DATE(a_date, '%d %M %Y'),a_time");
		$stmt->execute([":uid"=>$user['id']]);
		}
		catch(PDOException $e){
		$_SESSION['error'] = $e->getMessage();
		}
		$pdo->close();			
		$i=-1;
		foreach($stmt as $row){
		$i++;
		echo"
			$(document).on('click','#ad_".$i."',function(e){
			e.preventDefault();
		    $('.info-details').html(`<li>
								<div class='details-header'>
									<div class='row'>
										<div class='col-md-6'>
											<span class='title'>#APT".$row['aid']."</span>
											<span class='text'>".$row['a_date']." ".$row['a_time']."</span>
										</div>
										<div class='col-md-6'>
											<div class='text-right'>
												<button type='button' class='btn bg-success-light btn-sm' id='topup_status'>".$row['status']."</button>
											</div>
										</div>
									</div>
								</div>
							</li>
							<li>
								<span class='title'>Appointment Type:</span>
								<span class='text'>".$row['appointment_type']."</span>
							</li>
							<li>
								<span class='title'>Total Amount:</span>
								<span class='text'>&#8377; ".$row['amount']."</span>
							</li>
							<li>
								<span class='title'>Amount Paid in Advance</span>
								<span class='text'>&#8377; ".(($row['p_type']=='COV')?'0':$row['amount'])."</span>
							</li>`);
		    
		  });
			";}?>
		</script>
		
		<!-- Bootstrap Core JS -->
		<script src="assets/js/popper.min.js"></script>
		<script src="assets/js/bootstrap.min.js"></script>
		
		<!-- Sticky Sidebar JS -->
        <script src="assets/plugins/theia-sticky-sidebar/ResizeSensor.js"></script>
        <script src="assets/plugins/theia-sticky-sidebar/theia-sticky-sidebar.js"></script>
		
		<!-- Custom JS -->
		<script src="assets/js/script.js"></script>
		
	</body>
</html>