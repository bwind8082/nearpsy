<?php include 'includes/session.php'; ?>
<!DOCTYPE html> 
<html lang="en-US">
<?php include 'includes/header.php'; ?>
<title>Consult Psychiatrist and Pshychologist - Top 1% | NearPsy</title>
<meta name="description" content="NearPsy Platform helps to consult top Psychiatrist and Pshychologist within 24hours.">
</head>
<style type="text/css">
    /* Formatting search box */
    .result{
        position: absolute;        
        z-index: 9999999;
        top: 100%;
        left: 0;
        background: #ffffff;
    }
    .search-box input[type="text"], .result{
        width: 100%;
        box-sizing: border-box;
    }
    /* Formatting result items */
    .result p{
        margin: 0;
        padding: 7px 10px;
        border: 1px solid #CCCCCC;
        border-top: none;
        cursor: pointer;
        color: #000000;
    }
    .result p:hover{
        background: #f2f2f2;
    }
</style>
<body>

	<div class="main-wrapper">
		<?php include 'includes/navbar.php'; ?>

		<section class="section section-search">
				<div class="container-fluid">
					<div class="banner-wrapper">
						<div class="banner-header text-center">
							<h2>Find Mental Health Near You.</h2>
							
						</div>
                         
						<!-- Search -->
						<div class="search-box">
							<form>
								<div class="form-group search-location">
									<select class="form-control" id="location" onchange="search()">
										<option value="">All India</option>
										<option value="Ahmedabad">Ahmedabad</option>
										<option value="Bengaluru">Bengaluru</option>
										<option value="Chennai">Chennai</option>
										<option value="Delhi">Delhi</option>
										<option value="Gandhinagar">Gandhinagar</option>
										<option value="Jamnagar">Jamnagar</option>
										<option value="Kolkata">Kolkata</option>
										<option value="Mumbai">Mumbai</option>
										<option value="Pune">Pune</option>
										<option value="Rajkot">Rajkot</option>
										<option value="Surat">Surat</option>
									</select>
									
									
								</div>
								<div class="form-group search-info" id="search-box">
									<input type="text" class="form-control" id="sinput" placeholder="Search Doctors" autocomplete="off" onkeyup="search()">
									<div class="result"></div>
								</div>
							</form>
							
						</div>
						<!-- /Search -->
					</div>
				</div>
			</section>
			
	
			<!-- Popular Section -->
			<section class="section section-doctor">
				<div class="container-fluid">
				   <div class="row">
						<div class="col-lg-4">
							<div class="section-header ">
								<h3>Connect with India’s top 1% psychologist and psychiatrist to get best online therapy within 24 hours. </h3><br>
								
							</div>
						
							<div class="about-content">
								<p>Here you find top 1% Doctores for you. Just Register and  book an Appointment.</p>
								<p>We provide 24x7 online service and Wating for you take appointment now.</p>					
								<a href="/aboutus.php">Read More..</a>
							</div>
						</div>
						<div class="col-lg-8">
							<div class="doctor-slider slider">
							
								<!-- Doctor Widget -->
								<?php
								$conn = $pdo->open();
								try{
								$s = $conn->prepare("SELECT COUNT(feedback.id) as nor,CAST(AVG(rating) AS INT) as rat FROM feedback WHERE did=:did ");
								$stmt = $conn->prepare("SELECT *,d.id as did FROM doctor as d JOIN users WHERE d.user_id = users.id LIMIT 8");
								$stmt->execute();

								foreach($stmt as $row){
								$s->execute([":did"=>$row['did']]);
								$rat=$s->fetch();
								echo'

								<div class="profile-widget">
									<div class="doc-img">
										<a href="doctor-profile.php?id='.$row['did'].'">
											<img class="" alt="Doctor Image" src="assets/img/doctors/'.$row['img'].'" width="300" height="228">
										</a>	
									</div>
									<div class="pro-content">
										<h3 class="title">
											<a href="doctor-profile.php?id='.$row['did'].'">'.$row['name'].'</a> 
											<i class="fas fa-check-circle verified"></i>
										</h3>
										<p class="speciality">'.str_replace("@@",",",$row['degree']).'</p>
										<div class="rating">
											<i class="fas fa-star '.(($rat['rat']>0)?'filled':'').'"></i>
											<i class="fas fa-star '.(($rat['rat']>1)?'filled':'').'"></i>
											<i class="fas fa-star '.(($rat['rat']>2)?'filled':'').'"></i>
											<i class="fas fa-star '.(($rat['rat']>3)?'filled':'').'"></i>
											<i class="fas fa-star '.(($rat['rat']>4)?'filled':'').'"></i>
											<span class="d-inline-block average-rating">('.((!is_null($rat))?$rat['nor']:'0').')</span>
										</div>
										<ul class="available-info">
											<li>
												<i class="fas fa-map-marker-alt"></i>'.$row['city'].','.$row['state'].'
											</li>
											<li>
												<i class="far fa-money-bill-alt"></i> &#8377; '.$row['fees'].' 
												
											</li>
										</ul>
										<div class="row row-sm">
											<div class="col-6">
												<a href="doctor-profile.php?id='.$row['did'].'" class="btn view-btn">View Profile</a>
											</div>
											<div class="col-6">
												<a href="booking.php?did='.$row['did'].'" class="btn book-btn">Book Now</a>
											</div>
										</div>
									</div>
								</div>'; }}
								catch(PDOException $e){
											$_SESSION['error'] = $e->getMessage();
								}
								$pdo->close();?>
								<!-- /Doctor Widget -->
							</div>
						</div>
				   </div>
				</div>
			</section>
			<!-- /Popular Section -->
			<div class="card">
  <h1 class="card-header">Best Psychologist in Rajkot</h1>
  </div>
		   <!-- Availabe Features -->
		   <section class="section section-features">
				<div class="container-fluid">
				   <div class="row">
						<div class="col-md-5 features-img">
						<img src="https://ucarecdn.com/0b93e28e-d82d-4a17-93a9-0727d78c324d/mockup.png" class="img-fluid" alt="Feature">	
						</div>
						<div class="col-md-7">
							<div class="section-header">	
								<h3 class="mt-2">Availabe Features in </h3>
								<p>You get all the Features in the our Web Application.</p>
							</div>	
							<div class="features-slider slider">
								<!-- Slider Item -->
								<div class="feature-item text-center">
									<img src="https://ucarecdn.com/4ce64fc9-6853-48f0-8689-20598687a702/feature01.png" class="img-fluid" alt="Feature-01">
									<p>Data Security</p>
								</div>
								<!-- /Slider Item -->
								
								<!-- Slider Item -->
								<div class="feature-item text-center">
									<img src="https://ucarecdn.com/abf86d39-06a1-4592-8a98-8292e903c320/feature02.png" class="img-fluid" alt="Feature-02">
									<p>Book Any Time</p>
								</div>
								<!-- /Slider Item -->
								
								<!-- Slider Item -->
								<div class="feature-item text-center">
									<img src="https://ucarecdn.com/c14d5ddd-3163-4404-9a7c-c4c56245e79f/feature03.png" class="img-fluid" alt="Feature-03">
									<p>Video Counseling</p>
								</div>
								<!-- /Slider Item -->
								
								<!-- Slider Item -->
								<div class="feature-item text-center">
									<img src="https://ucarecdn.com/9e80b719-74e1-4d9a-bc35-ed7eaaabb754/feature04.png" class="img-fluid" alt="Feature-04">
									<p>Instant Refund</p>
								</div>
								<!-- /Slider Item -->
								
								<!-- Slider Item -->
								<div class="feature-item text-center">
									<img src="https://ucarecdn.com/0f95ccd3-2f5c-426b-b2d1-002b45c9f426/feature05.png" class="img-fluid" alt="Feature-05">
									<p>Clean UI</p>
								</div>
								<!-- /Slider Item -->
								
								<!-- Slider Item -->
								<div class="feature-item text-center">
									<img src="https://ucarecdn.com/ccacbfc3-2ab0-4ab3-b423-72bfc073181c/feature06.png" class="img-fluid" alt="Feature-06">
									<p>Instant Invoice</p>
								</div>
								<!-- /Slider Item -->
							</div>
						</div>
				   </div>
				</div>
			</section>
			<!-- Availabe Features -->

		<?php include 'includes/footer.php'; ?>
	</div>
	<?php include 'includes/scripts.php'; ?>
	<script type="text/javascript">

function search(){
	var inputVal = $('#sinput').val();
	var resultDropdown = $(".result");
    var location = $('#location').val();
	if(inputVal.length){
	    $.get("backend-search.php", {term: inputVal,location:location}).done(function(data){
            resultDropdown.html(data);
        });
    } else{
        resultDropdown.empty();
    }
}
</script>
</body>
</html>
