<?php include 'includes/session.php'; ?>
<?php
  if(isset($_SESSION['user'])){
    header('location: /doc_appointment/index.php');
  } 
?>
<!DOCTYPE html> 
<html lang="en">
<?php include 'includes/header.php'; ?>
<title>SignUp</title>
<meta name="description" content="Create Account </title>
</head>
	<body class="account-page">

		<!-- Main Wrapper -->
		<div class="main-wrapper">
		
			<!-- Header -->
			<?php include 'includes/navbar.php'; ?>
			<!-- /Header -->
			
			<!-- Page Content -->
			<div class="content">
				<div class="container-fluid">
					
					<div class="row">
						<div class="col-md-8 offset-md-2">
								<div>
								<?php
							      if(isset($_SESSION['error'])){
							        echo "
							          <div class='callout callout-danger text-center'>
							            <p>".$_SESSION['error']."</p><br>
							          </div>
							        ";
							        unset($_SESSION['error']);
							      }

							      if(isset($_SESSION['success'])){
							        echo "
							          <div class='callout callout-success text-center'>
							            <p>".$_SESSION['success']."</p><br>
							          </div>
							        ";
							        unset($_SESSION['success']);
							      }
							    ?>
							</div>
							<!-- Register Content -->
							<div class="account-content">
								<div class="row align-items-center justify-content-center">
									
									<div class="col-md-12 col-lg-6 login-right">
										<div class="login-header">
											<h3>Register</h3>
										</div>
										
										<!-- Register Form -->
										<form action="register_process.php" method="POST">
											<div class="form-group form-focus">
												<input id="name" name="name" type="text" class="form-control floating" required pattern="[a-zA-Z .]{3,}" oninvalid="this.setCustomValidity('Name shoud be atleast 3 Charcter long')" oninput="this.setCustomValidity('')">
												<label class="focus-label">Name</label>
											</div>
											<div class="form-group form-focus">
												<input id="mobileno" name="mobileno" type="text" class="form-control floating" required pattern="[0-9]{10}" oninvalid="this.setCustomValidity('Plase Enter your 10 digit mobile No.')" oninput="this.setCustomValidity('')">
												<label class="focus-label">Mobile Number</label>
											</div>
											<div class="form-group form-focus">
												<input id="email" name="email" type="email" class="form-control floating" required pattern="^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$" oninvalid="this.setCustomValidity('Plase Enter Valid Email Address')" oninput="this.setCustomValidity('')">
												<label class="focus-label">Email</label>
											</div>
											<div class="form-group form-focus">
												<input id="password" name="password" type="password" class="form-control floating" required pattern="^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*_=+-]).{6,}$" oninvalid="this.setCustomValidity('Password leanth Must be grater then 6 and it contain atleast 1 digit,1 Upper Case Latter,1 Lower Case Latter and 1 Special Charcter')" oninput="this.setCustomValidity('')">
												<label class="focus-label">Create Password</label>
											</div>
											<div class="form-group form-focus">
												<input id="conform_password" name="conform_password" type="password" class="form-control floating" required onfocusout="check_pass()">
												<label class="focus-label">Confirm Password</label>
											</div>
											<div id='pass_check' style="color: red;"></div><br>
											<div class="form-group form-focus">
												<select class="form-control floating" name="type" id="type" >
												  <option value="1">Patient</option>
												  <option value="2">Doctor</option>
												</select>
												<label class="focus-label">Select User Type</label>
											</div>
											<div class="text-right">
												<a class="forgot-link" href="login.php">Already have an account?</a>
											</div>
											<button class="btn btn-primary btn-block btn-lg login-btn" type="submit" name="signup" id="signup">Signup</button>
											<script type="text/javascript">
											function check_pass() {
											if(document.getElementById('password').value!=document.getElementById('conform_password').value){
												document.getElementById('pass_check').innerHTML='Password and Confirm password does not match.'
												document.getElementById("signup").disabled = true;
											}
											else{
												document.getElementById('pass_check').innerHTML=''
												document.getElementById("signup").disabled = false;
										}}
										</script>
										</form>
										<!-- /Register Form -->
										
									</div>
								</div>
							</div>
							<!-- /Register Content -->
								
						</div>
					</div>

				</div>

			</div>		
			<!-- /Page Content -->
   
			<!-- Footer -->
			<?php include 'includes/footer.php'; ?>
			<!-- /Footer -->
		   
		</div>
		<!-- /Main Wrapper -->
	  <?php include 'includes/scripts.php'; ?>
	
</body>
</html>
