<?php include 'includes/session.php'; ?>
<?php
	if(!isset($_SESSION['user'])){
		header('location: index.php');
	}
?>
<?php
$conn = $pdo->open();
try{
$stmt = $conn->prepare("SELECT name,degree,img,d.id as did FROM doctor as d JOIN users WHERE d.user_id = users.id AND users.id=:uid");
$stmt->execute([":uid"=>$user['id']]);
$row = $stmt->fetch();
$stmt = $conn->prepare("SELECT sunday, monday, tuesday, wednesday, thursday, friday, saturday FROM doctor_timing as d JOIN doctor WHERE d.did = doctor.id AND doctor.id=:did");
$stmt->execute([":did"=>$row['did']]);
$timing = $stmt->fetch();
}
catch(PDOException $e){
			$_SESSION['error'] = $e->getMessage();
}
$pdo->close();
?>
<!DOCTYPE html> 
<html lang="en">
<head>
		<meta charset="utf-8">
		<title>NearPsy</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
		
		<!-- Favicons -->
		<link href="assets/img/favicon.png" rel="icon">
		
		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="assets/css/bootstrap.min.css">
		
		<!-- Fontawesome CSS -->
		<link rel="stylesheet" href="assets/plugins/fontawesome/css/fontawesome.min.css">
		<link rel="stylesheet" href="assets/plugins/fontawesome/css/all.min.css">
		
		<!-- Select2 CSS -->
		<link rel="stylesheet" href="assets/plugins/select2/css/select2.min.css">
		
		<!-- Main CSS -->
		<link rel="stylesheet" href="assets/css/style.css">

</head>
	<body>

		<!-- Main Wrapper -->
		<div class="main-wrapper">
		
			<!-- Header -->
			<?php include 'includes/navbar.php'; ?>
			<!-- /Header -->
			
			<!-- Breadcrumb -->
			<div class="breadcrumb-bar">
				<div class="container-fluid">
					<div class="row align-items-center">
						<div class="col-md-12 col-12">
							<nav aria-label="breadcrumb" class="page-breadcrumb">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="index.php">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Schedule Timings</li>
								</ol>
							</nav>
							<h2 class="breadcrumb-title">Schedule Timings</h2>
						</div>
					</div>
				</div>
			</div>
			<!-- /Breadcrumb -->
			
			<!-- Page Content -->
			<div class="content">
				<div class="container-fluid">
					<div>
						<?php
						      if(isset($_SESSION['error'])){
						        echo "
						          <div class='callout callout-danger text-center'>
						            <p>".$_SESSION['error']."</p><br> 
						          </div>
						        ";
						        unset($_SESSION['error']);
						      }
						      if(isset($_SESSION['success'])){
						        echo "
						          <div class='callout callout-success text-center'>
						            <p>".$_SESSION['success']."</p><br>
						          </div>
						        ";
						        unset($_SESSION['success']);
						      }
						?>
						</div>
					<div class="row">
						<div class="col-md-5 col-lg-4 col-xl-3 theiaStickySidebar">
						
							<!-- Profile Sidebar -->
							<?php include 'includes/doc-profile-sidebar.php'; ?>
							<!-- /Profile Sidebar -->
							
						</div>
						
						<div class="col-md-7 col-lg-8 col-xl-9">
							<div class="row">
								<div class="col-sm-12">
									<div class="card">
										<div class="card-body">
											<h4 class="card-title">Schedule Timings</h4>
											<div class="profile-box">     
												<div class="row">
													<div class="col-md-12">
														<div class="card schedule-widget mb-0">
															<!-- Schedule Header -->
															<div class="schedule-header">
															
																<!-- Schedule Nav -->
																<div class="schedule-nav">
																	<ul class="nav nav-tabs nav-justified">
																		<li class="nav-item">
																			<a class="nav-link" data-toggle="tab" href="#slot_sunday" id="sun">Sunday</a>
																		</li>
																		<li class="nav-item">
																			<a class="nav-link active" data-toggle="tab" href="#slot_monday" id="mon">Monday</a>
																		</li>
																		<li class="nav-item">
																			<a class="nav-link" data-toggle="tab" href="#slot_tuesday" id="tue">Tuesday</a>
																		</li>
																		<li class="nav-item">
																			<a class="nav-link" data-toggle="tab" href="#slot_wednesday" id="wed">Wednesday</a>
																		</li>
																		<li class="nav-item">
																			<a class="nav-link" data-toggle="tab" href="#slot_thursday" id="thu">Thursday</a>
																		</li>
																		<li class="nav-item">
																			<a class="nav-link" data-toggle="tab" href="#slot_friday" id="fri">Friday</a>
																		</li>
																		<li class="nav-item">
																			<a class="nav-link" data-toggle="tab" href="#slot_saturday" id="sat">Saturday</a>
																		</li>
																	</ul>
																</div>
																<!-- /Schedule Nav -->
															</div>
															<!-- /Schedule Header -->
															
															<!-- Schedule Content -->
															<div class="tab-content schedule-cont">
															<?php
															$days=['sunday','monday','tuesday','wednesday','thursday','friday','saturday']; 
															for($i=0;$i<7;$i++) {													
															echo'
																<div id="slot_'.$days[$i].'" class="tab-pane fade '.((($days[$i])=='monday')?'show active':'').'">
																	<h4 class="card-title d-flex justify-content-between">
																		<span>Time Slots</span>'.((($timing[$days[$i]])==null)?
																		'<a class="edit-link" data-toggle="modal" href="#edit_time_slot"><i class="fa fa-plus-circle"></i> Add Slot</a>':'<a class="edit-link" data-toggle="modal" href="#edit_time_slot"><i class="fa fa-edit mr-1"></i>Edit</a>').'
																	</h4>
																	<div class="doc-times">';
																		if(is_null($timing[$days[$i]])){
																			echo '<p class="text-muted mb-0">Not Available</p>';
																		}
																		else{
																			$slots=explode(',',$timing[$days[$i]]);
																			for($j=0;$j<count($slots);$j++)
																				echo '<div class="doc-slot-list">
																						'.$slots[$j].'
																				</div>';
																		}
																		
																	echo '</div>
																</div>';
																}?>
																</div>
																													
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
								
						</div>
					</div>

				</div>

			</div>		
			<!-- /Page Content -->
   
			<!-- Footer -->
			<?php include 'includes/footer.php'; ?>
			<!-- /Footer -->
		   
		</div>
		<!-- /Main Wrapper -->
		
		<!-- Edit Time Slot Modal -->
		<div class="modal fade custom-modal" id="edit_time_slot">
			<div class="modal-dialog modal-dialog-centered">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title">Edit Time Slots</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body">
						<form action="update_timing.php" method="POST">
							<div class="hours-info" id="hours-info">
								<?php
								if(!is_null($timing[$days[1]])){
								$slots=explode(',',$timing[$days[1]]);
								for($i=0;$i<count($slots);$i++){
									$st=explode('-',$slots[$i]);
									$et=trim($st[1]);
									$st=trim($st[0]);
									echo'
								<div class="row form-row hours-cont">
									<div class="col-12 col-md-10">
										<div class="row form-row">
											<div class="col-12 col-md-6">
												<div class="form-group">
													<label>Start Time</label>
													<input type="text" name="stime_'.$i.'" class="form-control" value="'.$st.'">
													<input type="hidden" name="day_name" value="'.$days[1].'">
													<input type="hidden" name="slots" value="'.count($slots).'">
												</div> 
											</div>
											<div class="col-12 col-md-6">
												<div class="form-group">
													<label>End Time</label>
													<input type="text" name="etime_'.$i.'" class="form-control" value="'.$et.'">
												</div> 
											</div>
										</div>
									</div>
									<div class="col-12 col-md-2"><label class="d-md-block d-sm-none d-none">&nbsp;</label><button id="ts_'.$i.'" class="btn btn-danger" style="width: 68px;"><i class="far fa-trash-alt"></i></button></div>
								</div>';}}?>
								
							</div>
							<div class="add-more mb-3">
								<a href="#none" onclick="add_new_time_sloat()" ><i class="fa fa-plus-circle"></i> Add More</a>
							</div>
							<script type="text/javascript">
								function add_new_time_sloat() {
									
								 var b = document.createElement("div");
								   b.innerHTML='<div class="row form-row hours-cont"><div class="col-12 col-md-10"><div class="row form-row"><div class="col-12 col-md-6"><div class="form-group"><label>Start Time</label><input type="text" id="stime" class="form-control" ></div></div><div class="col-12 col-md-6"><div class="form-group"><label>End Time</label><input type="text" id="etime" class="form-control" ></div></div></div></div><div class="col-12 col-md-2"><label class="d-md-block d-sm-none d-none">&nbsp;</label><button class="btn btn-success" id="add_slot" style="width: 68px;">Add</button></div></div>'
								   
								   var element = document.getElementById("hours-info");
								   element.appendChild(b);}
							</script>
							<div class="submit-section text-center">
								<input type="hidden" name="did" value="<?php echo $row['did']?>">
								<button type="submit" class="btn btn-primary submit-btn" name="change_time_slots">Save Changes</button>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
		<!-- /Edit Time Slot Modal -->
	  
		<!-- jQuery -->
		<script src="assets/js/jquery.min.js"></script>

		<script type="text/javascript">

			$(document).on('click', '#sun', function(e){
			    e.preventDefault();
			    $('#hours-info').html(`<?php
			    				if(!is_null($timing[$days[0]])){
								$slots=explode(',',$timing[$days[0]]);
								for($i=0;$i<count($slots);$i++){
									$st=explode('-',$slots[$i]);
									$et=$st[1];
									$st=trim($st[0]);
									echo'
								<div class="row form-row hours-cont">
									<div class="col-12 col-md-10">
										<div class="row form-row">
											<div class="col-12 col-md-6">
												<div class="form-group">
													<label>Start Time</label>
													<input type="text" name="stime_'.$i.'" class="form-control" value="'.$st.'">
													<input type="hidden" name="day_name" value="'.$days[0].'">
													<input type="hidden" name="slots" value="'.count($slots).'">
												</div> 
											</div>
											<div class="col-12 col-md-6">
												<div class="form-group">
													<label>End Time</label>
													<input type="text" name="etime_'.$i.'" class="form-control" value="'.$et.'">
												</div> 
											</div>
										</div>
									</div>
									<div class="col-12 col-md-2"><label class="d-md-block d-sm-none d-none">&nbsp;</label><button id="ts_'.$i.'" class="btn btn-danger" style="width: 68px;"><i class="far fa-trash-alt"></i></button></div>
								</div>';}}?>`);
			    });

			$(document).on('click', '#mon', function(e){
			    e.preventDefault();
			    $('#hours-info').html(`<?php
			    				if(!is_null($timing[$days[1]])){
								$slots=explode(',',$timing[$days[1]]);
								for($i=0;$i<count($slots);$i++){
									$st=explode('-',$slots[$i]);
									$et=$st[1];
									$st=trim($st[0]);
									echo'
								<div class="row form-row hours-cont">
									<div class="col-12 col-md-10">
										<div class="row form-row">
											<div class="col-12 col-md-6">
												<div class="form-group">
													<label>Start Time</label>
													<input type="text" name="stime_'.$i.'" class="form-control" value="'.$st.'">
													<input type="hidden" name="day_name" value="'.$days[1].'">
													<input type="hidden" name="slots" value="'.count($slots).'">
												</div> 
											</div>
											<div class="col-12 col-md-6">
												<div class="form-group">
													<label>End Time</label>
													<input type="text" name="etime_'.$i.'" class="form-control" value="'.$et.'">
												</div> 
											</div>
										</div>
									</div>
									<div class="col-12 col-md-2"><label class="d-md-block d-sm-none d-none">&nbsp;</label><button id="ts_'.$i.'" class="btn btn-danger" style="width: 68px;"><i class="far fa-trash-alt"></i></button></div>
								</div>';}}?>`);
			    });
			
			$(document).on('click', '#tue', function(e){
			    e.preventDefault();
			    $('#hours-info').html(`<?php
			    				if(!is_null($timing[$days[2]])){
								$slots=explode(',',$timing[$days[2]]);
								for($i=0;$i<count($slots);$i++){
									$st=explode('-',$slots[$i]);
									$et=$st[1];
									$st=trim($st[0]);
									echo'
								<div class="row form-row hours-cont">
									<div class="col-12 col-md-10">
										<div class="row form-row">
											<div class="col-12 col-md-6">
												<div class="form-group">
													<label>Start Time</label>
													<input type="text" name="stime_'.$i.'" class="form-control" value="'.$st.'">
													<input type="hidden" name="day_name" value="'.$days[2].'">
													<input type="hidden" name="slots" value="'.count($slots).'">
												</div> 
											</div>
											<div class="col-12 col-md-6">
												<div class="form-group">
													<label>End Time</label>
													<input type="text" name="etime_'.$i.'" class="form-control" value="'.$et.'">
												</div> 
											</div>
										</div>
									</div>
									<div class="col-12 col-md-2"><label class="d-md-block d-sm-none d-none">&nbsp;</label><button id="ts_'.$i.'" class="btn btn-danger" style="width: 68px;"><i class="far fa-trash-alt"></i></button></div>
								</div>';}}?>`);
			    });

			$(document).on('click', '#wed', function(e){
			    e.preventDefault();
			    $('#hours-info').html(`<?php
			    				if(!is_null($timing[$days[3]])){
								$slots=explode(',',$timing[$days[3]]);
								for($i=0;$i<count($slots);$i++){
									$st=explode('-',$slots[$i]);
									$et=$st[1];
									$st=trim($st[0]);
									echo'
								<div class="row form-row hours-cont">
									<div class="col-12 col-md-10">
										<div class="row form-row">
											<div class="col-12 col-md-6">
												<div class="form-group">
													<label>Start Time</label>
													<input type="text" name="stime_'.$i.'" class="form-control" value="'.$st.'">
													<input type="hidden" name="day_name" value="'.$days[3].'">
													<input type="hidden" name="slots" value="'.count($slots).'">
												</div> 
											</div>
											<div class="col-12 col-md-6">
												<div class="form-group">
													<label>End Time</label>
													<input type="text" name="etime_'.$i.'" class="form-control" value="'.$et.'">
												</div> 
											</div>
										</div>
									</div>
									<div class="col-12 col-md-2"><label class="d-md-block d-sm-none d-none">&nbsp;</label><button id="ts_'.$i.'" class="btn btn-danger" style="width: 68px;"><i class="far fa-trash-alt"></i></button></div>
								</div>';}}?>`);
			    });

			$(document).on('click', '#thu', function(e){
			    e.preventDefault();
			    $('#hours-info').html(`<?php
			    				if(!is_null($timing[$days[4]])){
								$slots=explode(',',$timing[$days[4]]);
								for($i=0;$i<count($slots);$i++){
									$st=explode('-',$slots[$i]);
									$et=$st[1];
									$st=trim($st[0]);
									echo'
								<div class="row form-row hours-cont">
									<div class="col-12 col-md-10">
										<div class="row form-row">
											<div class="col-12 col-md-6">
												<div class="form-group">
													<label>Start Time</label>
													<input type="text" name="stime_'.$i.'" class="form-control" value="'.$st.'">
													<input type="hidden" name="day_name" value="'.$days[4].'">
													<input type="hidden" name="slots" value="'.count($slots).'">
												</div> 
											</div>
											<div class="col-12 col-md-6">
												<div class="form-group">
													<label>End Time</label>
													<input type="text" name="etime_'.$i.'" class="form-control" value="'.$et.'">
												</div> 
											</div>
										</div>
									</div>
									<div class="col-12 col-md-2"><label class="d-md-block d-sm-none d-none">&nbsp;</label><button id="ts_'.$i.'" class="btn btn-danger" style="width: 68px;"><i class="far fa-trash-alt"></i></button></div>
								</div>';}}?>`);
			    });

			$(document).on('click', '#fri', function(e){
			    e.preventDefault();
			    $('#hours-info').html(`<?php
			    				if(!is_null($timing[$days[5]])){
								$slots=explode(',',$timing[$days[5]]);
								for($i=0;$i<count($slots);$i++){
									$st=explode('-',$slots[$i]);
									$et=$st[1];
									$st=trim($st[0]);
									echo'
								<div class="row form-row hours-cont">
									<div class="col-12 col-md-10">
										<div class="row form-row">
											<div class="col-12 col-md-6">
												<div class="form-group">
													<label>Start Time</label>
													<input type="text" name="stime_'.$i.'" class="form-control" value="'.$st.'">
													<input type="hidden" name="day_name" value="'.$days[5].'">
													<input type="hidden" name="slots" value="'.count($slots).'">
												</div> 
											</div>
											<div class="col-12 col-md-6">
												<div class="form-group">
													<label>End Time</label>
													<input type="text" name="etime_'.$i.'" class="form-control" value="'.$et.'">
												</div> 
											</div>
										</div>
									</div>
									<div class="col-12 col-md-2"><label class="d-md-block d-sm-none d-none">&nbsp;</label><button id="ts_'.$i.'" class="btn btn-danger" style="width: 68px;"><i class="far fa-trash-alt"></i></button></div>
								</div>';}}?>`);
			    });

			$(document).on('click', '#sat', function(e){
			    e.preventDefault();
			    $('#hours-info').html(`<?php
			    				if(!is_null($timing[$days[6]])){
								$slots=explode(',',$timing[$days[6]]);
								for($i=0;$i<count($slots);$i++){
									$st=explode('-',$slots[$i]);
									$et=$st[1];
									$st=trim($st[0]);
									echo'
								<div class="row form-row hours-cont">
									<div class="col-12 col-md-10">
										<div class="row form-row">
											<div class="col-12 col-md-6">
												<div class="form-group">
													<label>Start Time</label>
													<input type="text" name="stime_'.$i.'"  class="form-control" value="'.$st.'">
													<input type="hidden" name="day_name" value="'.$days[6].'">
													<input type="hidden" name="slots" value="'.count($slots).'">
												</div> 
											</div>
											<div class="col-12 col-md-6">
												<div class="form-group">
													<label>End Time</label>
													<input type="text" name="etime_'.$i.'" class="form-control" value="'.$et.'">
												</div> 
											</div>
										</div>
									</div>
									<div class="col-12 col-md-2"><label class="d-md-block d-sm-none d-none">&nbsp;</label><button id="ts_'.$i.'" class="btn btn-danger" style="width: 68px;"><i class="far fa-trash-alt"></i></button></div>
								</div>';}}?>`);
			    });

			$(document).on('click', '#add_slot', function(e){
			    e.preventDefault();
			    var stime = $('#stime').val();
			    var etime = $('#etime').val();
			    var day=$(`[class='nav-link active']`).attr('href').replace('#slot_', '');
			    var mode='insert';
			    var did=<?php echo $row['did']?>;
			    $.ajax({
			      type: 'POST',
			      url: 'update_timing.php',
			      data: {stime:stime,etime:etime,day:day,did:did,mode:mode},
			      dataType: 'json',
			      success: function(response){
			        if(!response.error){
			          location.reload(); 
			        }
			      }
			    });
			  });

			<?php for($i=0;$i<7;$i++){
				echo"

					$(document).on('click','#ts_".$i."',function(e){
						e.preventDefault();
				    var stime = $('input[name=stime_".$i."]').val();
				    var etime = $('input[name=etime_".$i."]').val();
				    var mode='delete';
				    var did=".$row['did']."
    			    var day=$(`[class='nav-link active']`).attr('href').replace('#slot_', '');
    			   
				    $.ajax({
				      type: 'POST',
				      url: 'update_timing.php',
				      data: {stime:stime,etime:etime,day:day,did:did,mode:mode},
				      dataType: 'json',
				      success: function(response){
				        if(!response.error){
				          location.reload(); 
				        }
				      },
				      error: function(response){
				      	
				      }
				    });
				  });
					";
											
				}?>
		</script>
		
		<!-- Bootstrap Core JS -->
		<script src="assets/js/popper.min.js"></script>
		<script src="assets/js/bootstrap.min.js"></script>
		
		<!-- Sticky Sidebar JS -->
        <script src="assets/plugins/theia-sticky-sidebar/ResizeSensor.js"></script>
        <script src="assets/plugins/theia-sticky-sidebar/theia-sticky-sidebar.js"></script>
		
		<!-- Select2 JS -->
		<script src="assets/plugins/select2/js/select2.min.js"></script>
		
		<!-- Custom JS -->
		<script src="assets/js/script.js"></script>
		
	</body>
</html>