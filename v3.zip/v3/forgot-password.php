<?php include 'includes/session.php'; ?>
<!DOCTYPE html> 
<html lang="en">
<?php include 'includes/header.php'; ?>

	<body class="account-page">

		<!-- Main Wrapper -->
		<div class="main-wrapper">
		
			<!-- Header -->
			<?php include 'includes/navbar.php'; ?>
			<!-- /Header -->
			
			<!-- Page Content -->
			<div class="content">
				<div class="container-fluid">
					<div><br>
                                <?php
                                      if(isset($_SESSION['error'])){
                                        echo "
                                          <div class='callout callout-danger text-center'>
                                            <p>".$_SESSION['error']."</p><br> 
                                          </div>
                                        ";
                                        unset($_SESSION['error']);
                                      }
                                      if(isset($_SESSION['success'])){
                                        echo "
                                          <div class='callout callout-success text-center'>
                                            <p>".$_SESSION['success']."</p><br>
                                          </div>
                                        ";
                                        unset($_SESSION['success']);
                                      }
                                ?>
                    </div>
					<div class="row">
						<div class="col-md-8 offset-md-2">
							
							<!-- Account Content -->
							<div class="account-content">
								<div class="row align-items-center justify-content-center">
									
									<div class="col-md-12 col-lg-6 login-right">
										<div class="login-header">
											<h3>Forgot Password?</h3>
											<p class="small text-muted">Enter your email to get a password reset link</p>
										</div>
										
										<!-- Forgot Password Form -->
										<form action="reset.php" method="POST">
											<div class="form-group form-focus">
												<input id="email" name="email" type="email" class="form-control floating" required pattern="^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$" oninvalid="this.setCustomValidity('Plase Enter Valid Email Address')" oninput="this.setCustomValidity('')" value="<?php echo (isset($_SESSION['email'])) ? $_SESSION['email'] : '' ?>" >
												<label class="focus-label">Email</label>
											</div>
											<div class="text-right">
												<a class="forgot-link" href="login.php">Remember your password?</a>
											</div>
											<button class="btn btn-primary btn-block btn-lg login-btn" type="submit" name="reset">Reset Password</button>
										</form>
										<!-- /Forgot Password Form -->
										
									</div>
								</div>
							</div>
							<!-- /Account Content -->
							
						</div>
					</div>

				</div>

			</div>		
			<!-- /Page Content -->
   
			<!-- Footer -->
			<?php include 'includes/footer.php'; ?>
			<!-- /Footer -->
		   
		</div>
		<?php include 'includes/scripts.php'; ?>
	</body>
</html>