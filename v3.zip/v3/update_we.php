<?php include 'includes/session.php'; ?>
<?php
$conn = $pdo->open();
$output = array('error'=>false,'message'=>'');

$mode=$_POST['mode'];
$h_name=$_POST['hn'];
$etime=$_POST['etime'];
$des=$_POST['des'];

if(isset($_SESSION['user'])){
	if($mode=='insert'){
		try{
			$stmt = $conn->prepare("SELECT h_name from doctor where user_id=:uid");
			$stmt->execute([':uid'=>$user['id']]);
			$row = $stmt->fetch();
			if(is_null($row['h_name'])){
				$stmt = $conn->prepare("UPDATE doctor set h_name=:h_name,etime=:etime,designation=:des where user_id=:uid");
				$stmt->execute([':h_name'=>$h_name,':etime'=>$etime,':des'=>$des,':uid'=>$user['id']]);
			
			}
			else{
			$stmt = $conn->prepare("UPDATE doctor set h_name=CONCAT(h_name, '@@', :h_name),etime=CONCAT(etime, '@@', :etime),designation=CONCAT(designation, '@@', :des) where user_id=:uid");
			$stmt->execute([':h_name'=>$h_name,':etime'=>$etime,':des'=>$des,':uid'=>$user['id']]);
			}
		}
		catch(PDOException $e){
			$output['message'] = $e->getMessage();
		}
	}
	else{
		try{
			
			$stmt = $conn->prepare("UPDATE doctor set h_name=REPLACE(h_name,:h_name,''),etime=REPLACE(etime,:etime,''),designation=REPLACE(designation,:des,'') where user_id=:uid");
			$stmt->execute([':h_name'=>$h_name,':etime'=>$etime,':des'=>$des,':uid'=>$user['id']]);
			$stmt = $conn->prepare("UPDATE doctor set h_name=REPLACE(h_name,'@@@@','@@'),etime=REPLACE(etime,'@@@@','@@'),designation=REPLACE(designation,'@@@@','@@') where user_id=:uid");
			$stmt->execute([':uid'=>$user['id']]);
			
			
			$stmt = $conn->prepare("select RIGHT(h_name,2) as l from doctor  where user_id=:uid");
			$stmt->execute([':uid'=>$user['id']]);
			$row = $stmt->fetch();
			if($row['l']=='@@'){
				$stmt = $conn->prepare("UPDATE doctor set h_name=SUBSTR(h_name, 1, LENGTH(h_name) - 2),etime=SUBSTR(etime, 1, LENGTH(etime) - 2),designation=SUBSTR(designation, 1, LENGTH(designation) - 2) where user_id=:uid");
				$stmt->execute([':uid'=>$user['id']]);
			}

			$stmt = $conn->prepare("select LEFT(h_name,2) as l from doctor  where user_id=:uid");
			$stmt->execute([':uid'=>$user['id']]);
			$row = $stmt->fetch();
			if($row['l']=='@@'){
				$stmt = $conn->prepare("UPDATE doctor set h_name=SUBSTR(h_name, 3, LENGTH(h_name)),etime=SUBSTR(etime, 3, LENGTH(etime)),designation=SUBSTR(designation, 3, LENGTH(designation)) where user_id=:uid");
				$stmt->execute([':uid'=>$user['id']]);
			}

			$stmt = $conn->prepare("SELECT h_name from doctor where user_id=:uid");
			$stmt->execute([':uid'=>$user['id']]);
			$row = $stmt->fetch();
			
			if($row['h_name']==''){
				$stmt = $conn->prepare("UPDATE doctor set h_name=NULL,etime=NULL,designation=NULL where user_id=:uid");
				$stmt->execute([':uid'=>$user['id']]);
			
			}
			
		}
		catch(PDOException $e){
			$output['message'] = $e->getMessage();
		}

	}
}

	$pdo->close();
	echo json_encode($output);
?>