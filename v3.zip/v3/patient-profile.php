<?php include 'includes/session.php'; ?>
<!DOCTYPE html> 
<html lang="en">
<?php
$pid=$_GET['pid'];
$conn = $pdo->open();
try{
$stmt = $conn->prepare("SELECT img,name,city,state,mobileno,date_of_birth,blood_group,gender FROM patient JOIN users WHERE users.id = patient.user_id AND patient.id=:pid");
$stmt->execute([":pid"=>$pid]);
$row = $stmt->fetch();
$age= date_diff(date_create($row['date_of_birth']), date_create(date("Y-m-d")));
$age= $age->format('%y');
$stmt = $conn->prepare("SELECT doctor.id as did FROM doctor JOIN users WHERE users.id = doctor.user_id AND doctor.user_id=:uid");
$stmt->execute([":uid"=>$user['id']]);
$doc=$stmt->fetch();
$doc=$doc['did'];
}
catch(PDOException $e){
	$_SESSION['error'] = $e->getMessage();
}
$pdo->close();
?>
<head>
		<meta charset="utf-8">
		<title>OHAS</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
		
		<!-- Favicons -->
		<link href="assets/img/favicon.png" rel="icon">
		
		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="assets/css/bootstrap.min.css">
		
		<!-- Fontawesome CSS -->
		<link rel="stylesheet" href="assets/plugins/fontawesome/css/fontawesome.min.css">
		<link rel="stylesheet" href="assets/plugins/fontawesome/css/all.min.css">
		
		<!-- Datetimepicker CSS -->
		<link rel="stylesheet" href="assets/css/bootstrap-datetimepicker.min.css">
		
		<!-- Main CSS -->
		<link rel="stylesheet" href="assets/css/style.css">
	
	</head>
	<body>

		<!-- Main Wrapper -->
		<div class="main-wrapper">
		
			<!-- Header -->
			<?php include 'includes/navbar.php'; ?>
			<!-- /Header -->
			
			<!-- Breadcrumb -->
			<div class="breadcrumb-bar">
				<div class="container-fluid">
					<div class="row align-items-center">
						<div class="col-md-12 col-12">
							<nav aria-label="breadcrumb" class="page-breadcrumb">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="index.php">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Profile</li>
								</ol>
							</nav>
							<h2 class="breadcrumb-title">Profile</h2>
						</div>
					</div>
				</div>
			</div>
			<!-- /Breadcrumb -->
			
			<!-- Page Content -->
			<div class="content">
				<div class="container-fluid">

					<div class="row">
						<div class="col-md-5 col-lg-4 col-xl-3 theiaStickySidebar dct-dashbd-lft">
						
							<!-- Profile Widget -->
							<div class="card widget-profile pat-widget-profile">
								<div class="card-body">
									<div class="pro-widget-content">
										<div class="profile-info-widget">
											<a href="#" class="booking-doc-img">
												<img src="assets/img/patients/<?php echo $row['img']?>" alt="User Image">
											</a>
											<div class="profile-det-info">
												<h3><?php echo $row['name']?></h3>
												
												<div class="patient-details">
													<h5><b>Patient ID :</b> PT<?php echo $pid?></h5>
													<h5 class="mb-0"><i class="fas fa-map-marker-alt"></i> <?php echo $row['city']?>, <?php echo $row['state']?></h5>
												</div>
											</div>
										</div>
									</div>
									<div class="patient-info">
										<ul>
											<li>Phone <span>+91 <?php echo $row['mobileno']?></span></li>
											<li>Age <span><?php echo $age?> Years, <?php echo ($row['gender']==1)?'Male':'Female' ?></span></li>
											<li>Blood Group <span><?php echo $row['blood_group']?></span></li>
										</ul>
									</div>
								</div>
							</div>
							<!-- /Profile Widget -->
							<!-- Last Booking -->
							<div class="card">
								<div class="card-header">
									<h4 class="card-title">Last Booking</h4>
								</div>
								<ul class="list-group list-group-flush">
									<?php
										$conn = $pdo->open();
										try{
										$stmt = $conn->prepare("SELECT img,name,doc_type,a_date,a_time FROM appointments JOIN doctor JOIN users WHERE users.id = doctor.user_id AND doctor.id=appointments.did AND appointments.pid=:pid ORDER BY appointments.id DESC LIMIT 2");
										$stmt->execute([":pid"=>$pid]);
										}
										catch(PDOException $e){
													$_SESSION['error'] = $e->getMessage();
										}
										$pdo->close();
									foreach ($stmt as $row) {
									echo'
									<li class="list-group-item">
										<div class="media align-items-center">
											<div class="mr-3">
												<img alt="Image placeholder" src="assets/img/doctors/'.$row['img'].'" class="avatar  rounded-circle">
											</div>
											<div class="media-body">
												<h5 class="d-block mb-0">Dr. '.$row['name'].' </h5>
												<span class="d-block text-sm text-muted">'.$row['doc_type'].'</span>
												<span class="d-block text-sm text-muted">'.$row['a_date'].' '.$row['a_time'].'</span>
											</div>
										</div>
									</li>';}?>
								</ul>
							</div>
							<!-- /Last Booking -->
							
						</div>

						<div class="col-md-7 col-lg-8 col-xl-9 dct-appoinment">
							<div class="card">
								<div class="card-body pt-0">
									<div class="user-tabs">
										<ul class="nav nav-tabs nav-tabs-bottom nav-justified flex-wrap">
											<li class="nav-item">
												<a class="nav-link active" href="#pat_appointments" data-toggle="tab">Appointments</a>
											</li>
											<li class="nav-item">
												<a class="nav-link" href="#pres" data-toggle="tab"><span>Prescription</span></a>
											</li>
											<li class="nav-item">
												<a class="nav-link" href="#medical" data-toggle="tab"><span class="med-records">Medical Records</span></a>
											</li>
											<li class="nav-item">
												<a class="nav-link" href="#billing" data-toggle="tab"><span>Billing</span></a>
											</li> 
										</ul>
									</div>
									<div class="tab-content">
										
										<!-- Appointment Tab -->
										<div id="pat_appointments" class="tab-pane fade show active">
											<div class="card card-table mb-0">
												<div class="card-body">
													<div class="table-responsive">
														<table class="table table-hover table-center mb-0">
															<thead>
																<tr>
																	<th>Doctor</th>
																	<th>Appt Date</th>
																	<th>Appt Type</th>
																	<th>Payment Type</th>
																	<th>Amount</th>
																	<th>Appt Status</th>
																</tr>
															</thead>
															<tbody>
																<?php
																	$conn = $pdo->open();
																	$bgc=['Pending'=>'warning','Cancelled'=>'danger','Confirm'=>'success','Completed'=>'info'];
																	try{
																	$stmt = $conn->prepare("SELECT doctor.id as did,img,name,doc_type,a_date,a_time,appointment_type,amount,status,p_type FROM appointments JOIN doctor JOIN users JOIN payment WHERE users.id = doctor.user_id AND doctor.id=appointments.did AND payment.id=appointments.payment_id AND appointments.pid=:pid ORDER BY appointments.id DESC");
																	$stmt->execute([":pid"=>$pid]);
																	}
																	catch(PDOException $e){
																				$_SESSION['error'] = $e->getMessage();
																	}
																	$pdo->close();
																foreach ($stmt as $row) {
																echo'
																<tr>
																	<td>
																		<h2 class="table-avatar">
																			<a href="doctor-profile.php?id='.$row['did'].'" class="avatar avatar-sm mr-2">
																				<img class="avatar-img rounded-circle" src="assets/img/doctors/'.$row['img'].'" alt="User Image">
																			</a>
																			<a href="doctor-profile.php?id='.$row['did'].'">Dr. '.$row['name'].' <span>'.$row['doc_type'].'</span></a>
																		</h2>
																	</td>
																	<td>'.$row['a_date'].' <span class="d-block text-info">'.$row['a_time'].'</span></td>
																	<td>'.$row['appointment_type'].'</td>
																	<td>'.$row['p_type'].'</td>
																	<td>&#8377; '.$row['amount'].'</td>
																	<td><span class="badge badge-pill bg-'.$bgc[$row['status']].'-light">'.$row['status'].'</span></td>
																</tr>';}?>
															</tbody>
														</table>
													</div>
												</div>
											</div>
										</div>
										<!-- /Appointment Tab -->
										
										<!-- Prescription Tab -->
										<div class="tab-pane fade" id="pres">
											<div class="text-right">
												<a href="add-prescription.php?pid=<?php echo $pid ?>&e=0" class="add-new-btn">Add Prescription</a>
											</div>
											<div class="card card-table mb-0">
												<div class="card-body">
													<div class="table-responsive">
														<table class="table table-hover table-center mb-0">
															<thead>
																<tr>
																	<th>ID</th>
																	<th>Date </th>									
																	<th>Created by </th>
																	<th></th>
																</tr>     
															</thead>
															<tbody>
																<?php
																	$conn = $pdo->open();
																	
																	try{
																	$stmt = $conn->prepare("SELECT prescription.id as prid,doctor.id as did,doctor.user_id as duid,img,name,doc_type,`date` FROM doctor JOIN users JOIN prescription WHERE users.id = doctor.user_id AND doctor.id=prescription.did AND prescription.pid=:pid ORDER BY prescription.id DESC");
																	$stmt->execute([":pid"=>$pid]);
																	}
																	catch(PDOException $e){
																				$_SESSION['error'] = $e->getMessage();
																	}
																	$pdo->close();
																foreach ($stmt as $row) {
																echo'
																<tr>
																	<td>#PR-'.$row['prid'].'</td>
																	<td>'.$row['date'].'</td>
																	<td>
																		<h2 class="table-avatar">
																			<a href="doctor-profile.php?id='.$row['did'].'" class="avatar avatar-sm mr-2">
																				<img class="avatar-img rounded-circle" src="assets/img/doctors/'.$row['img'].'" alt="User Image">
																			</a>
																			<a href="doctor-profile.php?id='.$row['did'].'">Dr. '.$row['name'].' <span>'.$row['doc_type'].'</span></a>
																		</h2>
																	</td>
																	<td class="text-right">
																		<div class="table-action">
																			'.(($row['duid']==$user['id'])?'<a href="add-prescription.php?pid='.$pid.'&e=1&id='.$row['prid'].'" class="btn btn-sm bg-success-light">
																				<i class="fas fa-edit"></i> Edit
																			</a>':'').'
																			<a href="prescription-view.php?prid='.$row['prid'].'" class="btn btn-sm bg-info-light">
																				<i class="far fa-eye"></i> View
																			</a>
																		</div>
																	</td>
																</tr>';}?>
																
															</tbody>	
														</table>
													</div>
												</div>
											</div>
										</div>
										<!-- /Prescription Tab -->

										<!-- Medical Records Tab -->
										<div class="tab-pane fade" id="medical">
											<div class="text-right">		
												<a href="#" class="add-new-btn" data-toggle="modal" data-target="#add_medical_records">Add Medical Records</a>
											</div>
											<div class="card card-table mb-0">
												<div class="card-body">
													<div class="table-responsive">
														<table class="table table-hover table-center mb-0">
															<thead>
																<tr>
																	<th>ID</th>
																	<th>Date </th>
																	<th>Description</th>
																	<th>Attachment</th>
																	<th>Created By</th>
																	<th></th>
																</tr>     
															</thead>
															<tbody>
																<?php
																	$conn = $pdo->open();
																	
																	try{
																	$stmt = $conn->prepare("SELECT medical_record.id as mrid,doctor.id as did,doctor.user_id as duid,img,name,doc_type,`date`,description,attachment FROM doctor JOIN users JOIN medical_record WHERE users.id = doctor.user_id AND doctor.id=medical_record.did AND medical_record.pid=:pid ORDER BY medical_record.id DESC");
																	$stmt->execute([":pid"=>$pid]);
																	}
																	catch(PDOException $e){
																		$_SESSION['error'] = $e->getMessage();
																	}
																	$pdo->close();
																	$i=-1;
																foreach ($stmt as $row) {
																echo'
																<tr>
																	<td><a href="javascript:void(0);">#MR-'.$row['mrid'].'</a></td>
																	<td>'.$row['date'].'</td>
																	<td>'.$row['description'].'</td>
																	<td>'.(!(is_null($row['attachment']))?'<a href="assets/m_file/'.$row['attachment'].'">MR_'.$row['attachment'].'</a>':'').'</td>
																	<td>
																		<h2 class="table-avatar">
																			<a href="doctor-profile.php?id='.$row['did'].'" class="avatar avatar-sm mr-2">
																				<img class="avatar-img rounded-circle" src="assets/img/doctors/'.$row['img'].'" alt="User Image">
																			</a>
																			<a href="doctor-profile.php?id='.$row['did'].'">Dr. '.$row['name'].' <span>'.$row['doc_type'].'</span></a>
																		</h2>
																	</td>
																	<td class="text-right">
																		<div class="table-action">
																			'.(($row['duid']==$user['id'])?'<a href="" id="emr_'.++$i.'" class="btn btn-sm bg-success-light" data-toggle="modal" data-target="#add_medical_records">
																				<i class="fas fa-edit"></i> Edit
																			</a>':'').'
																		</div>
																	</td>
																</tr>';}
																?>
																
															</tbody>  	
														</table>
													</div>
												</div>
											</div>
										</div>
										<!-- /Medical Records Tab -->
										
										<!-- Billing Tab -->
										<div class="tab-pane" id="billing">
											<div class="card card-table mb-0">
												<div class="card-body">
													<div class="table-responsive">
													
														<table class="table table-hover table-center mb-0">
															<thead>
																<tr>
																	<th>Invoice No</th>
																	<th>Doctor</th>
																	<th>Payment Type</th>
																	<th>Amount</th>
																	<th>Paid On</th>
																</tr>
															</thead>
															<tbody>
																<?php
																	$conn = $pdo->open();
																	try{
																	$stmt = $conn->prepare("SELECT doctor.id as did,appointments.id as aid,img,name,doc_type,a_date,amount,p_type FROM appointments JOIN doctor JOIN users JOIN payment WHERE users.id = doctor.user_id AND doctor.id=appointments.did AND payment.id=appointments.payment_id AND appointments.pid=:pid ORDER BY appointments.id DESC");
																	$stmt->execute([":pid"=>$pid]);
																	}
																	catch(PDOException $e){
																				$_SESSION['error'] = $e->getMessage();
																	}
																	$pdo->close();
																foreach ($stmt as $row) {
																echo'
																<tr>
																	<td>
																		<a href="invoice-view.php?aid='.$row['aid'].'">#INV-'.$row['aid'].'</a>
																	</td>
																	<td>
																		<h2 class="table-avatar">
																			<a href="doctor-profile.php?id='.$row['did'].'" class="avatar avatar-sm mr-2">
																				<img class="avatar-img rounded-circle" src="assets/img/doctors/'.$row['img'].'" alt="User Image">
																			</a>
																			<a href="doctor-profile.php?id='.$row['did'].'">Dr. '.$row['name'].' <span>'.$row['doc_type'].'</span></a>
																		</h2>
																	</td>
																	<td>'.$row['p_type'].'</td>
																	<td>&#8377; '.$row['amount'].'</td>
																	<td>'.$row['a_date'].'</td>
																	<td class="text-right">
																		<div class="table-action">
																			<a href="invoice-view.php?aid='.$row['aid'].'" class="btn btn-sm bg-info-light">
																				<i class="far fa-eye"></i> View
																			</a>
																		</div>
																	</td>
																</tr>';}?>
															</tbody>
														</table>
													</div>
												</div>
											</div>
										</div>
										<!-- Billing Tab -->
												
									</div>
								</div>
							</div>
						</div>
					</div>

				</div>

			</div>		
			<!-- /Page Content -->
   
			<!-- Footer -->
			<?php include 'includes/footer.php'; ?>
			<!-- /Footer -->
		   
		</div>
		<!-- /Main Wrapper -->
		
		<!-- Add Medical Records Modal -->
		<div class="modal fade custom-modal" id="add_medical_records">
			<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h3 class="modal-title">Medical Records</h3>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					</div>
					<form action="add_medical_records.php" method="POST" enctype="multipart/form-data">					
						<div class="modal-body">
							<div class="form-group">
								<label>Date</label>
								<input type="text" class="form-control datetimepicker" id="m_date" name="m_date" value="<?php echo date('d/m/Y')?>">
							</div>
							<div class="form-group">
								<label>Description ( Optional )</label>
								<textarea class="form-control" id="m_des" name="m_des"></textarea>
							</div>
							<div class="form-group">
								<label>Upload File</label> 
								<input type="file" class="form-control" name="fileToUpload" >
							</div>	
							<div class="submit-section text-center">
								<input type="hidden" id="e" name="e" value="0">
								<input type="hidden" name="pid" value="<?php echo $_GET['pid'] ?>">
								<input type="hidden" name="did" value="<?php echo $doc ?>">
								<input type="hidden" id="mrid" name="mrid">
								<button type="submit" class="btn btn-primary submit-btn" name="submit">Submit</button>
								<button type="button" class="btn btn-secondary submit-btn" data-dismiss="modal">Cancel</button>
															
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
		<!-- /Add Medical Records Modal -->
	  
		<!-- jQuery -->
		<script src="assets/js/jquery.min.js"></script>
		<script type="text/javascript">
			<?php
			$conn = $pdo->open();	
			try{
				$stmt = $conn->prepare("SELECT medical_record.id as mrid,`date`,description FROM doctor JOIN users JOIN medical_record WHERE users.id = doctor.user_id AND doctor.id=medical_record.did AND medical_record.pid=:pid AND doctor.user_id=:uid ORDER BY medical_record.id DESC");
				$stmt->execute([":pid"=>$pid,":uid"=>$user['id']]);
			}
			catch(PDOException $e){
			$_SESSION['error'] = $e->getMessage();
			}
			$pdo->close();
			$i=-1;
			foreach ($stmt as $row) {
			echo"
			$(document).on('click', '#emr_".++$i."', function(e){
			    e.preventDefault();
			    var date='".$row["date"]."';
			    var des='".$row["description"]."';
			    var mrid='".$row['mrid']."';
			    $('#m_date').val(date);
			    $('#m_des').val(des);
			    $('#e').val('1');
			    $('#mrid').val(mrid);
			});";}?>
		</script>
		
		<!-- Bootstrap Core JS -->
		<script src="assets/js/popper.min.js"></script>
		<script src="assets/js/bootstrap.min.js"></script>
		
		<!-- Datetimepicker JS -->
		<script src="assets/js/moment.min.js"></script>
		<script src="assets/js/bootstrap-datetimepicker.min.js"></script>
		
		<!-- Sticky Sidebar JS -->
        <script src="assets/plugins/theia-sticky-sidebar/ResizeSensor.js"></script>
        <script src="assets/plugins/theia-sticky-sidebar/theia-sticky-sidebar.js"></script>
		
		<!-- Custom JS -->
		<script src="assets/js/script.js"></script>
		
	</body>

</html>