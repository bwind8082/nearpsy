<?php
include 'includes/session.php';
	
if(isset($_SESSION['user'])){

	if(isset($_POST['update'])){
		$name=$_POST['name'];
		$email=$_POST['email'];
		$mobileno=$_POST['mobileno'];
		$gender=(int)$_POST['gender'];
		$blood_group=$_POST['blood_group'];
		$dob = str_replace('/', '-', $_POST['dob']);
		$dob=date('Y-m-d', strtotime($dob));
		$address=$_POST['address'];
		$city=$_POST['city'];
		$state=$_POST['state'];
		$country=$_POST['country'];
		$postal_code=$_POST['postal_code'];

		$conn = $pdo->open();
		try{
			if($user['is_first_time']==1){
			$stmt=$conn->prepare("UPDATE users SET is_first_time=0 WHERE id=:uid");
			$stmt->execute([':uid'=>$user['id']]);}
		}
		catch(PDOException $e){
			$_SESSION['error'].= $e->getMessage();
		}

		try{
			$stmt=$conn->prepare("UPDATE users SET name=:name,gender=:gender,date_of_birth=:dob WHERE id=:uid");
			$stmt->execute([':name'=>$name,':gender'=>$gender,':dob'=>$dob,':uid'=>$user['id']]);
			$_SESSION['success'] = 'Account Updated Successfully';
			}
			catch(PDOException $e){
			$_SESSION['error'].= "<br>".$e->getMessage();
			}

			if($mobileno!=$user['mobileno'] || $email!=$user['email'])
			{
				$stmt = $conn->prepare("SELECT COUNT(*) AS numrows FROM users WHERE mobileno=:mobileno");
				$stmt1 = $conn->prepare("SELECT COUNT(*) AS numrows FROM users WHERE email=:email");
				$stmt->execute(['mobileno'=>$mobileno]);
				$stmt1->execute(['email'=>$email]);
				$row = $stmt->fetch();
				$row1 = $stmt1->fetch();
					if($row['numrows'] == 0){
					try{
					$stmt=$conn->prepare("UPDATE users SET email=:email WHERE id=:uid");
					$stmt->execute([':email'=>$email,':uid'=>$user['id']]);
					$_SESSION['success'] = 'Account updated successfully';
					}
					catch(PDOException $e){
						$_SESSION['error'].= "<br>".$e->getMessage();
					}}
					else
						$_SESSION['error'].= '<br>Mobile No is already Registered';

					if($row1['numrows'] == 0){
						try{
						$stmt=$conn->prepare("UPDATE users SET mobileno=:mobileno WHERE id=:uid");
						$stmt->execute([':mobileno'=>$mobileno,':uid'=>$user['id']]);
						$_SESSION['success'] = 'Account updated successfully';
						}
						catch(PDOException $e){
							$_SESSION['error'].= "<br>".$e->getMessage();
						}

					}
					else
						$_SESSION['error'].= '<br>Email is already Registered';
			}

			try{

					$stmt = $conn->prepare("UPDATE patient SET blood_group=:blood_group,address=:address,city=:city,state=:state,country=:country,postal_code=:postal_code WHERE user_id=:uid");
					$stmt->execute([':blood_group'=>$blood_group,':address'=>$address,':city'=>$city,':state'=>$state,':country'=>$country,':postal_code'=>$postal_code,':uid'=>$user['id']]);

					$_SESSION['success'] = 'Account Updated Successfully';
				}
				catch(PDOException $e){
					$_SESSION['error'].= "<br>".$e->getMessage();
				}
			$pdo->close();
	}
	else
		$_SESSION['error'].= 'Fill up edit form first';
		header('location: profile-settings.php');
}
else
	header('location: index.php');