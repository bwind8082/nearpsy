<?php include 'includes/session.php'; ?>
<!DOCTYPE html> 
<html lang="en">
<?php
$conn = $pdo->open();
try{
$stmt = $conn->prepare("SELECT *,d.id as did FROM doctor as d JOIN users WHERE users.id = d.user_id AND d.id=:did");
$stmt->execute([":did"=>$_GET['id']]);
$row = $stmt->fetch();
$stmt = $conn->prepare("SELECT hospitals.name,hospitals.address FROM hospitals JOIN doctor WHERE d_id=doctor.id AND doctor.id=:did");
$stmt->execute([":did"=>$_GET['id']]);
$row1 = $stmt->fetch();
$stmt = $conn->prepare("SELECT * FROM doctor_timing WHERE did=:did");
$stmt->execute([":did"=>$_GET['id']]);
$timing = $stmt->fetch();
$stmt = $conn->prepare("SELECT count(feedback.id) as norv,CAST(AVG(rating) AS INT) as rat FROM feedback JOIN users JOIN patient WHERE users.id=feedback.g_uid AND patient.user_id=users.id AND did=:did ");
$stmt->execute([":did"=>$row['did']]);
$rv_detail=$stmt->fetch();
$stmt = $conn->prepare("SELECT count(recommend) as norm FROM feedback JOIN users JOIN patient WHERE users.id=feedback.g_uid AND patient.user_id=users.id AND did=:did AND feedback.recommend=1");
$stmt->execute([":did"=>$row['did']]);
$rc=$stmt->fetch();
$stmt = $conn->prepare("SELECT count(recommend) as norm FROM feedback JOIN users JOIN patient WHERE users.id=feedback.g_uid AND patient.user_id=users.id AND did=:did AND feedback.recommend!=3");
$stmt->execute([":did"=>$row['did']]);
$tr=$stmt->fetch();
$rc=($tr['norm']>0)?round($rc['norm']/$tr['norm']*100,2):'N/A';
if(isset($_SESSION['user']) && $user['type']==1){
$stmt = $conn->prepare("SELECT favourite_did FROM patient JOIN users WHERE patient.user_id=users.id AND users.id=:uid");
$stmt->execute([":uid"=>$user['id']]);
$f=$stmt->fetch();
$f=explode(',',  $f['favourite_did']);
}
}
catch(PDOException $e){
	$_SESSION['error'] = $e->getMessage();
}
$pdo->close();
?>
<head>
		<meta charset="utf-8">
		<title>NearPsy</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
		
		<!-- Favicons -->
		<link href="assets/img/favicon.png" rel="icon">
		
		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="assets/css/bootstrap.min.css">
		
		<!-- Fontawesome CSS -->
		<link rel="stylesheet" href="assets/plugins/fontawesome/css/fontawesome.min.css">
		<link rel="stylesheet" href="assets/plugins/fontawesome/css/all.min.css">
		
		<!-- Fancybox CSS -->
		<link rel="stylesheet" href="assets/plugins/fancybox/jquery.fancybox.min.css">
		
		<!-- Main CSS -->
		<link rel="stylesheet" href="assets/css/style.css">
		<style type="text/css">
			button.like{
				width: 30px;
				height: 30px;
				margin: 0 auto;
				line-heigth: 50px;
				border-radius: 50%;
				color: rgba(0,150,136 ,1);
				background-color:rgba(38,166,154 ,0.3);
				border-color: rgba(0,150,136 ,1);
				border-width: 1px;
				font-size: 15px;
			}

			button.dislike{
				width: 30px;
				height: 30px;
				margin: 0 auto;
				line-heigth: 50px;
				border-radius: 50%;
				color: rgba(255,82,82 ,1);
				background-color: rgba(255,138,128 ,0.3);
				border-color: rgba(255,82,82 ,1);
				border-width: 1px;
				font-size: 15px;
			}
		</style>
	
</head>
	<body>

		<!-- Main Wrapper -->
		<div class="main-wrapper">
			<?php include 'includes/navbar.php'; ?>
			<!-- Header -->
			
			<!-- /Header -->
			
			<!-- Breadcrumb -->
			<div class="breadcrumb-bar">
				<div class="container-fluid">
					<div class="row align-items-center">
						<div class="col-md-12 col-12">
							<nav aria-label="breadcrumb" class="page-breadcrumb">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="index.php">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Doctor Profile</li>
								</ol>
							</nav>
							<h2 class="breadcrumb-title">Doctor Profile</h2>
						</div>
					</div>
				</div>
			</div>
			<!-- /Breadcrumb -->
			
			<!-- Page Content -->
			<div class="content">
				<div class="container">

					<!-- Doctor Widget -->
					<div class="card">
						<div class="card-body">
							<div class="doctor-widget">
								<div class="doc-info-left">
									<div class="doctor-img">
										<img src="assets/img/doctors/<?php echo $row['img']?>" class="img-fluid" alt="User Image">
									</div>
									<div class="doc-info-cont">
										<h4 class="doc-name">Dr. <?php echo $row['name'];?></h4>
										<p class="doc-speciality"><?php echo str_replace("@@",",",$row['degree']);?></p>
										
										<div class="rating">
											<i class="fas fa-star <?php echo ($rv_detail['rat']>0)?'filled':'' ?>"></i>
											<i class="fas fa-star <?php echo ($rv_detail['rat']>1)?'filled':'' ?>"></i>
											<i class="fas fa-star <?php echo ($rv_detail['rat']>2)?'filled':'' ?>"></i>
											<i class="fas fa-star <?php echo ($rv_detail['rat']>3)?'filled':'' ?>"></i>
											<i class="fas fa-star <?php echo ($rv_detail['rat']>4)?'filled':'' ?>"></i>
											<span class="d-inline-block average-rating">(<?php echo $rv_detail['norv'] ?>)</span>
										</div>
										<form action="http://maps.google.com/maps" method="get" target="_blank">
										<div class="clinic-details">
											<input type="hidden" name="saddr" id="myloc" >
   											<input type="hidden" name="daddr" value="<?php echo $row1['address']?>" >
											<p class="doc-location"><i class="fas fa-map-marker-alt"></i> <?php echo $row['city'].', '.$row['state']?> - <a><button style="background: none;color: inherit;border: none;padding: 0;font: inherit;cursor: pointer;outline:inherit;"> Get Directions</button></a></p></form>
											<script>
											var x = document.getElementById("myloc");

											function getLocation() {
											  if (navigator.geolocation) {
											    navigator.geolocation.getCurrentPosition(showPosition);
											  } else { 
											    x.value = "Geolocation is not supported by this browser.";
											  }
											}

											function showPosition(position) {
											  x.value = position.coords.latitude + 
											  "," + position.coords.longitude;
											}
											getLocation();
											</script>
										</div>
										<div class="clinic-services">
											<?php $services=explode(',',$row['services']);?>
											<span><?php echo $services[0]?></span>
											<span><?php echo $services[1]?></span>
										</div>
									</div>
								</div>
								<div class="doc-info-right">
									<div class="clini-infos">
										<ul>
											<li><i class="far fa-thumbs-up"></i> <?php echo $rc ?> %</li>
											<li><i class="far fa-comment"></i> <?php echo $rv_detail['norv'] ?> Feedback</li>
											<li><i class="fas fa-map-marker-alt"></i> <?php echo $row['city'].', '.$row['state']?></li>
											<li><i class="far fa-money-bill-alt"></i> &#8377; <?php echo $row['fees']; ?> per hour </li>
										</ul>
									</div>
									<?php
									echo ((isset($_SESSION['user']) && $user['type']==1)?
									'<div class="doctor-action">
										<a href="javascript:void(0)" class="btn btn-white fav-btn" id="fav" '.((in_array($row['did'], $f))?'style="background-color: #fb1612;border-color: #fb1612;color: #fff"':'').'>
											<i class="far fa-bookmark"></i>
										</a>
									</div>
									<div class="clinic-booking">
										<a class="apt-btn" href="booking.php?did='.$row['did'].'">Book Appointment</a>
									</div>':'')?>
								</div>
							</div>
						</div>
					</div>
					<!-- /Doctor Widget -->
					
					<!-- Doctor Details Tab -->
					<div class="card">
						<div class="card-body pt-0">
						
							<!-- Tab Menu -->
							<nav class="user-tabs mb-4">
								<ul class="nav nav-tabs nav-tabs-bottom nav-justified">
									<li class="nav-item">
										<a class="nav-link active" href="#doc_overview" data-toggle="tab">Overview</a>
									</li>
									<li class="nav-item">
										<a class="nav-link" href="#doc_locations" data-toggle="tab">Location</a>
									</li>
									<li class="nav-item">
										<a class="nav-link" href="#doc_reviews" data-toggle="tab">Reviews</a>
									</li>
									<li class="nav-item">
										<a class="nav-link" href="#doc_business_hours" data-toggle="tab">Business Hours</a>
									</li>
								</ul>
							</nav>
							<!-- /Tab Menu -->
							
							<!-- Tab Content -->
							<div class="tab-content pt-0">
							
								<!-- Overview Content -->
								<div role="tabpanel" id="doc_overview" class="tab-pane fade show active">
									<div class="row">
										<div class="col-md-12 col-lg-9">
										
											<!-- About Details -->
											<div class="widget about-widget">
												<h4 class="widget-title">About Me</h4>
												<p><?php echo $row['about_me']; ?></p>
											</div>
											<!-- /About Details -->
										
											<!-- Education Details -->
											<div class="widget education-widget">
												<h4 class="widget-title">Education</h4>
												<div class="experience-box">
													<ul class="experience-list">
														<?php
														if(!is_null($row['degree'])){
														 $degree=explode("@@",$row['degree']);
														 $institute=explode("@@",$row['institute']);
														 $year_of_completion=explode("@@",$row['year_of_completion']);
														 $no_ed=count($degree);
														for($i=0;$i<$no_ed;$i++){
														echo'
														<li>
															<div class="experience-user">
																<div class="before-circle"></div>
															</div>
															<div class="experience-content">
																<div class="timeline-content">
																	<a href="https://www.google.com/search?q='.$institute[$i].'" class="name" target="_blank">'.$institute[$i].'</a>
																	<div>'.$degree[$i].'</div>
																	<span class="time">'.$year_of_completion[$i].'</span>
																</div>
															</div>
														</li>';}} ?>
														
													</ul>
												</div>
											</div>
											<!-- /Education Details -->
									
											<!-- Experience Details -->
											<div class="widget experience-widget">
												<h4 class="widget-title">Work & Experience</h4>
												<div class="experience-box">
													<ul class="experience-list">
														<?php
														 if(!is_null($row['h_name'])){
														 $hname=explode("@@",$row['h_name']);
														 $temp=explode("@@",$row['etime']);
														 $designation=explode("@@",$row['designation']);
														 $no_we=count($hname);
															for($i=0;$i<$no_we;$i++){ 
																$time=explode('-',$temp[$i]);
																$exp=(int)$time[1]-(int)$time[0];
																if(date("Y")==$time[1])
																	$time[1]='Present';
																$time=implode("-",$time);

																echo '
														<li>
															<div class="experience-user">
																<div class="before-circle"></div>
															</div>
															<div class="experience-content">
																<div class="timeline-content">
																	<a href="https://www.google.com/search?q='.$hname[$i].'" class="name" target="_blank ">'.$hname[$i].'</a>
																	<div>'.$designation[$i].'</div>
																	<span class="time">'.$time.' ('.$exp.' years)</span>
																</div>
															</div>
														</li>';}}?>
														
													</ul>
												</div>
											</div>
											<!-- /Experience Details -->
								
											<!-- Awards Details -->
											<div class="widget awards-widget">
												<h4 class="widget-title">Awards</h4>
												<div class="experience-box">
													<ul class="experience-list">
														<?php
														 if(!is_null($row['award'])){
														 $award=explode("@@",$row['award']);
														 $a_year=explode("@@",$row['a_year']);
														 $no_aw=count($award);
														for($i=0;$i<$no_aw;$i++){ echo '
														<li>
															<div class="experience-user">
																<div class="before-circle"></div>
															</div>
															<div class="experience-content">
																<div class="timeline-content">
																	<p class="exp-year">'.$a_year[$i].'</p>
																	<h4 class="exp-title">'.$award[$i].'</h4>
																</div>
															</div>
														</li>';}}?>
													</ul>
												</div>
											</div>
											<!-- /Awards Details -->
											
											<!-- Services List -->
											<div class="service-list">
												<h4>Services</h4>
												<ul class="clearfix">
													<?php foreach ($services as $s) echo'<li>'.$s.'</li>';?>
												</ul>
											</div>
											<!-- /Services List -->
											
											<!-- Specializations List -->
											<div class="service-list">
												<h4>Specializations</h4>
												<ul class="clearfix">
													<?php 
													$Specializations=explode(',',$row['specializations']);
													foreach ($Specializations as $s) echo'<li>'.$s.'</li>';?>
												</ul>
											</div>
											<!-- /Specializations List -->

										</div>
									</div>
								</div>
								<!-- /Overview Content -->
								
								<!-- Locations Content -->
								<div role="tabpanel" id="doc_locations" class="tab-pane fade">
								
									<!-- Location List -->
									<div class="location-list">
										<div class="row">
										
											<!-- Clinic Content -->
											<div class="col-md-6">
												<div class="clinic-content">
													<h4 class="clinic-name"><a href="#"><?php echo $row1['name']?></a></h4>
													<p class="doc-speciality"><?php echo str_replace("@@",",",$row['degree'])?></p>
													<form action="http://maps.google.com/maps" method="get" target="_blank">
													<div class="clinic-details mb-0">
														<h5 class="clinic-direction"> <i class="fas fa-map-marker-alt"></i> <?php echo $row1['address']?><br>
														<input type="hidden" name="saddr" id="myloc_1" >
			   											<input type="hidden" name="daddr" value="<?php echo $row1['address']?>" >
														<a><button style="background: none;color: inherit;border: none;padding: 0;font: inherit;cursor: pointer;outline:inherit;"> Get Directions</button></a></h5></form>
															<script>
															var x = document.getElementById("myloc_1");

															function getLocation() {
															  if (navigator.geolocation) {
															    navigator.geolocation.getCurrentPosition(showPosition);
															  } else { 
															    x.value = "Geolocation is not supported by this browser.";
															  }
															}

															function showPosition(position) {
															  x.value = position.coords.latitude + 
															  "," + position.coords.longitude;
															}
															getLocation();
															</script>
														
													</div>
												</div>
											</div>
											<!-- /Clinic Content -->
											
											<div class="col-md-4">
											</div>
										
											<div class="col-md-2">
												<div class="consult-price">
													&#8377; <?php echo $row['fees']; ?>
												</div>
											</div>
										</div>
									</div>
									<!-- /Location List -->

								</div>
								<!-- /Locations Content -->
								
								<!-- Reviews Content -->
								<div role="tabpanel" id="doc_reviews" class="tab-pane fade">
								
									<!-- Review Listing -->
									<div class="widget review-listing" >
										<ul class="comments-list" id="comm">
										
											<!-- Comment List -->
											<?php
											$conn = $pdo->open();

											try{
											
											$stmt = $conn->prepare("SELECT name,img,review, rating, recommend, r_date FROM feedback JOIN users JOIN patient WHERE users.id=feedback.g_uid AND patient.user_id=users.id AND did=:did ORDER BY feedback.id DESC LIMIT 3");
											$stmt->execute([":did"=>$row['did']]);
											}
											catch(PDOException $e){
												$_SESSION['error'] = $e->getMessage();
											}
											$pdo->close();
											foreach ($stmt as $r) { 
											$t = date_diff(date_create($r['r_date']), date_create(date("d M Y")));
											$t=$t->format('%d');
											echo'
											<li>
												<div class="comment" style="position: relative;">
													<img class="avatar avatar-sm rounded-circle" alt="User Image" src="assets/img/patients/'.$r['img'].'">
													<div class="comment-body">
														<div class="meta-data">
															<span class="comment-author">'.$r['name'].'</span>
															<span class="comment-date">Reviewed '.$t.' Days ago</span>
															<div class="review-count rating" style="position: absolute;left: 920px">
																<i class="fas fa-star '.(($r['rating']>0)?'filled':'').'"></i>
																<i class="fas fa-star '.(($r['rating']>1)?'filled':'').'"></i>
																<i class="fas fa-star '.(($r['rating']>2)?'filled':'').'"></i>
																<i class="fas fa-star '.(($r['rating']>3)?'filled':'').'"></i>
																<i class="fas fa-star '.(($r['rating']>4)?'filled':'').'"></i>
															</div>
														</div>
														'.(($r['recommend']==1)?'<p class="recommended"><i class="far fa-thumbs-up"></i> I recommend the doctor</p>':(($r['recommend']==0)?'<p class="recommended" style="color: red"><i class="far fa-thumbs-down"></i> I do not recommend the doctor</p>':'')).'
														<p class="comment-content">
															'.$r['review'].'
														</p>
													</div>
												</div>
											</li>';}?>
											<!-- /Comment List -->
											
										</ul>
										
										<!-- Show All -->
										<div class="all-feedback text-center">
											<a href="#" id="show_all" class="btn btn-primary btn-sm">
												Show all feedback <strong>(<?php echo $rv_detail['norv'] ?>)</strong>
											</a>
										</div>
										<!-- /Show All -->
										
									</div>
									<!-- /Review Listing -->
								
									<!-- Write Review -->
									<?php
										if(isset($_SESSION['user'])){
											if($user['type']==1){echo'
									<div class="write-review">
										<h4>Write a review for <strong>Dr. '.$row['name'].'</strong></h4>
										
										<!-- Write Review Form -->
										<form action="add_feedback.php" method="POST">
											<div class="form-group">
												<label>Review</label>
												<div class="star-rating">
													<input id="star-5" type="radio" name="rating" value="5">
													<label for="star-5" title="5 stars">
														<i class="active fa fa-star"></i>
													</label>
													<input id="star-4" type="radio" name="rating" value="4">
													<label for="star-4" title="4 stars">
														<i class="active fa fa-star"></i>
													</label>
													<input id="star-3" type="radio" name="rating" value="3">
													<label for="star-3" title="3 stars">
														<i class="active fa fa-star"></i>
													</label>
													<input id="star-2" type="radio" name="rating" value="2">
													<label for="star-2" title="2 stars">
														<i class="active fa fa-star"></i>
													</label>
													<input id="star-1" type="radio" name="rating" value="1">
													<label for="star-1" title="1 star">
														<i class="active fa fa-star"></i>
													</label>
												</div>
											</div>
											<div class="form-group">
												<span>Recommend?</span>&nbsp;

												<button type="button" class="like" onclick="like()">
													<i class="fa fa-thumbs-up" aria-hidden="true" ></i>
												</button>&nbsp;

												<button type="button" class="dislike" onclick="dislike()">
													<i class="fa fa-thumbs-down" aria-hidden="true"></i>
												</button>
												
											</div>
											<div id="ld">
												
											</div>
											<input type="hidden" name="recommended" id="recommended" value="3">
											<div class="form-group">
												<label>Your review</label>
												<textarea id="review_desc" maxlength="100" name="rev" class="form-control"></textarea>
											  
											  <div class="d-flex justify-content-between mt-3"><small class="text-muted"><span id="chars">100</span> characters remaining</small></div>
											</div>
											<hr>
											<div class="submit-section">
												<input type="hidden" name="did" value="'.$row['did'].'">
												<button type="submit" class="btn btn-primary submit-btn" name="submit">Add Review</button>
											</div>
										</form>
										<!-- /Write Review Form -->
										
									</div>';}}?>
									<!-- /Write Review -->
									<script type="text/javascript">
												function like() {
													document.getElementById('ld').innerHTML='<p class="recommended" ><i class="far fa-thumbs-up"></i> I recommend the doctor</p><br>'
													document.getElementById('recommended').value=1;
												}
												function dislike() {
													document.getElementById('ld').innerHTML='<p class="recommended" style="color: red"><i class="far fa-thumbs-down"></i> I do not recommend the doctor</p><br>'
													document.getElementById('recommended').value=0;
												}
											</script>
						
								</div>
								<!-- /Reviews Content -->
								
								<!-- Business Hours Content -->
								<div role="tabpanel" id="doc_business_hours" class="tab-pane fade">
									<div class="row">
										<div class="col-md-6 offset-md-3">
										
											<!-- Business Hours Widget -->
											<?php
											$day=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
											$today=strtolower($day[date('w')]);
											if(!is_null($timing[$today])){
											$slots=explode(',',$timing[$today]);
											$class='bg-success-light';
											$text='Open Today';}
											else{
											$class='bg-danger-light';
											$text='Closed';
											}
											?>
											<div class="widget business-widget">
												<div class="widget-content">
													<div class="listing-hours">
														<div class="listing-day current">
															<div class="day">Today <span><?php echo date("d M Y") ?></span></div>
															<div class="time-items">
																<span class="open-status"><span class="badge <?php echo $class; ?>"><?php echo $text; ?></span></span>
																<?php
																if(!is_null($timing[$today])){
																for($i=0;$i<count($slots);$i++){echo'
																<span class="time">'.strtoupper($slots[$i]).'</span>';}}?>
															</div>
														</div>
														<?php
														for($i=0;$i<7;$i++){
															$cd=strtolower($day[$i]);
															if(!is_null($timing[$cd])){
															$slots=explode(',',$timing[$cd]);
															}
															echo'
														<div class="listing-day">
															<div class="day">'.$day[$i].'</div>
															<div class="time-items">';
																if(!is_null($timing[$cd])){
																for($j=0;$j<count($slots);$j++){echo'
																<span class="time">'.strtoupper($slots[$j]).'</span>';}}
																else{
																	echo'<span class="time"><span class="badge bg-danger-light">Closed</span></span>';
																}
																echo'
															</div>
														</div>';}?>
														
													</div>
												</div>
											</div>
											<!-- /Business Hours Widget -->
									
										</div>
									</div>
								</div>
								<!-- /Business Hours Content -->
								
							</div>
						</div>
					</div>
					<!-- /Doctor Details Tab -->

				</div>
			</div>		
			<!-- /Page Content -->
   
			<!-- Footer -->
			<?php include 'includes/footer.php'; ?>
			<!-- /Footer -->
		   
		</div>
		<!-- /Main Wrapper -->
			
		<!-- jQuery -->
		<script src="assets/js/jquery.min.js"></script>
		<script type="text/javascript">
			$(document).on('click', '#show_all', function(e){
    		e.preventDefault();
    		$('#comm').html(`<?php
											$conn = $pdo->open();

											try{
											$stmt = $conn->prepare("SELECT name,img,review, rating, recommend, r_date FROM feedback JOIN users JOIN patient WHERE users.id=feedback.g_uid AND patient.user_id=users.id AND did=:did ORDER BY feedback.id DESC ");
											$stmt->execute([":did"=>$row['did']]);
											}
											catch(PDOException $e){
												$_SESSION['error'] = $e->getMessage();
											}
											$pdo->close();
											foreach ($stmt as $r) { 
											$t = date_diff(date_create($r['r_date']), date_create(date("d M Y")));
											$t=$t->format('%d');
											echo'
											<li>
												<div class="comment" style="position: relative;">
													<img class="avatar avatar-sm rounded-circle" alt="User Image" src="assets/img/patients/'.$r['img'].'">
													<div class="comment-body">
														<div class="meta-data">
															<span class="comment-author">'.$r['name'].'</span>
															<span class="comment-date">Reviewed '.$t.' Days ago</span>
															<div class="review-count rating" style="position: absolute;left: 920px">
																<i class="fas fa-star '.(($r['rating']>0)?'filled':'').'"></i>
																<i class="fas fa-star '.(($r['rating']>1)?'filled':'').'"></i>
																<i class="fas fa-star '.(($r['rating']>2)?'filled':'').'"></i>
																<i class="fas fa-star '.(($r['rating']>3)?'filled':'').'"></i>
																<i class="fas fa-star '.(($r['rating']>4)?'filled':'').'"></i>
															</div>
														</div>
														'.(($r['recommend']==1)?'<p class="recommended"><i class="far fa-thumbs-up"></i> I recommend the doctor</p>':(($r['recommend']==0)?'<p class="recommended" style="color: red"><i class="far fa-thumbs-down"></i> I do not recommend the doctor</p>':'')).'
														<p class="comment-content">
															'.$r['review'].'
														</p>
													</div>
												</div>
											</li>';}?>`);
    	});
		</script>

<script type="text/javascript">
	$(document).on('click', '#fav', function(e){
    e.preventDefault();
    var did="<?php echo $row['did']?>";
    //alert(did)
    $.ajax({
      type: 'POST',
      url: 'add-favourite.php',
      data: {did:did},
      dataType: 'json',
      success: function(response){
        if(!response.error){
        	if(response.css=='fav')
          	$('#fav').css({"background-color": "#fb1612","border-color": "#fb1612","color": "#fff"});
          	else
          	$('#fav').removeAttr("style");
        }
      }
    });
  });
</script>
		
		<!-- Bootstrap Core JS -->
		<script src="assets/js/popper.min.js"></script>
		<script src="assets/js/bootstrap.min.js"></script>
		
		<!-- Fancybox JS -->
		<script src="assets/plugins/fancybox/jquery.fancybox.min.js"></script>
		
		<!-- Custom JS -->
		<script src="assets/js/script.js"></script>
		
	</body>

<!-- doccure/doctor-profile.php  30 Nov 2019 04:12:16 GMT -->
</html>