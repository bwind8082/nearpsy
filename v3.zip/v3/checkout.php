<?php include 'includes/session.php'; ?>
<?php

if(isset($_POST['checkout'])){
	$selected=explode("_", $_POST['selected']);
	$i=$selected[0];
	$date=$_POST['da_'.$i];
	$time=$selected[1];
	$did=$_POST['did'];
	$age = date_diff(date_create($user['date_of_birth']), date_create(date("Y-m-d")));
	$age=$age->format('%y');

$conn = $pdo->open();
try{
$stmt = $conn->prepare("SELECT *,d.id as did FROM doctor as d JOIN users WHERE d.user_id = users.id AND d.id=:did");
$stmt->execute([":did"=>$did]);
$row = $stmt->fetch();
$stmt = $conn->prepare("SELECT hospitals.name,hospitals.address FROM hospitals JOIN doctor WHERE d_id=doctor.id AND doctor.id=:did");
$stmt->execute([":did"=>$did]);
$row1 = $stmt->fetch();
$cf=explode('-', $row['fees']);
$cf=$cf[0];
$bf=10;
}
catch(PDOException $e){
			$_SESSION['error'] = $e->getMessage();
}
$pdo->close();
}

else{
	$_SESSION['error'] = 'Fill Up Booking Detail First.';
	header('location: index.php');
}

?>
<!DOCTYPE html> 
<html lang="en">
	
<head>
		<meta charset="utf-8">
		<title>OHAS</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
		
		<!-- Favicons -->
		<link href="assets/img/favicon.png" rel="icon">
		
		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="assets/css/bootstrap.min.css">
		
		<!-- Fontawesome CSS -->
		<link rel="stylesheet" href="assets/plugins/fontawesome/css/fontawesome.min.css">
		<link rel="stylesheet" href="assets/plugins/fontawesome/css/all.min.css">
		
		<!-- Main CSS -->
		<link rel="stylesheet" href="assets/css/style.css">
		<style type="text/css">
					.card-label > select {
		    background-color: #fff;
		    border: 1px solid #dbdbdb;
		    border-radius: 4px;
		    box-shadow: 0 1px 3px 0 rgba(0, 0, 0, .05);
		    display: block;
		    height: 50px;
		    margin-top: -13px;
		    padding: 5px 15px 0;
		    transition: border-color .3s;
		    width: 100%;
		}
		</style>
</head>
	<body>

		<!-- Main Wrapper -->
		<div class="main-wrapper">
		
			<!-- Header -->
			<?php include 'includes/navbar.php'; ?>
			<!-- /Header -->
			
			<!-- Breadcrumb -->
			<div class="breadcrumb-bar">
				<div class="container-fluid">
					<div class="row align-items-center">
						<div class="col-md-12 col-12">
							<nav aria-label="breadcrumb" class="page-breadcrumb">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="index.php">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Checkout</li>
								</ol>
							</nav>
							<h2 class="breadcrumb-title">Checkout</h2>
						</div>
					</div>
				</div>
			</div>
			<!-- /Breadcrumb -->
			
			<!-- Page Content -->
			<div class="content">
				<div class="container">

					<div class="row">
						<div class="col-md-7 col-lg-8">
							<div class="card">
								<div class="card-body">
								
									<!-- Checkout Form -->
									<form action="checkout_process.php" method="POST">
									
										<!-- Personal Information -->
										<div class="info-widget">
											<h4 class="card-title">Personal Information</h4>
											<div class="row">
												<div class="col-md-6 col-sm-12">
													<div class="form-group card-label">
														<label>Name</label>
														<input class="form-control" type="text" name="name" value="<?php echo (isset($user['name']))? $user['name']:'' ?>" required pattern="[a-zA-Z .]{3,}" oninvalid="this.setCustomValidity('Name shoud be atleast 3 Charcter long')" oninput="this.setCustomValidity('')">
													</div>
												</div>
												<div class="col-md-6 col-sm-12">
													<div class="form-group card-label">
														<label>Age</label>
														<input class="form-control" type="text" name="age" value="<?php echo $age?>" required pattern="[0-9]{1,3}" oninvalid="this.setCustomValidity('Plase Enter Valid Age.')" oninput="this.setCustomValidity('')">
													</div>
												</div>
												<div class="col-md-6 col-sm-12">
													<div class="form-group card-label">
														<label>Email</label>
														<input class="form-control" type="email" name="email" value="<?php echo (isset($user['email']))? $user['email']:'' ?>" required pattern="^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$" oninvalid="this.setCustomValidity('Plase Enter Valid Email Address')" oninput="this.setCustomValidity('')">
													</div>
												</div>
												<div class="col-md-6 col-sm-12">
													<div class="form-group card-label">
														<label>Phone</label>
														<input class="form-control" type="text" name="mobileno" value="<?php echo (isset($user['mobileno']))? $user['mobileno']:'' ?>" required pattern="[0-9]{10}" oninvalid="this.setCustomValidity('Plase Enter your 10 digit mobile No.')" oninput="this.setCustomValidity('')">
													</div>
												</div>
												<div class="col-md-6 col-sm-12">
													<div class="form-group card-label">
														<label>Appointment Type</label>
														<select class="form-control" name="aptype" id="aptype" onchange="check_type()">
															<option value="offline">Offline</option>
															<option value="online">Online</option>
														</select>
													</div>
												</div>
											</div>
											
										</div>
										<!-- /Personal Information -->
										
										<div class="payment-widget">
											<h4 class="card-title">Payment Method</h4>
											
											<!-- Credit Card Payment -->
											<div class="payment-list">
												<label class="payment-radio credit-card-option">
													<input type="radio" name="radio" id="card" value="Debit/Credit Card" checked>
													<span class="checkmark"></span>
													Debit/Credit card
												</label>
												<div class="row">
													<div class="col-md-6">
														<div class="form-group card-label">
															<label for="card_name">Name on Card</label>
															<input class="form-control" id="card_name" type="text" name="noc" oninvalid="this.setCustomValidity('Plase Enter Name on Card')" oninput="this.setCustomValidity('')">
														</div>
													</div>
													<div class="col-md-6">
														<div class="form-group card-label">
															<label for="card_number">Card Number</label>
															<input class="form-control" id="card_number" placeholder="1234  5678  9876  5432" type="text" name="cno" oninvalid="this.setCustomValidity('Plase Enter Valid Card Number')" oninput="this.setCustomValidity('')">
														</div>
													</div>
													<div class="col-md-4">
														<div class="form-group card-label">
															<label for="expiry_month">Expiry Month</label>
															<input class="form-control" id="expiry_month" placeholder="MM" type="text" name="exm" oninvalid="this.setCustomValidity('Plase Enter Valid Month')" oninput="this.setCustomValidity('')">
														</div>
													</div>
													<div class="col-md-4">
														<div class="form-group card-label">
															<label for="expiry_year">Expiry Year</label>
															<input class="form-control" id="expiry_year" placeholder="YY" type="text" name="exy" oninvalid="this.setCustomValidity('Plase Enter Valid Year')" oninput="this.setCustomValidity('')">
														</div>
													</div>
													<div class="col-md-4">
														<div class="form-group card-label">
															<label for="cvv">CVV</label>
															<input class="form-control" id="cvv" type="text" name="cvv" oninvalid="this.setCustomValidity('Plase Enter Valid CVV')" oninput="this.setCustomValidity('')">
														</div>
													</div>
												</div>
											</div>
											<!-- /Credit Card Payment -->
											<div class="payment-list">
												<label class="payment-radio credit-card-option">
													<input type="radio" name="radio" id="upi" value="UPI">
													<span class="checkmark"></span>
													UPI
												</label>
												<div class="row">
													<div class="col-md-12">
														<div class="form-group card-label">
															<label for="card_name">UPI Id</label>
															<input class="form-control" id="upi_id" type="text" name="upi_id" oninvalid="this.setCustomValidity('Plase Enter Valid UPI')" oninput="this.setCustomValidity('')">
														</div>
													</div>
												</div>
											</div>
											<!-- Cash Payment -->
											<div class="payment-list" id="cash" >
												<label class="payment-radio paypal-option">
													<input type="radio" name="radio" id="cov" value="COV">
													<span class="checkmark"></span>
													Cash on Visit
												</label>
											</div>
											<!-- /Cash Payment -->
											<script type="text/javascript">
												function check_type() {
													if(document.getElementById('aptype').value=='online'){
														document.getElementById('cash').style.display="none";
													}
													else
														document.getElementById('cash').style.display="";
												}
												function check() {
													if(document.getElementById('card').checked){	
													document.getElementById('card_name').pattern="[a-zA-Z .]{3,}";
													document.getElementById('card_number').pattern="[0-9]{16}";
													document.getElementById('expiry_month').pattern="0[1-9]|1[012]";
													document.getElementById('expiry_year').pattern="2[0-9]";
													document.getElementById('cvv').pattern="[0-9]{3}";					
													document.getElementById('card_name').required = true;
													document.getElementById('card_number').required = true;
													document.getElementById('expiry_month').required = true;
													document.getElementById('expiry_year').required = true;
													document.getElementById('cvv').required = true;
													}
													else{
													document.getElementById('card_name').value="";
													document.getElementById('card_number').value="";
													document.getElementById('expiry_month').value="";
													document.getElementById('expiry_year').value="";
													document.getElementById('cvv').value="";
													document.getElementById('card_name').pattern="";
													document.getElementById('card_number').pattern="";
													document.getElementById('expiry_month').pattern="";
													document.getElementById('expiry_year').pattern="";
													document.getElementById('cvv').pattern="";
													document.getElementById('card_name').required = false;
													document.getElementById('card_number').required = false;
													document.getElementById('expiry_month').required = false;
													document.getElementById('expiry_year').required = false;
													document.getElementById('cvv').required = false;
													}
													if(document.getElementById('upi').checked){
														document.getElementById('upi_id').pattern="^[\\w.-]+@[\\w.-]+$";
														document.getElementById('upi_id').required = true;
													}
													else{
													document.getElementById('upi_id').value="";
													document.getElementById('upi_id').pattern="";
													document.getElementById('upi_id').required = false;
													}
												}
											</script>
											
											<!-- Terms Accept -->
											<div class="terms-accept">
												<div class="custom-checkbox">
												   <input type="checkbox" id="terms_accept" required>
												   <label for="terms_accept">I have read and accept <a href="term-condition.php">Terms &amp; Conditions</a></label>
												</div>
											</div>
											<!-- /Terms Accept -->
											
											<!-- Submit Section -->
											<input type="hidden" name="did" value="<?php echo $did ?>">
											<input type="hidden" name="date" value="<?php echo $date?>">
											<input type="hidden" name="time" value="<?php echo $time ?>">
											<input type="hidden" name="amount" value="<?php echo ($cf+$bf)?>">
											<div class="submit-section mt-4">
												<button type="submit" class="btn btn-primary submit-btn" name="book" onclick="check()">Confirm and Book</button>
											</div>
											<!-- /Submit Section -->
											
										</div>
									</form>
									<!-- /Checkout Form -->
									
								</div>
							</div>
							
						</div>
						
						<div class="col-md-5 col-lg-4 theiaStickySidebar">
						
							<!-- Booking Summary -->
							<div class="card booking-card">
								<div class="card-header">
									<h4 class="card-title">Booking Summary</h4>
								</div>
								<div class="card-body">
								
									<!-- Booking Doctor Info -->
									<div class="booking-doc-info">
										<a href="doctor-profile.php?id=<?php echo $did?>" class="booking-doc-img">
											<img src="assets/img/doctors/<?php echo $row['img']?>" alt="Doctor Image">
										</a>
										<div class="booking-info">
											<h4><a href="doctor-profile.php?id=<?php echo $did?>">Dr. <?php echo $row['name']?></a></h4>
											<div class="rating">
												<i class="fas fa-star filled"></i>
												<i class="fas fa-star filled"></i>
												<i class="fas fa-star filled"></i>
												<i class="fas fa-star filled"></i>
												<i class="fas fa-star"></i>
												<span class="d-inline-block average-rating">35</span>
											</div>
											<div class="clinic-details">
												<p class="doc-location"><i class="fas fa-map-marker-alt"></i> <?php echo $row['city'].', '.$row['state']?></p>
											</div>
										</div>
									</div>
									<!-- Booking Doctor Info -->
									
									<div class="booking-summary">
										<div class="booking-item-wrap">
											<ul class="booking-date">
												<li>Date <span><?php echo $date?></span></li>
												<li>Time <span><?php echo $time ?></li>
											</ul>
											<ul class="booking-fee">
												<li>Consulting Fee <span>&#8377; <?php echo  $cf?></span></li>
												<li>Booking Fee <span>&#8377; <?php echo $bf?></span></li>
											</ul>
											<div class="booking-total">
												<ul class="booking-total-list">
													<li>
														<span>Total</span>
														<span class="total-cost">&#8377; <?php echo ($cf+$bf)?></span>
													</li>
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
							<!-- /Booking Summary -->
							
						</div>
					</div>

				</div>

			</div>		
			<!-- /Page Content -->
   
			<!-- Footer -->
			<?php include 'includes/footer.php'; ?>
			<!-- /Footer -->
		   
		</div>
		<!-- /Main Wrapper -->
	  
		<!-- jQuery -->
		<script src="assets/js/jquery.min.js"></script>
		
		<!-- Bootstrap Core JS -->
		<script src="assets/js/popper.min.js"></script>
		<script src="assets/js/bootstrap.min.js"></script>
		
		<!-- Sticky Sidebar JS -->
        <script src="assets/plugins/theia-sticky-sidebar/ResizeSensor.js"></script>
        <script src="assets/plugins/theia-sticky-sidebar/theia-sticky-sidebar.js"></script>
		
		<!-- Custom JS -->
		<script src="assets/js/script.js"></script>
		
	</body>
</html>