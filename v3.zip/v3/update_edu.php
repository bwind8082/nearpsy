<?php include 'includes/session.php'; ?>
<?php
$conn = $pdo->open();
$output = array('error'=>false,'message'=>'');

$mode=$_POST['mode'];
$deg=$_POST['deg'];
$inti=$_POST['int'];
$year=$_POST['year'];

if(isset($_SESSION['user'])){
	if($mode=='insert'){
		try{
			$stmt = $conn->prepare("SELECT degree from doctor where user_id=:uid");
			$stmt->execute([':uid'=>$user['id']]);
			$row = $stmt->fetch();
			if(is_null($row['degree'])){
				$stmt = $conn->prepare("UPDATE doctor set degree=:deg,institute=:inti,year_of_completion=:year where user_id=:uid");
				$stmt->execute([':deg'=>$deg,':inti'=>$inti,':year'=>$year,':uid'=>$user['id']]);
			
			}
			else{
			$stmt = $conn->prepare("UPDATE doctor set degree=CONCAT(degree, '@@', :deg) where user_id=:uid");
			$stmt->execute([':deg'=>$deg,':uid'=>$user['id']]);
			$stmt = $conn->prepare("UPDATE doctor set institute=CONCAT(institute, '@@', :inti) where user_id=:uid");
			$stmt->execute([':uid'=>$user['id'],':inti'=>$inti]);
			$stmt = $conn->prepare("UPDATE doctor set year_of_completion=CONCAT(year_of_completion, '@@', :year) where user_id=:uid");
			$stmt->execute([':year'=>$year,':uid'=>$user['id']]);
			
			}
		}
		catch(PDOException $e){
			$output['message'] = $e->getMessage();
		}
	}
	else{
		try{
			
			$stmt = $conn->prepare("UPDATE doctor set degree=REPLACE(degree,:deg,'') where user_id=:uid");
			$stmt->execute([':deg'=>$deg,':uid'=>$user['id']]);
			$stmt = $conn->prepare("UPDATE doctor set degree=REPLACE(degree,'@@@@','@@') where user_id=:uid");
			$stmt->execute([':uid'=>$user['id']]);
			$stmt = $conn->prepare("UPDATE doctor set institute=REPLACE(institute,:inti,'') where user_id=:uid");
			$stmt->execute([':inti'=>$inti,':uid'=>$user['id']]);
			$stmt = $conn->prepare("UPDATE doctor set institute=REPLACE(institute,'@@@@','@@') where user_id=:uid");
			$stmt->execute([':uid'=>$user['id']]);
			$stmt = $conn->prepare("UPDATE doctor set year_of_completion=REPLACE(year_of_completion,:year,'') where user_id=:uid");
			$stmt->execute([':year'=>$year,':uid'=>$user['id']]);
			$stmt = $conn->prepare("UPDATE doctor set year_of_completion=REPLACE(year_of_completion,'@@@@','@@') where user_id=:uid");
			$stmt->execute([':uid'=>$user['id']]);
			
			$stmt = $conn->prepare("select RIGHT(degree,2) as l from doctor  where user_id=:uid");
			$stmt->execute([':uid'=>$user['id']]);
			$row = $stmt->fetch();
			if($row['l']=='@@'){
				$stmt = $conn->prepare("UPDATE doctor set degree=SUBSTR(degree, 1, LENGTH(degree) - 2) where user_id=:uid");
				$stmt->execute([':uid'=>$user['id']]);
			}
			$stmt = $conn->prepare("select RIGHT(institute,2) as l from doctor  where user_id=:uid");
			$stmt->execute([':uid'=>$user['id']]);
			$row = $stmt->fetch();
			if($row['l']=='@@'){
				$stmt = $conn->prepare("UPDATE doctor set institute=SUBSTR(institute, 1, LENGTH(institute) - 2) where user_id=:uid");
				$stmt->execute([':uid'=>$user['id']]);
			}
			$stmt = $conn->prepare("select RIGHT(year_of_completion,2) as l from doctor  where user_id=:uid");
			$stmt->execute([':uid'=>$user['id']]);
			$row = $stmt->fetch();
			if($row['l']=='@@'){
				$stmt = $conn->prepare("UPDATE doctor set year_of_completion=SUBSTR(year_of_completion, 1, LENGTH(year_of_completion) - 2) where user_id=:uid");
				$stmt->execute([':uid'=>$user['id']]);
			}

			$stmt = $conn->prepare("select LEFT(degree,2) as l from doctor  where user_id=:uid");
			$stmt->execute([':uid'=>$user['id']]);
			$row = $stmt->fetch();
			if($row['l']=='@@'){
				$stmt = $conn->prepare("UPDATE doctor set degree=SUBSTR(degree, 3, LENGTH(degree)),institute=SUBSTR(institute, 3, LENGTH(institute)),year_of_completion=SUBSTR(year_of_completion, 3, LENGTH(year_of_completion)) where user_id=:uid");
				$stmt->execute([':uid'=>$user['id']]);
			}
			
			$stmt = $conn->prepare("SELECT degree from doctor where user_id=:uid");
			$stmt->execute([':uid'=>$user['id']]);
			$row = $stmt->fetch();
			
			if($row['degree']==''){
				$stmt = $conn->prepare("UPDATE doctor set degree=NULL,institute=NULL,year_of_completion=NULL where user_id=:uid");
				$stmt->execute([':uid'=>$user['id']]);
			
			}
			
		}
		catch(PDOException $e){
			$output['message'] = $e->getMessage();
		}

	}
}

	$pdo->close();
	echo json_encode($output);
?>