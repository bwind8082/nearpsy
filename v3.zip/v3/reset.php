<?php
include 'includes/session.php';

if(isset($_POST['reset'])){
		$email = $_POST['email']; //mail id

		$conn = $pdo->open();

		$stmt = $conn->prepare("SELECT *, COUNT(*) AS numrows FROM users WHERE email=:email");
		$stmt->execute(['email'=>$email]);
		$row = $stmt->fetch();

		if($row['numrows'] > 0){

			$subject = "Forgot Password For Online Hospital Appointment System";

			$message = '
			<html>
			<head>
			<title>Forgot Password</title>
			</head>
			<body>
				<p>Dear '.$row['name'].' </p>
				<p> Your Login credentials for Dav Grocery Store are as below:</p>
				<p>Mobile No: '.$row['email'].'</p>
				<p>Password: '.$row['password'].'</p>
				<p>You Can Login from Following Link:</p>
				<a href="http://localhost/doc_appointment/login.php">http://localhost/doc_appointment/login.php</a>
				<p>Thanks,</p>
				<p>Dav Grocery Store</p>
			</body>
			</html>
			';

			$headers = "MIME-Version: 1.0" . "\r\n";
			$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
			$headers .= 'From: <info@docappointment.com>' . "\r\n";

			if(mail($email,$subject,$message,$headers)){
				$_SESSION['success'] = 'Password sent to Your Email';
			}

			else{
			   $_SESSION['error'] = 'Message could not be sent. Try Again Later';
			}
		}
		else{
			$_SESSION['error'] = 'Email is not Registred.';
		}

		$pdo->close();

}
	
else{
	$_SESSION['error'] = 'Input Email Associated With Account';
}

header('location: forgot-password.php');
?>